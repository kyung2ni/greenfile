//1. 사용자의 패 결정
let userInput = prompt ("가위, 바위, 보 ")
if (userInput != "가위" && userInput != "바위" && userInput != "보") {
    alert ("가위, 바위, 보 중에 하나를 입력하세요")
} else {
    //2. 컴퓨터의 패 결정
    let rnd = Math.random();
    let comInput;
    document.write(rnd + "<br>")
    if (rnd < 0.33) { // 0~ 0.33사이의 값으로 계산 (1/3확률)
        comInput = "가위"
    } else if (rnd < 0.66) {
        comInput = "바위"
    } else {
        comInput ="보"
    }
    document.write("사용자 :" + userInput + "<br>")
    document.write("컴퓨터 :" + comInput)



    if (userInput =="가위") {
        if (comInput =="가위") {
            alert("컴퓨터: 가위 -- 비김")
        } else if (comInput == "바위") {
            alert("컴퓨터: 바위 -- 짐")
        } else if (comInput == "보") {
            alert("컴퓨터: 보 -- 이김")
        }
    }
    else if (userInput =="바위") {
        if (comInput =="가위") {
            alert("컴퓨터: 가위 -- 이김")
        } else if (comInput == "바위") {
            alert("컴퓨터: 바위 -- 비김")
        } else if (comInput == "보") {
            alert("컴퓨터: 보 -- 짐")
        }
    }
    else if (userInput =="보") {
        if (comInput =="가위") {
            alert("컴퓨터: 가위 -- 짐")
        } else if (comInput == "바위") {
            alert("컴퓨터: 바위 -- 이김")
        } else if (comInput == "보") {
            alert("컴퓨터: 보 -- 비김")
        }
    }
}