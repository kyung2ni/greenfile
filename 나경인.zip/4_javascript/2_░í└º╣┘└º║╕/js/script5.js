//1. 사용자의 패 결정

//* 문자열을 상수에 저장. (상수는 대문자로 작성)
// const SCISSORS = "가위";
// const ROCK = "바위";
// const PAPER = "보";

// let game =prompt("가위, 바위, 보 중에 선택하세요")
// let gameNum =0;
// switch (game) {
//     case "가위" :
//         gameNum = 1;
//         break;
//     case "바위" :
//         gameNum = 2;
//         break;
//     case "보" :
//         gameNum = 3;
//         break;
//     default :
//         alert("잘못 입력하셨습니다")

// }

function onButtonclick (userInput) {
    let gameNum =userInput;

    // let rnd = Math.random();
    // let comInput;
    // if (rnd < 0.33) { // 0~ 0.33사이의 값으로 계산 (1/3확률)
    //     comInput = 1;
    // } else if (rnd < 0.66) {
    //     comInput = 2;
    // } else {
    //     comInput =3;
    // }

    let comInput = Math.floor(Math.random() *3+1)

    if (comInput - gameNum ==1 || comInput - gameNum ==-2) {
        alert("컴퓨터가 이김")
    } else if (gameNum - comInput ==1 || gameNum - comInput ==-2) {
        alert("내가 이김")
    } else {
        alert("비김")
    }
}