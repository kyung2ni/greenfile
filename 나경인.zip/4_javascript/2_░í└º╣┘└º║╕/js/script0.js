//1. 사용자의 패 결정

//* 문자열을 상수에 저장. (상수는 대문자로 작성)
const SCISSORS = "가위";
const ROCK = "바위";
const PAPER = "보";

//공통 로직
function onButtonclick(userInput) {
    // 2. 컴퓨터의 패 결정
    let rnd = Math.random();
    let comInput;
    if (rnd < 0.33) { // 0~ 0.33사이의 값으로 계산 (1/3확률)
        comInput = SCISSORS
    } else if (rnd < 0.66) {
        comInput = ROCK
    } else {
        comInput =PAPER
    }
    
    if (userInput ==comInput ){
        alert("유저: "+userInput+"/ 컴퓨터: "+comInput+"===비겼어요")
    } else if (userInput=="가위" && comInput=="보" ||userInput =="바위" && comInput== "가위"|| userInput== "보" && comInput == "바위") {
        alert("유저: "+userInput+"/ 컴퓨터: "+comInput+"===이겼어요!!")
    } else {
        alert("유저: "+userInput+"/ 컴퓨터: "+comInput+"===졌어요...")
    } 
}