//1. 사용자의 패 결정

//* 문자열을 상수에 저장. (상수는 대문자로 작성)
const SCISSORS = "가위";
const ROCK = "바위";
const PAPER = "보";

//공통 로직
function onButtonclick(userInput) {
    // 2. 컴퓨터의 패 결정
    let rnd = Math.random();
    let comInput;
    if (rnd < 0.33) { // 0~ 0.33사이의 값으로 계산 (1/3확률)
        comInput = SCISSORS
    } else if (rnd < 0.66) {
        comInput = ROCK
    } else {
        comInput =PAPER
    }
    
    let result = "사용자 :" +userInput+ " / 컴퓨터:"+ comInput ;
    
    if (userInput ==SCISSORS ){
        
        if (comInput ==SCISSORS) {
            alert(result+"--비김")
        } else if (comInput == ROCK) {
            alert(result+"--짐")
        } else if (comInput == PAPER) {
            alert(result+"--이김")
        }
    } else if (userInput == ROCK){
        
        if (comInput ==SCISSORS) {
            alert(result+"--이김")
        } else if (comInput == ROCK) {
            alert(result+"--비김")
        } else if (comInput == PAPER) {
            alert(result+"--짐")
        }
    } else {
        
        if (comInput ==SCISSORS) {
            alert(result+"--짐")
        } else if (comInput == ROCK) {
            alert(result+"--이김")
        } else if (comInput == PAPER) {
            alert(result+"--비김")
        }    
    }

}
