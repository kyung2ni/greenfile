//1. 사용자의 패 결정

//* 문자열을 상수에 저장. (상수는 대문자로 작성)
const SCISSORS = "가위";
const ROCK = "바위";
const PAPER = "보";
// let userInput = prompt ("가위, 바위, 보 ")
// if (userInput != SCISSORS && userInput != ROCK && userInput != PAPER) {
//     alert ("가위, 바위, 보 중에 하나를 입력하세요")
// } else {
    
//     document.write("사용자 :" + userInput + "<br>")
//     document.write("컴퓨터 :" + comInput)


//승패결정
// switch(userInput) {
//     case SCISSORS :
//         switch (comInput) {
//             case comInput ==SCISSORS :
//                 alert("컴퓨터: 가위 -- 비김")
//             break;
//             case comInput ==ROCK :
//                 alert("컴퓨터: 바위 -- 짐")
//             break;
//             default :
//                 alert("컴퓨터: 보 -- 이김")
//         }
//     break;
//     case ROCK :
//         switch (comInput) {
//             case SCISSORS :
//                 alert("컴퓨터: 가위 -- 이김")
//             break;
//             case ROCK :
//                 alert("컴퓨터: 바위 -- 비김")
//             break;
//             default :
//                 alert("컴퓨터: 보 -- 짐")
//         }
//     break;
//     default :
//         switch (comInput) {
//             case SCISSORS :
//                 alert("컴퓨터: 가위 -- 짐")
//             break;
//             case ROCK :
//                 alert("컴퓨터: 바위 -- 이김")
//             break;
//             default :
//                 alert("컴퓨터: 보 -- 비김")
//         }
//     }


//가위를 눌렀을때
function onScissorsClick() {
    //2. 컴퓨터의 패 결정
    let rnd = Math.random();
    let comInput;
    if (rnd < 0.33) { // 0~ 0.33사이의 값으로 계산 (1/3확률)
        comInput = SCISSORS
    } else if (rnd < 0.66) {
        comInput = ROCK
    } else {
        comInput =PAPER
    }
    
    
    if (comInput ==SCISSORS) {
        alert("컴퓨터: 가위 -- 비김")
    } else if (comInput == ROCK) {
        alert("컴퓨터: 바위 -- 짐")
    } else if (comInput == PAPER) {
        alert("컴퓨터: 보 -- 이김")
    }

}
//바위를 눌렀을때
function onRockClick() {
    // 2. 컴퓨터의 패 결정
    let rnd = Math.random();
    let comInput;
    if (rnd < 0.33) { // 0~ 0.33사이의 값으로 계산 (1/3확률)
        comInput = SCISSORS
    } else if (rnd < 0.66) {
        comInput = ROCK
    } else {
        comInput =PAPER
    }
    
    
    if (comInput ==SCISSORS) {
        alert("컴퓨터: 가위 -- 이김")
    } else if (comInput == ROCK) {
        alert("컴퓨터: 바위 -- 비김")
    } else if (comInput == PAPER) {
        alert("컴퓨터: 보 -- 짐")
    }
    
}
//보를 눌렀을때
function onPaperClick() {
    //2. 컴퓨터의 패 결정
    let rnd = Math.random();
    let comInput;
    if (rnd < 0.33) { // 0~ 0.33사이의 값으로 계산 (1/3확률)
        comInput = SCISSORS
    } else if (rnd < 0.66) {
        comInput = ROCK
    } else {
        comInput =PAPER
    }
    
    
    if (comInput ==SCISSORS) {
        alert("컴퓨터: 가위 -- 짐")
    } else if (comInput == ROCK) {
        alert("컴퓨터: 바위 -- 이김")
    } else if (comInput == PAPER) {
        alert("컴퓨터: 보 -- 비김")
    }
    
}



