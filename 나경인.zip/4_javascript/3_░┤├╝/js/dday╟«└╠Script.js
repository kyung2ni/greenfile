let now =new Date();

let firstDay = new Date(2023,0,6);

let toNow = now.getTime();

let toFirst = firstDay.getTime();
let passedTime = toNow - toFirst;
let passedDay = Math.ceil(passedTime / (1000*60*60*24));

document.querySelector("#accent").innerHTML = passedDay + "일";

calcDate(100);
calcDate(200);
calcDate(365);
calcDate(1000);


function calcDate(days) {
    //처음 만난 날에 100일을 더하여 future 변수에 저장(밀리초)
    let future = toFirst + days*(1000*60*60*24);
    //future값을 이용하여 Date객체롤 변환하여 someday 변수에 저장
    let someday = new Date(future);
    //연도를 가져와 year 변수에 저장
    year = someday.getFullYear();
    //월을 가져와 month 변수에 저장
    month = someday.getMonth();
    //일을 가져와 date 변수에 저장
    date = someday.getDate();
    //출력해야 하는 곳에 ####년 #월 #일 형태로 출력
    document.querySelector("#date"+days).innerHTML = year+ "년"+month+"월"+date+"일";
}