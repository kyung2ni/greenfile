let today = new Date();
let nowMonth = today.getMonth()+1;
let nowYear = today.getYear();
let nowDay = today.getDay();
let loveday = new Date(2024, 0, 5);

let day100year = loveday.getYear();



let cpday = today.getTime() - loveday.getTime();
let cpday2 = Math.ceil(cpday / (1000*60*60*24)); 


document.write(cpday2+"<br>")
document.write(day100year+"<br>")
 
document.querySelector("#display").innerHTML = cpday2
