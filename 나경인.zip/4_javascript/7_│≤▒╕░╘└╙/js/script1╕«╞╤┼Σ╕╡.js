let shotsLeft = document.querySelector("#shots-count");
let comBtn = document.querySelector("#btn-computer");
let userBtn2 = document.querySelector("#btn2-user");
let userBtn3 = document.querySelector("#btn3-user");
let text = document.querySelector("#text");
let comScore = document.querySelector("#computer-score")
let userScore = document.querySelector("#user-score")
let leftScore = document.querySelector("#shots-count")

//컴퓨터부터 시작 (사용자 버튼 비활성화)
userBtn2.disabled = true;
userBtn3.disabled = true;


//컴퓨터 버튼 눌렀을 때 성공 확률
comBtn.addEventListener("click", function() {
    let shoot2OrShoot3 = Math.random();
    let shoot = Math.random();
    let number = parseInt(comScore.textContent);

    if (shoot2OrShoot3 < 0.5) {
        if (shoot < 0.5) {
            text.textContent = "컴퓨터 2점슛 성공 / 사용자 턴"
            comScore.textContent = number + 2;
        } else {
            text.textContent = "컴퓨터 2점슛 실패 / 사용자 턴"
        }
    } else if (shoot <0.33) {
        text.textContent = "컴퓨터 3점슛 성공 / 사용자 턴"
        comScore.textContent = number + 3;
    } else {
        text.textContent = "컴퓨터 3점슛 실패 / 사용자 턴"
    }
    //버튼 비활성화
    comBtn.disabled = true;
    userBtn2.disabled = false;
    userBtn3.disabled = false;
});

//사용자 2점 버튼 클릭 이벤트
userBtn2.addEventListener("click", function() {
    userShoot(0.5, 2);
});
//사용자 3점 버튼 클릭 이벤트
userBtn3.addEventListener("click", function() {
    userShoot(0.33, 3);
});


//사용자 버튼 눌렀을 때 성공 확률
function userShoot(shootType, point) {
    let shoot = Math.random();
    let number = parseInt(userScore.textContent);
    let leftNumber = parseInt(leftScore.textContent);

    if (shoot < shootType) {
        text.textContent = "사용자 " + point + "점슛 성공 / 컴퓨터 턴"
        userScore.textContent = number + point;
    } else {
        text.textContent = "사용자 " + point + "점슛 실패 / 컴퓨터 턴"
    } 

    //버튼 비활성화
    comBtn.disabled = false;
    userBtn2.disabled = true;
    userBtn3.disabled = true;
    //남은 카운트 제거
    leftScore.textContent = leftNumber -1;
    
    //게임 종료
    let leftzero = parseInt(leftScore.textContent);
    if (leftzero <= 0) {
        let comNumber = parseInt(comScore.textContent);
        let userNumber = parseInt(userScore.textContent);

        if (comNumber < userNumber) {
            text.textContent = "승리했습니다!!"
        } else if (comNumber == userNumber) {
            text.textContent = "무승부"
        } else {
            text.textContent = "아쉽게도 패배했습니다..."
        }

        comBtn.disabled = true;
        userBtn2.disabled = true;
        userBtn3.disabled = true;
    }
};
