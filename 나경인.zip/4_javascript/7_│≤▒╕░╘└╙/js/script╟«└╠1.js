let comScore = 0;
let userScore = 0;
let isComputerTurn = true; // Flag변수
let shotsLeft = 15;

//컴푸터의 슛 버튼 생성
function onComputerShoot() {
    if (!isComputerTurn) {
        return;
    } 
    let shootType = Math.random() <0.5 ? 2 : 3; //2점슛 or 3점슛 결정
    let textElem = document.getElementById("text");
    let comScoreElem = document.getElementById("computer-score");
    let computerButtons = document.getElementsByClassName("btn-computer");
    let userButtons = document.getElementsByClassName("btn-user");
    // innerHTML = 태그를 인식
    // innerText = 문자로 인식
    if (shootType == 2 ) { //2점슛일 경우
        if (Math.random() < 0.5) { //2점 슛 성공확률 50% 설정
            textElem.innerText = "컴퓨터가 2점슛을 성공하였습니다."
            comScore += 2;
            comScoreElem.innerHTML = comScore;
        } else { //2점슛 실패
            textElem.innerHTML = "컴퓨터가 2점슛을 실패하였습니다."
        }
    } else {
        (shootType == 3 )  //3점슛일 경우
        if (Math.random() < 0.33) { //3점 슛 성공확률 50% 설정
            textElem.innerHTML = "컴퓨터가 3점슛을 성공하였습니다."
            comScore += 3;
            comScoreElem.innerHTML = comScore;
        } else { //3점슛 실패
            textElem.innerHTML = "컴퓨터가 3점슛을 실패하였습니다."
        }
    }

    isComputerTurn = false;
    for (let i=0; i<computerButtons.length; i++) {
        computerButtons[i].disabled = true;
    }
    for (let i=0; i<userButtons.length; i++) {
        userButtons[i].disabled = false; 
    }
}

//사용자의 슛 버튼
function onUserShoot(shootType) {
    if (isComputerTurn) {
        return;
    }
    
    //2점슛 or 3점슛 결정
    let textElem = document.getElementById("text");
    let userScoreElem = document.getElementById("user-score");
    let computerButtons = document.getElementsByClassName("btn-computer");
    let userButtons = document.getElementsByClassName("btn-user");
    let shotsLeftElem =document.getElementById("shots-count");
    // innerHTML = 태그를 인식
    // innerText = 문자로 인식
    if (shootType == 2 ) { //2점슛일 경우
        if (Math.random() < 0.5) { //2점 슛 성공확률 50% 설정
            textElem.innerText = "2점슛을 성공하였습니다."
            userScore += 2;
            userScoreElem.innerHTML = userScore;
        } else { //2점슛 실패
            textElem.innerHTML = "2점슛을 실패하였습니다."
        }
    } else {
        // (shootType == 3 )  //3점슛일 경우
        if (Math.random() < 0.33) { //3점 슛 성공확률 50% 설정
            textElem.innerHTML = "3점슛을 성공하였습니다."
            userScore += 3;
            userScoreElem.innerHTML = userScore;
        } else { //3점슛 실패
            textElem.innerHTML = "3점슛을 실패하였습니다."
        }
    }
    isComputerTurn = true;
    for (let i=0; i<computerButtons.length; i++) {
        computerButtons[i].disabled = false;
    }
    for (let i=0; i<userButtons.length; i++) {
        userButtons[i].disabled = true; 
    }
    shotsLeft--;
    shotsLeftElem.innerHTML = shotsLeft;

    if (shotsLeft == 0) {
        if (userScore > comScore) {
            textElem.innerHTML = "이겼습니다!!!"
        } else if (userScore < comScore) {
            textElem.innerHTML = "졌습니다..."
        } else {
            textElem.innerHTML = "비겼습니다"
        }
        for (let i=0; i<computerButtons.length; i++) {
            computerButtons[i].disabled = true;
        }
        for (let i=0; i<userButtons.length; i++) {
            userButtons[i].disabled = true; 
        }
    }
}
