/*
    컴퓨터와 사용자가 15번씩 번갈아가며 슛을 한다
    컴퓨터가 2점슛 혹은 3점슛을 한다
    사용자가 2점슛과 3점슛 중 골라서 한다
    2점슛 혹은 3점슛이 확률적으로 성공하면 스코어가 올라간다
    컴퓨터와 사용자가 15번의 슛이 끝나고 서로 점수를 비교해 승패를 정한다

    1. 컴퓨터가 먼저 시작한다.
    2. 사용자가 컴퓨터의 슛 버튼을 클릭한다.
    3. 컴퓨터는 2점슛 or 3점슛인지를 랜덤으로 결정한다.
       - 2점슛 or 3점슛 >> 50:50
       - 2점슛의 성공 확률 >> 50%
       - 3점슛의 성공 확률 >> 33%
    4. 컴퓨터가 슛을 성공하면 컴퓨터의 점수를
       2점 혹은 3점을 올려준다.
    5. 사용자의 턴으로 바꿔준다.
    6. 2점슛 혹은 3점슛을 선택하여 클릭한다.
       - 2점슛의 성공 확률 >> 50%
       - 3점슛의 성공 확률 >> 33%
    7. 사용자의 슛이 성공하면 사용자의 점수를 올려준다.
    8. 남은 슛 횟수를 1 줄인다.
    9. 남은 슛 횟수가 0이 될때까지 1-8까지 반복.
    10. 남은 슛 횟수가 0이 되면
       양쪽의 점수를 비교하여 승자를 알려준다.

*/
// let shoot2OrShoot3 = Math.random();
let shotsLeft = document.querySelector("#shots-count");
let comBtn = document.querySelector("#btn-computer");
let userBtn2 = document.querySelector("#btn2-user");
let userBtn3 = document.querySelector("#btn3-user");
let text = document.querySelector("#text");
let comScore = document.querySelector("#computer-score")
let userScore = document.querySelector("#user-score")
let leftScore = document.querySelector("#shots-count")

//컴퓨터부터 시작 (사용자 버튼 비활성화)
userBtn2.disabled = true;
userBtn3.disabled = true;


//컴퓨터 버튼 눌렀을 때 성공 확률
comBtn.addEventListener("click", function() {
    let shoot2OrShoot3 = Math.random();
    let shoot2 = Math.random();
    let number = parseInt(comScore.textContent);

    if (shoot2OrShoot3 < 0.5) {
        if (shoot2 < 0.5) {
            text.textContent = "컴퓨터 2점슛 성공 / 사용자 턴"
            comScore.textContent = number + 2;
        } else {
            text.textContent = "컴퓨터 2점슛 실패 / 사용자 턴"
        }
    } else if (shoot2 <0.33) {
        text.textContent = "컴퓨터 3점슛 성공 / 사용자 턴"
        comScore.textContent = number + 3;
    } else {
        text.textContent = "컴퓨터 3점슛 실패 / 사용자 턴"
    }
    //버튼 비활성화
    comBtn.disabled = true;
    userBtn2.disabled = false;
    userBtn3.disabled = false;
})




//사용자 2점 버튼 눌렀을 때 성공 확률
userBtn2.addEventListener("click", function() {
    let shoot = Math.random();
    let number = parseInt(userScore.textContent);
    let leftNumber = parseInt(leftScore.textContent);

    if (shoot < 0.5) {
        text.textContent = "사용자 2점슛 성공 / 컴퓨터 턴"
        userScore.textContent = number + 2;
    } else {
        text.textContent = "사용자 2점슛 실패 / 컴퓨터 턴"
    } 

    //버튼 비활성화
    comBtn.disabled = false;
    userBtn2.disabled = true;
    userBtn3.disabled = true;
    //남은 카운트 제거
    leftScore.textContent = leftNumber -1;
    
    //게임 종료
    let leftzero = parseInt(leftScore.textContent);
    if (leftzero <= 0) {
        let comNumber = parseInt(comScore.textContent);
        let userNumber = parseInt(userScore.textContent);
        if (comNumber < userNumber) {
            text.textContent = "승리했습니다!!"
        } else if (comNumber == userNumber) {
            text.textContent = "무승부"
        } else {
            text.textContent = "아쉽게도 패배했습니다..."
        }
        alert("게임 종료")
        comBtn.disabled = true;
        userBtn2.disabled = true;
        userBtn3.disabled = true;
    }
})

//사용자 3점 버튼 눌렀을 때 성공 확률
userBtn3.addEventListener("click", function() {
    let shoot = Math.random();
    let number = parseInt(userScore.textContent);
    let leftNumber = parseInt(leftScore.textContent);

    if (shoot < 0.33) {
        text.textContent = "사용자 3점슛 성공 / 컴퓨터 턴"
        userScore.textContent = number + 3;
    } else {
        text.textContent = "사용자 3점슛 실패 / 컴퓨터 턴"
    } 

    //버튼 비활성화
    comBtn.disabled = false;
    userBtn2.disabled = true;
    userBtn3.disabled = true;
    //남은 카운트 제거
    leftScore.textContent = leftNumber -1;

    //게임 종료
    let leftzero = parseInt(leftScore.textContent);
    if (leftzero <= 0) {
        let comNumber = parseInt(comScore.textContent);
        let userNumber = parseInt(userScore.textContent);
        if (comNumber < userNumber) {
            text.textContent = "승리했습니다!!"
        } else if (comNumber == userNumber) {
            text.textContent = "무승부"
        } else {
            text.textContent = "아쉽게도 패배했습니다..."
        }
        alert("게임 종료")
        comBtn.disabled = true;
        userBtn2.disabled = true;
        userBtn3.disabled = true;
    }
}) 
// userBtn2.addEventListener("click", function(){
//     let leftzero = parseInt(leftScore.textContent);
//     if (leftzero <= 0) {
//         let comNumber = parseInt(comScore.textContent);
//         let userNumber = parseInt(userScore.textContent);
//         if (comNumber < userNumber) {
//             text.textContent = "승리했습니다!!"
//         } else if (comNumber == userNumber) {
//             text.textContent = "무승부"
//         } else {
//             text.textContent = "아쉽게도 패배했습니다..."
//         }
//         alert("게임 종료")
//         comBtn.disabled = true;
//         userBtn2.disabled = true;
//         userBtn3.disabled = true;
//     }
// })
