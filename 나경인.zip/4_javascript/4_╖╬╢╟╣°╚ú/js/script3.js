let list = [];

// list 배열에 1부터 45까지의 숫자를 저장

for(i=1; i<=45; i++){
    list.push(i);
}

let result = []; // 결과저장


for (let i=0; i<6; i++){



    let index = Math.floor(Math.random() * list.length);

    // 해당 인덱스의 값을 가져옴
    let num = list[index];

    // 배열에서 인덱스의 값 제거
    list.splice(index,1);

    // console.log(num, list);

    // document.write(num + "<br>")

    result.push(num);


}

result.sort(function compare(a,b){
    return a-b;
});   //숫자 크기 순서대로 정렬


// function compare(a,b){
//     return a-b;
// }




for(let i=0; i<6; i++){
    document.write("<span class='ball'>"+ result[i] + "</span>");
}


//비교함수 : 두 개의 값을 비교해서 어떤 것의 순위가 더 높은지 판별

/*
    if (a<b){
        return 0보다 작은 숫자;
    }
    if (a>b){
        return 0보다 큰 숫자;
    }
    return 0;  // a와 b의 값이 동일

*/
