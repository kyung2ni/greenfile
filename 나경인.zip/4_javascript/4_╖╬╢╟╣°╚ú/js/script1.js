let num1, num2, num3, num4, num5, num6;  // 숫자 6개를 저장할 변수를 준비

// num1에 랜덤값 설정
num1 = Math.ceil(Math.random()*45);   
 
                                        // Math.ceil = 반올림
// 이미 뽑은 숫자와 동일하다면 다시 랜덤값을 생성
num2 = Math.ceil(Math.random()*45);
while(num1 == num2){
    num2 = Math.ceil(Math.random()*45);
}

num3 = Math.ceil(Math.random()*45);
while(num3 == num1 || num3 == num2){
    num3 = Math.ceil(Math.random()*45);
}

num4 = Math.ceil(Math.random()*45);
while(num4 == num3 || num4 == num2 || num4 == num1){
    num4 = Math.ceil(Math.random()*45);
}

num5 = Math.ceil(Math.random()*45);
while(num5 == num4 || num5 == num3 || num5 == num2 || num5 == num1){
    num5 = Math.ceil(Math.random()*45);
}

num6 = Math.ceil(Math.random()*45);
while(num6 == num5 || num6 == num4 || num6 == num3 || num6 == num2 || num6 == num1){
    num6 = Math.ceil(Math.random()*45);
}

// 조건문은 , 사용 불가능  ex) num1,num2 == num3 (x)

document.write(num1+"<br>");
document.write(num2+"<br>");
document.write(num3+"<br>");
document.write(num4+"<br>");
document.write(num5+"<br>");
document.write(num6);




