let list = [];

// list 배열에 1부터 45까지의 숫자를 저장

for(i=1; i<=45; i++){
    list.push(i);
}

let result = []; // 결과저장

for (let i=0; i<6; i++){



    let index = Math.floor(Math.random() * list.length);

    // 해당 인덱스의 값을 가져옴
    let num = list[index];

    // 배열에서 인덱스의 값 제거
    list.splice(index,1);

    // console.log(num, list);

    // document.write(num + "<br>")

    result.push(num);


}

for(let i=0; i<6; i++){
    document.write("<span class='ball'>"+ result[i] + "</span>");
}






