let isCheck = false;
//check를 변수에 저장
let buttons = document.querySelectorAll(".check");
//check버튼에 이벤트 등록
for (let i=0; i<buttons.length; i++) {

    buttons[i].addEventListener("click", function(){
    //만약 check가 선택되어 있지 않은 상태라면
        if (isCheck == false) {
    //선택한 대상의 부모의 글자색을 회색으로 변경
        this.parentNode.style.color = "#ccc"
        isCheck = true;
        } else {
    //check가 선택되어 있는 상태라면
        this.parentNode.style.color = "#222"
        isCheck = false;
    //선택한 대상의 부모의 글자색을 검정으로 변경

        }
    
    })
}
