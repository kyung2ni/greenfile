function newRegister() {

    //새로운 p 요소를 생성하여 newP변수에 저장
    //새로운 텍스트 노드 생성하여 newText변수에 저장
    //텍스트를 p의 자식노드로 연결
    //결과를 나타낼 #nameList를 가져옴
    //newP를 nameList의 자식으로 연결
    //다음 이름을 입력할 수 있도록 입력창의 내용을 지움
    
    //새로운 p 요소를 생성하여 newP변수에 저장
    let newP = document.createElement("p");
    
    //새로운 텍스트 노드 생성하여 newText변수에 저장
    let userName = document.querySelector("#userName");
    let newText = document.createTextNode(userName.value);
    
    //텍스트를 p의 자식노드로 연결
    newP.appendChild(newText);

    //결과를 나타낼 #nameList를 가져옴
    let nameList = document.querySelector("#nameList");

        //newP를 nameList의 자식으로 연결
        // nameList.appendChild(newP);

    //추가하는 p태그를 #nameList 맨 앞에 추가
    nameList.insertBefore(newP, nameList.childNodes[0]);

    //다음 이름을 입력할 수 있도록 입력창의 내용을 지움
    userName.value = "";

    ///////////////////////////////////////////////////////////////

    //span태그를 만들어 delBtn 변수에 저장
    let delBtn = document.createElement("span");

    //새 텍스트 노드 생성하여 delText에 저장
    let delText = document.createTextNode("X");

    //클래스 생성
    delBtn.setAttribute("class", "del");

    //텍스트를자식 노드 추가
    delBtn.appendChild(delText);

    //버튼을 p태그 자식으로 추가
    newP.appendChild(delBtn);

    let removeBtn = document.querySelectorAll(".del");

    for (let i=0; i<removeBtn.length; i++) {
        removeBtn[i].addEventListener("click", function() {
            //현재 클릭한 노드(X)의 부모의 부모노드가 있으면
            if (this.parentNode.parentNode) {
                //현재 노드(X, this)의 부모의 부모(div)를 찾아서
                //현재 노드의 부모노드(p)를 삭제
                this.parentNode.parentNode.removeChild(this.parentNode);
            }
        })
    }
}