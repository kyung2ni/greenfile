function newRegister() {

    let newP = document.createElement("p");

    let userName = document.querySelector("#userName");
    let newName = document.createTextNode(userName.value)

    newP.appendChild(newName)

    let nameList = document.querySelector("#nameList")

    nameList.appendChild(newP)

    userName.value= ""

    //span 태그를 만들어 delBtn 변수에 저장
    let delBtn = document.createElement("span")
    //새 텍스트 노드 생성하여 delText에 저장
    let delText = document.createTextNode("X")

    //클래스 생성
    delBtn.setAttribute(".class",".del")
    //텍스트를 자식 노드 추가

    //버튼을 p태그 자식으로 추가

}