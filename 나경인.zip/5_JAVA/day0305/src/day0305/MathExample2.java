package day0305;

import java.util.Scanner;
import java.util.StringTokenizer;

public class MathExample2 {
	public static void main(String[] args) {
		//랜덤으로 배열안의 글자가 선택되고
		//글자를 맞추는 게임
		//10번이상 시도하면 정답을 알려줌
		
		//1. 단어를 랜덤으로 선택 Math.random()
		//2. 선택된 단어의 글자 길이만큼 밑줄을 표시
		//3. 사용자에게 글자를 입력받고
		//	입력받은 글자가 단어에 포함되어있으면
		//	밑줄을 글자로 변경
		//	횟수 증가
		//4. 글자를 모두 맞췄으면 횟수와 함께 정답이라고 출력하고 종료
		
		Scanner scan = new Scanner(System.in);
		int rnd = (int) (Math.random()*6); //랜덤 배열 글자 선택
		
		String[] words = {"java","school","programmer","book","green","example"};
//		StringTokenizer st = new StringTokenizer(words[rnd]);
//		System.out.println(st.nextToken());
		String st = new String(words[rnd]);
		System.out.println(st);
		StringBuilder blind = new StringBuilder();
		
		for (int i=0; i<words[rnd].length(); i++) {
			blind.append("_");
		}
		String result = blind.toString();
		System.out.println(result);
		
		int cnt = 0;
		for (int i=1; i<=10; i++) {
			System.out.println("현재의 상태 : "+result);
			System.out.print("글자를 추측하시오 : ");
			String wd = scan.nextLine();
			StringTokenizer st2 = new StringTokenizer(words[rnd],wd);	
			
		}
	}
}
