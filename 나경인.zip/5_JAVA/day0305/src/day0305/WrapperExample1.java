package day0305;

public class WrapperExample1 {
	public static void main(String[] args) {
		//쓰지마세요!!!!
//		Integer obj1 = new Integer(100);
		
		Integer obj = 100;
		Integer obj2 = Integer.valueOf("200");
		System.out.println(obj2);
		
	}
}
