package day0305;

public class SystemTime {
	public static void main(String[] args) {
		
		long time1 = System.currentTimeMillis();
		
		int sum=0;
		for(int i=0; i<=1000000; i++) {
			sum+= i;
		}
		System.out.println("1~1000000까지의 합"+sum);
		
		long time2 = System.currentTimeMillis();
		
		System.out.println((double)((time2-time1)/1000.0)+"밀리초 소요됨");
		
		String str = "        abcd         ";
		String newStr = str.toUpperCase();
		String newStr2 = newStr.toLowerCase();
		System.out.println(newStr2);
	}
}
