package day0305;

public class MathExample1 {
	public static void main(String[] args) {
		double v1 = Math.round(5.2);
		double v2 = Math.round(5.8);
		System.out.println(v1);
		System.out.println(v2);
		
		//rint() : 가까운 정수의 실수값을 double 형태로 리턴
		//짝수로 결과를 나타내는 반올림
		//홀수면 올림하고, 짝수면 내림(오차범위를 줄임)
		
		double v3 = Math.rint(8.5);
		double v4 = Math.rint(5.7);
		System.out.println(v3);
		System.out.println(v4);
		
		double sum=0, roundSum=0, rintSum =0;
		for (double i=1.5; i<=10.5; i++) {
			sum+= i;
			roundSum+=Math.round(i);
			rintSum +=Math.rint(i);
		}
		System.out.println(sum);
		System.out.println(roundSum);
		System.out.println(rintSum);
		
		//소수점 셋째자리수에서 반올림
		
		double value = 12.4567;
		double num = value * 100;
		long tmp = Math.round(num);
		double result = tmp /100.0;
		System.out.println(result);
	}
}
