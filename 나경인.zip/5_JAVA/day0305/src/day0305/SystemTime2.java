package day0305;

public class SystemTime2 {
	public static void main(String[] args) {
		
		long time1 = System.currentTimeMillis();
		
		String str = "";
		StringBuffer str2 = new StringBuffer();
		StringBuilder str3 = new StringBuilder();
		for(int i=0; i<=100000; i++) {
			str3.append("a");
		}
		
		long time2 = System.currentTimeMillis();
		
		System.out.println((time2-time1)+"밀리초 소요됨");
		
		//String : 584밀리초
		//StringBuffer : 5밀리초
		//StringBuilder : 3밀리초
	}
}
