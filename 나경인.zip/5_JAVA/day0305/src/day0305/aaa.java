package day0305;

import java.nio.file.spi.FileSystemProvider;
import java.text.SimpleDateFormat;
import java.util.Date;

public class aaa {
	public static void main(String[] args) {
		Date now = new Date();
		String strNow1 = now.toString();
		System.out.println(strNow1);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy년 MM월 dd일 HH시 mm분 ss초");
		String strNow2 = sdf.format(now);
		System.out.println(strNow2);
		
	}
	/*
	 * StringBuilder 클래스
	 * 	잦은 문자열 변경 작업을 해야 한다면 String 보다는 StringBulider 가 좋음
	 * 	StringBuilder 는 내부 버퍼에 문자열을 저장해두고 그 안에서 추가, 수정, 삭제 작업을 하도록 설계
	 * 	리턴 타입			메소드(매개변수)					설명
	 * 	StringBuilder	append(기본값|문자열)			문자열을 끝에 추가
	 * 	StringBuilder	insert(위치, 기본값|문자열)		문자열을 지정 위치에 추가
	 * 	StringBuilder	delete(시작 위치, 끝 위치)		문자열 일부를 삭제
	 * 	StringBuilder	replace(시작 위치,끝 위치,문자열) 	문자열 일부를 대체
	 * 	String			toString()					완성된 문자열을 리턴
	 * 
	 * StringBuffer 클래스
	 * 	String 처럼 문자형 배열(char[])을 내부적으로 가지고 있다
	 * 	그러나, String 클래스와 달리 내용을 변경할 수 있다(mutable)
	 * 	인스턴스를 생성할 때 버퍼(배열)의 크기를 출분히 지정해주는 것이 좋다
	 * 	(버퍼가 작으면 성능 저하 - 작업 중에 더 큰 배열의 생성이 필요)
	 * 	String 클래스와 달리 equals()를 오버라이딩하지 않았다 >> 주소비교
	 * 
	 * StringBuilder 와 StringBuffer 클래스의 차이
	 * 	StringBuffer 와 StringBuilder 클래스는 둘 다 크기가 유연하게 변하는 가변적인 특성을 가짐
	 * 	제공하는 메서드도 같고 사용하는 방법도 동일함
	 * 	두 클래스의 차이는 동기화 지원의 유무
	 * 	StringBuffer 는 각 메소드별로 Synchronized keyword 가 존재하여 멀티 스레드 상태에서 동기화를 지원
	 * 	StringBuilder 는 단일 스레드 환경에서만 사용하도록 설계되어 있음
	 * 	StringBuilder 가 StringBuffer 보다 속도는 더 빠르지만 현업에서는 언제 멀티스레드 환경에서
	 *  돌아갈지 알지 못하기에 안정적인 StringBuffer로 통일하여 코딩하는것을 추천함
	 * 	
	 * 					String			StringBuffer			StringBuilder
	 * 	가변 여부			불변				가변						가변
	 * 	스레드 세이프		O				O						X
	 * 	연산 속도			느림				중간						빠름
	 * 	저장 위치	String Constant Pool	Heap					Heap
	 * 				(리터럴 생성)
	 * 	언제 사용	  문자열 추가 연산이 적고,		문자열 추가 연산이 많고,		문자열 추가 연산이 많고
	 * 				스레드 세이프 환경		스레드 세이프 환경 			스레드 세이프 고려 X 
	 									조금 변경이 많은 경우 		빠른 연산 필요
	 * 
	 * StringTokenizer 클래스
	 * 	문자열에 여러 종류가 아닌 한 종류의 구분자만 있다면 StringTokenizer 를 사용할 수도 있음
	 * 	StringTokenizer 객채를 생성 시 첫 번째 매개값으로 전체 문자열을 주고,
	 * 	두 번째 매개값으로 구분자를 줌. 구분자를 생략하면 공백이 기본 구분자가 됨
	 * 
	 * 	리턴 타입		메소드(매개변수)			설명
	 * 	int			countTokens()		분리할 수 있는 문자열의 총 수
	 * 	boolean		hasMoreTokens()		남아 있는 문자열이 있는지 여부
	 * 	String		nextToken()			문자열을 하나씩 가져옴
	 * 
	 * Math 클래스
	 * 	수학계산에 유용한 메서드로 구성되어 있다(모두 static 메서드)
	 * 
	 * 포장 객체
	 * 	기본형을 클래스로 정의한 것 기본형 값도 객체로 다뤄져야 할 때가 있다
	 * 	기본 타입의 값을 내부에 두고 포장
	 * 	포장하고 있는 기본 타입 값은 외부에서 변경할 수 없고, 단지 객체를 생성하는 목적
	 * 	byte, char, short, int, long, float, double, boolean 기본 타입 값 갖는 객체
	 * wrapper 클래스
	 * 	내부적으로 기본형(primitive type) 변수를 가지고 있다
	 * 	값을 비교하도록 equals()가 오버라이딩되어 있다
	 * 
	 * Boxing 과 UnBoxing
	 *  박싱 : 기본 타입의 값을 포장 객체로 만드는 과정
	 *  	  포장 클래스 변수에 기본 타입 값이 대입 시 발생
	 *  언박싱 : 포장 객체에서 기본 타입의 값을 얻어내는 과정
	 *  		기본 타입 변수에 포장 객체가 대입 시 발생
	 * 
	 * Calendar 와 Date
	 * 	java.util.Date (특정 시점의 날짜, 시간)
	 * 		날짜와 시간을 다룰 목적으로 만들어진 클래스 (JDK1.0)
	 * 		Date 의 메서드는 거의 deprecated 되었지만, 여전히 쓰이고 있다
	 * 
	 * 	java.util.Calendar (날짜, 시간)
	 * 		Date 클래스를 개선한 새로운 클래스(JDK1.1) 여전히 단점이 존재
	 * 	
	 * 	java.time 패키지 (날짜, 시간 분리)
	 * 		Date 와 Calendar 의 단점을 개선한 새로운 클래스들을 제공 (JDK1.8)
	 * 
	 * Date 클래스
	 * 	날짜를 표현하는 클래스
	 * 	Date 객체 간 날짜 정보 주고받을 때 매개 변수나 리턴 타입으로 주로 사용
	 * 	Date() 생성자는 컴퓨터의 현재 날짜를 읽어 Date 객체로 만듦
	 * 	원하는 날짜 형식의 문자열 얻기 위해 java.text 패키지의 SimpleDateFormat 클래스와 함께 사용
	 * 	
	 * Calendar 클래스
	 * 	java.util.Calendar
	 * 		달력을 표현하는 추상 클래스
	 * 		추상 클래스이므로 getInstance()를 통해 주현된 객체를 얻어야 한다
	 * 		getInstance() 메소드로 컴퓨터에 설정된 시간대 기준으로 Calendar 하위 객체를 얻을 수 있음
	 * 		Calendar cal =Calendar.getInstance();
	 * 
	 * Calendar 의 주요 메서드 - get()
	 * 	get()으로 날짜와 시간 필드 가져오기 - int get(int field)
	 * 	Calendar 에 정의된 필드
	 * 		필드명			설명
	 * 		YEAR			년
	 * 		MONTH			월(0부터)
	 * 		WEEK_OF_YEAR	1월1일부터~지금까지 몇번째 주인지 계산
	 * 		WEEK_OF_MONTH	그 달의 몇 번째 주
	 * 		DATE			일
	 * 		DAY_OF_MONTH	그 달의 몇 번째 일
	 * 		DAY_OF_YEAR		그 해의 몇 번째일
	 * 		DAY_OF_WEEK		요일
	 * 	DAY_OF_WEEK_IN_MONTH 그 달의 몇 번째 요일
	 * 		HOUR			시간(0~11)
	 * 		HOUR_OF_DAY		시간(0~23
	 * 		MINUTE			분
	 * 		SECOND			초
	 * 		MILLISECOND		천분의 일 초
	 * 		ZONE_OFFSET		GMT기준 시차(천분의 일 초)
	 * 		AM_PM			오전/오후
	 * 	
	 * Calendar 의 주요 메서드 - set()
	 * 		
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * */
	
	
}
