package day0305;

import java.util.Arrays;

class Dice {
	private int cnt; // 주사위면의 개수
	public Dice(int cnt) {
		this.cnt = cnt;
	}
	public int roll() {
		return (int)(Math.random()*cnt)+1;
	}
}


public class MathRandomExample1 {
	public static void main(String[] args) {
		
		//주사위 2개를 100번 던져서 주사위의 합이 가장 많이 나오는 결과와
		//가장 적게 나오는 결과를 출력
		
		Dice diceA = new Dice(6);
		Dice diceB = new Dice(6);
		
		int[] result = new int[13];
		
		for (int i=1; i<=100; i++) {
			int dice1 = diceA.roll();
			int dice2 = diceB.roll();
			int count = dice1+dice2;
			result[count]++;
		}
		System.out.println(Arrays.toString(result));
		for (int i=2; i<result.length; i++ ) {
			System.out.println(i+" : "+result[i]); 
		}
		
		int max = result[2];
		int min = result[2];
		int maxCnt = 0;
		int minCnt = 0;
		for (int i=2; i<result.length; i++) {
			if (max<result[i]) {
				maxCnt = i;
				max = result[i];
			} else if (min>result[i]) {
				minCnt = i;
				min= result[i];
			}
		}
		System.out.printf("최대 출력 : %d(%d)\n",maxCnt,max);
		System.out.printf("최소 출력 : %d(%d)\n",minCnt,min);
	}
}
