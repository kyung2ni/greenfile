package day0305;

import java.util.Scanner;
import java.util.StringTokenizer;

public class MathExample222 {
	public static void main(String[] args) {
		//랜덤으로 배열안의 글자가 선택되고
		//글자를 맞추는 게임
		//10번이상 시도하면 정답을 알려줌
		
		//1. 단어를 랜덤으로 선택 Math.random()
		//2. 선택된 단어의 글자 길이만큼 밑줄을 표시
		//3. 사용자에게 글자를 입력받고
		//	입력받은 글자가 단어에 포함되어있으면
		//	밑줄을 글자로 변경
		//	횟수 증가
		//4. 글자를 모두 맞췄으면 횟수와 함께 정답이라고 출력하고 종료
		
		Scanner scan = new Scanner(System.in);
		int rnd = (int) (Math.random()*6); //랜덤 배열 글자 선택
		
		String[] words = {"java","school","programmer","book","green","example"};

		//length : 속성 배열의 길이를 반환
		int index = (int)(Math.random() * words.length);
//		System.out.println(words[index]);
		String solution = words[index];
		
		//length() : 메서드. 길이를 반환
		StringBuffer answer = new StringBuffer(solution.length());
		for (int i=0; i<solution.length(); i++) {
			answer.append("_");
		}
		
//		System.out.println(answer);
		int cnt=0;
		while(true) {
			
			if (solution.equals(answer.toString())) {
				System.out.println("정답입니다");
				System.out.println(cnt+"번 만에 맞췄습니다");
				break;
			} else if (cnt >=10) {
				System.out.println("정답은"+solution+"입니다");
				break;
			}
			System.out.println("현재의 상태 : "+answer);
			System.out.print("글자를 추측하시오 : ");
			char c = scan.next().charAt(0);
			for (int i=0; i<solution.length(); i++) {
				if(c == solution.charAt(i) ) {
					//replace(인덱스 이상, 인덱스 미만, 해당 문자로 변경)
					answer.replace(i, i+1, String.valueOf(c));
				}
			}
			cnt++;
			System.out.println(answer);
		}

	}
}
