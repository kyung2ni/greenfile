package day0305;

import java.util.StringTokenizer;

public class StringBuffer1 {
	public static void main(String[] args) {
		StringBuilder sb = new StringBuilder(); //변경이 잦은 경우
		sb.append("hello");
		sb.append(" ");
		sb.insert(0,"java"); //0번째 위치에 들어감
		
		String result = sb.toString();
		System.out.println(result);
		
		System.out.println(sb.substring(0,4));
		
		String str = ""; //변경이 거의 없는 경우
		str += "hello";
		str += " ";
		str += "java";
		System.out.println(str);
		
		System.out.println("--------------------------------------");
		
		String s = "안녕하세요!반갑습니다~잘부탁드려요~하하하하!";
		StringTokenizer st = new StringTokenizer(s,"!~");
		
		while(st.hasMoreTokens()) {
			System.out.println(st.nextToken());
		}
	}
}
