package day0305;

public class SystemExit {
	public static void main(String[] args) {
		
		for(int i=0; i<10; i++) {
			System.out.println(i);
			if(i == 5) {
				//break; //반복문 실행 강제 종료
				//return; //메서드의 실행 강제 종료
				//System.exit(0); //프로그램 강제 종료(정상종료)
				System.exit(1); //프로그램 강제 종료(비정상종료)
			}
		}
		System.out.println("끝");
	}
}
