package day0219;

import java.util.Scanner;

public class Array2DExample3 {

	public static void main(String[] args) {
		
		
		String[][] type = {
							{"boolean", "1"},
							{"char", "2"},
							{"byte", "1"}, //type[2][0] , type[2][1]
							{"short", "2"},
							{"int", "4"},
							{"long", "8"},
							{"float", "4"},
							{"double", "8"}
		};
		System.out.println("----------기본형의 크기는?----------");
		Scanner scan = new Scanner(System.in);
		int count = 0;
		
		
		for (int i=1; i<=5; i++) {
			int Q = (int) (Math.random()*type.length);
//			System.out.println("Q"+i+". "+type[Q][0]+"의 길이는?");
			System.out.printf("Q%d. %s의 길이는?",i,type[Q][0]);
			String tmp = scan.nextLine();
			
			if (tmp.equals(type[Q][1])) {
				System.out.println("정답입니다. \n");
				count++;
			} else {
				System.out.println("틀렸습니다. 정답은"+ type[Q][1]+"입니다\n");
			}
		
		}
		System.out.println("정답 횟수 : "+count);
	}
}

