package day0219;

import java.util.Arrays;

public class ArrayExample3 {

	public static void main(String[] args) {
		
		//길이가 10인 배열을 만들어
		//0	부터 9까지의 임의의 값을 각 배열에 저장하고
		//0 부터 9까지의 숫자가 몇번 나오는지 출력

		int[] arr = {0,0,0,0,0,0,0,0,0,0}; //길이가 10인 배열 생성
		int[] counter = new int[10];
		
		for (int i=0; i<arr.length; i++) { //임의의 값 각 배열에 저장
			int rnd = (int) (Math.random()*10);
			arr[i] += rnd;  
			
		}
		
		System.out.println(Arrays.toString(arr));
		
		for (int i=0; i<arr.length; i++) {
			int count = 0; //카운트 초기화
			
			for (int j=0; j<arr.length; j++) {
				if (i == arr[j]) {
					count++; // 각 배열에 개수 추가
				}	
			}
			
			System.out.println(i+"의 개수 : "+count); //각 배열 개수 출력
		}
		System.out.println("==================================");
		
		for (int i=0; i<arr.length; i++) {
			counter[arr[i]]++;  
		}
		
		for (int i=0; i<arr.length; i++) {
			System.out.println(i+"의 개수 : "+counter[i]);
		}
		
	}
}
