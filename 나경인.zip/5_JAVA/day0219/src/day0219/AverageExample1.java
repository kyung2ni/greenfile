package day0219;

public class AverageExample1 {

	public static void main(String[] args) {
		
		int[] scores = { 80, 65, 99, 35, 88, 70,  40, 50};
		int sum =0;
		for (int i=0; i<scores.length; i++) {
			sum += scores[i];
		}
		
		
		
		double avg = (double) sum / scores.length;
		System.out.println("평균 :"+avg);
		
		int max =scores[0];
		int min =scores[0];
		
		for (int i=1; i<scores.length; i++) {
			if (scores[i] >max) {
				max = scores[i];
			} else if (scores[i]<min) {
				min = scores[i];
			}
		}
		System.out.println("최대값 :" + max);
		System.out.println("최소값 :" + min);
	}

}
