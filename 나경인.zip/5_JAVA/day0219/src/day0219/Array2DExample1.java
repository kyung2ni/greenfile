package day0219;

public class Array2DExample1 {

	public static void main(String[] args) {
		
		int[][] arr1 = new int[][] {{10, 20, 30},{40, 50, 60}}; //첫번째 방법
		
		int[][] arr2 = {{10, 20, 30},{40, 50, 60}}; //두번째 방법 new 생략
		
		int[][] arr3 = { //세번째 방법 가변배열
						{10, 20, 30},
						{40, 50, 60, 100},
						{70, 80, 90}
		};
		
		System.out.println(arr3[1][3]);
		
		int[][] arr4 = { 
						{11, 12, 13, 14, 15, 16},
						{25, 26, 27},
						{33, 34, 35, 36},
						{47, 48}
		};
		System.out.println(arr4[1].length);
		
		int[][] arr5 = { 
						{10, 20, 30},
						{40, 50, 60},
						{70, 80, 90}
		};
		for (int i=0; i<arr5.length; i++) {
			for (int j=0; j<arr5[i].length; j++) {
				System.out.printf("arr5[%d][%d]=%d\n",i,j,arr5[i][j]);
			}
		}
	}
	
}
