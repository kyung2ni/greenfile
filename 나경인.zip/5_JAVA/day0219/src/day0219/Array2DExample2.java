package day0219;

public class Array2DExample2 {

	public static void main(String[] args) {
		int korTotal = 0;
		int engTotal = 0;
		int mathTotal = 0;
		
		int[][] score = {
				{100,50,76},
				{28,90,62},
				{85,31,99},
				{88,77,36},
				{56,95,88}
		};
		System.out.println("번호  국어   영어    수학   총점   평균");
		System.out.println("==================================");
		
		for (int i=0; i<score.length; i++) {
			int sum = 0;
			double avg = 0.0;
			
			korTotal += score[i][0];
			engTotal += score[i][1];
			mathTotal += score[i][2];
			
			System.out.printf("%d",i+1);
			for (int j=0; j<score[i].length; j++) {
				sum += score[i][j];
				System.out.printf("%6d", score[i][j]);
				
				
			}
			avg = (double) sum / score[i].length;
			System.out.printf("%6d  %5.1f",sum,avg);
			
			System.out.println();
		}
		
		double korAvg = (double)korTotal / score.length;
		double engAvg = (double)engTotal / score.length;
		double mathAvg = (double)mathTotal / score.length;
		
		System.out.println("==================================");
		System.out.printf("총점 :%3d %5d %5d \n",korTotal,engTotal,mathTotal);
		System.out.printf("평균 :%3.1f %5.1f %5.1f \n",korAvg,engAvg,mathAvg);
		

		
		
		
	}
}
