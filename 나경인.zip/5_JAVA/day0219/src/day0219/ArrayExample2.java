package day0219;

import java.util.Arrays;

public class ArrayExample2 {

	public static void main(String[] args) {
		
		int[] ballArr = {1,2,3,4,5,6,7,8,9};
		int[] ball3 = new int[3];
		
		//1부터 9까지 사이의 중복되지 않은 숫자로 이루어진
		//3자리 수를 ball3에 저장하고 출력하시오.
		for (int i=1; i<ballArr.length; i++) {
			int rnd = (int)(Math.random()*ballArr.length);
			int tmp = ballArr[i];
			ballArr[i] = ballArr[rnd];
			ballArr[rnd] = tmp;
		}
		System.out.println(Arrays.toString(ballArr));
		System.arraycopy(ballArr, 0, ball3, 0, 3);
		
		for (int i=0; i<ball3.length; i++) {
			System.out.print(ball3[i]); 
		}
		
		
		
	}
}
