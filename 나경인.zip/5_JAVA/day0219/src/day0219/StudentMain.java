package day0219;

public class StudentMain {

	public static void main(String[] args) {
		
		//정수를 저장하는 a변수
		//int a;
		
		//Student를 저장하는 s변수
		Student s;
		s = new Student();
		
		s.name = "김그린";
		s.age = 22;
		s.addr = "울산시 남구 삼산동";
		
		s.studentInfo();
		
		Student s2;
		s2 = new Student();
		s2.name = "이자바";
		s2.age = 33;
		s2.addr= "울산시 중구 성남동";
		
		s2.studentInfo();
	}

}
