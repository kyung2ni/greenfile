package day0219;

import java.util.Arrays;

public class ArrayCopyExample1 {

	public static void main(String[] args) {
		
		int[] number = {1,2,3,4,5};
		int[] newNumber = new int[10];
		
		for (int i=0; i<number.length; i++) {
			newNumber[i] = number[i];
		}
		System.out.println(Arrays.toString(newNumber));
		
		String[] oldStr = {"java", "array","copy"};
		String[] newStr = new String[5];
		
		
		
	}
	
}
