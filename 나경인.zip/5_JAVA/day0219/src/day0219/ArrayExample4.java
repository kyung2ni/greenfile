package day0219;

public class ArrayExample4 {

	public static void main(String[] args) {
		
		//딱정벌레
		
	}
	
}
