package day0219;

import java.util.Arrays;

public class ArrayExample1 {
	
		public static void main(String[] args) {
			
			int[] numArr = {0,1,2,3,4,5,6,7,8,9};
			
			System.out.println(Arrays.toString(numArr));
			
			//순서 섞어서 출력
			//1.n번째 값과 맞바꾸기
			//2.처음에 있는 값과 랜덤 위치에 있는 수를 바꾸기
			
			
			
			for (int i=0; i<numArr.length; i++) {
				int rnd = (int)(Math.random()*10);
				int tmp = numArr[i];
				numArr[i] = numArr[rnd];
				numArr[rnd] = tmp;
			}
			System.out.println(Arrays.toString(numArr));
			
			for (int i=0; i<100; i++) {
				int rnd= (int) (Math.random()*10);
				int tmp = numArr[0];
				numArr[0] = numArr[rnd];
				numArr[rnd] = tmp;
			}
			System.out.println(Arrays.toString(numArr));
			
			
		}
}
