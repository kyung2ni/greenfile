package day0219;

public class TvTest1 {

	public static void main(String[] args) {
		
		Tv t;
		t = new Tv();
		
		t.channel = 7;
		t.volume = 10;
		
		System.out.printf("Tv1의 채널은 %d이고 볼륨은 %d입니다\n",t.channel,t.volume);
		
		t.channelUp();
		
		System.out.printf("Tv1의 채널은 %d이고 볼륨은 %d입니다\n",t.channel,t.volume);
		
		Tv t2 = new Tv();
		
		System.out.printf("Tv2의 채널은 %d이고 볼륨은 %d입니다\n",t2.channel,t2.volume);
		
		Tv t3 = new Tv();
		Tv t4 = new Tv();
		
		t4 = t3; //값이 아닌 주소 저장
		t3.channel = 3;
		System.out.println("t3의 channel : "+ t3.channel); //3
		System.out.println("t4의 channel : "+ t4.channel); //0
		
	}
	
}
