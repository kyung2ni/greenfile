package day0223;

public class Drama {
	private String name;
	private String genre;
	private String author; 
	private static int count;
	
	Drama() {}
	
	public Drama(String name,String genre,String author) {
		this.name = name;
		this.genre = genre;
		this.author = author;
		
		count++;
	}
	public void print() {
		System.out.printf("Webtoon {제목 : %s, 장르 : %s, 작가 : %s}\n",name,genre,author);
	}
	
	public static int getCount() {
		return count;
	}
//	public static void Count() {
//		System.out.println("총 드라마의 수 : "+count);
//		return;
//	}
//	
}
