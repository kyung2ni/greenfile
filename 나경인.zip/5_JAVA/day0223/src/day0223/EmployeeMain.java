package day0223;

public class EmployeeMain {
	public static void main(String[] args) {
		Employee e1 = new Employee("김그린",100);
		Employee e2 = new Employee("이자바",200);
		Employee e3 = new Employee("정디비",300);
		
		e1 = null;
		System.gc();
		
		System.out.println(e1);
		System.out.println(e2);
		System.out.println(e1==e2);
		//가비지 컬렉터 강제 동작
		System.out.println("직원수 : "+Employee.getCount());
		

		
	}
}
