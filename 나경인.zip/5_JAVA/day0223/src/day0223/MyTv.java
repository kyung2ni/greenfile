package day0223;

public class MyTv {
	private boolean isPowerOn; //전원
	private int channel; //채널
	private int volume;	 //볼륨
	private int prev;
	
	final int MAX_VOLUME = 100;
	final int MIN_VOLUME = 0;
	final int MAX_CHANNEL = 100;
	final int MIN_CHANNEL = 0;
	
	//이전 채널로 이동하는 기능의 메서드를 추가하시오.
	//메서드명 : gotoPrevChannel
	//기능 : 현재 채널을 이전채널로 변경한다.
	//반환타입 : 없음
	public void gotoPrevChannel() {
		setChannel(prev);	
	}
	
	public boolean getIsPowerOn() {
		return isPowerOn;
	}
	public void setIsPowerOn(boolean isPowerOn) {
		this.isPowerOn = isPowerOn;
	}
	public int getChannel() {
		return channel;
	}
	public void setChannel(int channel) {
		if (channel < MIN_CHANNEL || channel > MAX_CHANNEL) {
			return;
		}
		prev = this.channel;
		this.channel = channel;
	}
	public int getVolume() {
		return volume;
	}
	public void setVolume(int volume) {
		if (volume < MIN_VOLUME || volume > MAX_VOLUME) {
			return;
		}
		this.volume = volume;
	}
//	public void setChannelVolume(int channel,int volume) {
//		if (channel>=MIN_CHANNEL &&channel<=MAX_CHANNEL) {
//			this.channel = channel;
//		} else {
//			System.out.println("채널은 0-100까지");
//		}
//		if (volume>=MIN_VOLUME &&volume<=MAX_VOLUME) {
//			this.volume = volume;
//		} else {
//			System.out.println("볼륨은 0-100까지");
//		}
//	}

	//MyTv클래스의 멤버변수를
	//클래스 외부에서 접근할 수 없도록 설정하고
	//메서드를 통해 접근하도록 하시오
	//단 채널과 볼륨은 0부터 100사이의 값만 입력 가능함
}
