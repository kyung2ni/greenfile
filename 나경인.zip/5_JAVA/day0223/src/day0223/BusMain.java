package day0223;

class Bus{
	private int num;
	private int count;
	
	public void setNumCount(int num,int count) {
		if (count >=0 && count<=45) {
			this.num = num;
			this.count = count;
			System.out.printf("차량번호 : %d 탑승인원 : %d\n",num,count);
		} else {
			System.out.println("탑승인원은 0~45만 가능합니다.");
		}
	}
	public void show() {
		System.out.println("차량번호 : "+num);
		System.out.println("탑승 인원 : "+count);
	}
}

public class BusMain {
	public static void main(String[] args) {
		Bus bus1 = new Bus();
		//num, count가 private 이므로 접근 불가능
//		bus1.num = 2200;
//		bus1.count = 2200;
		
		bus1.setNumCount(2200,20);
		bus1.show();
	}
}
