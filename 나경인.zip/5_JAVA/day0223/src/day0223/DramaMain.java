package day0223;

public class DramaMain {
	public static void main(String[] args) {
		Drama d1 = new Drama("스위트홈","스릴러","김달콤");
		Drama d2 = new Drama("이재, 곧 죽습니다","판타지","서이재");
		Drama d3 = new Drama("비밀의 비밀","드라마","이비밀");
		
		Drama[] dramas = {d1,d2,d3};
		
//		for (int i=0; i<dramas.length; i++) {
//			dramas[i].print();
//		}
		
		for (Drama d: dramas) {
			d.print();
		}
		
		
		
//		d1.print();
//		d2.print();
//		d3.print();
		
		System.out.println("총 드라마의 수 : "+Drama.getCount());
	}
}
