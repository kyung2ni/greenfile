package day0223.package1; //A와 같은 패키지

public class B {
	public static void main(String[] args) {
		A a =new A();
		System.out.println(a.pub);	//O	(제한없음)
		System.out.println(a.pro);	//O	(같은 패키지+다른패키지 자손)
		System.out.println(a.def);	//O	(같은 패키지)
//		System.out.println(a.pri);	//X	(같은 클래스)
	}
}
