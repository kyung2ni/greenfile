package day0223.package1;

public class A {

	public int pub;		//제한없음
	protected int pro; 	//같은 패키지 + 다른 패키지 자손
			int def;	//같은 패키지
	private int pri;	//같은 클래스
	
	public void printMembers() {
		System.out.println(pub); 	//O
		System.out.println(pro);	//O
		System.out.println(def);	//O
		System.out.println(pri);	//O
	}
	
}
