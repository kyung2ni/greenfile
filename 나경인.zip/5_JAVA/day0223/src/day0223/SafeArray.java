package day0223;

public class SafeArray {
	private int a[];
	public int length;
	
	SafeArray() {}
	public SafeArray(int size) {
		a= new int[size];
		length = size;
	}
	public int getNum(int index) {
		if (index >=0 && index <length) {
			return a[index];
		}
		return -1;
	}
	public void setNum(int index,int value) {
		if (index >=0 &&index <length) {
			a[index] = value;
		} else {
			System.out.println("잘못된 인덱스");
		}
	}
}
