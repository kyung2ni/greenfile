package day0223;

class Static1 {
	static double pi=3.14159; //클래스변수
	
	int a = 10;
	
	static int plus(int x,int y) { //클래스 메서드
		Static1 s = new Static1();
		return x+y+s.a;
	}
	
	static int minus(int x , int y) { //클래스 메서드
		return x-y;
	}
}

public class StaticTest {
	int a;
	
	void print() {
		System.out.println("출력");
	}
	public static void main(String[] args) {
		StaticTest st = new StaticTest();
		st.a = 10;
		
		Static1 s = new Static1();
		
		int result1= Static1.plus(10,5);
		int result2 = Static1.minus(10,5);
		double result3 = 10*s.pi;
		
		System.out.println(result1);
		System.out.println(result2);
		System.out.println(result3);
	}
}
