package day0223;

public class MyTvTest1 {
	public static void main(String[] args) {
		MyTv t = new MyTv();
		
		t.setChannel(10);
		System.out.println("ch : "+t.getChannel());
		t.setChannel(20);
		System.out.println("ch : "+t.getChannel());
		
		t.gotoPrevChannel();
		System.out.println("prevCh : "+t.getChannel());
		
		t.gotoPrevChannel();
		System.out.println("prevCh : "+t.getChannel());
		
		t.setVolume(10);
		System.out.println("vol : "+t.getVolume());
		
		
		
		
		
	}
	
}
