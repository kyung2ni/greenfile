package day0223;

public class SingleTestMain {
	public static void main(String[] args) {
		SingleTest t = SingleTest.getInstance();
		
		System.out.println("x : "+t.getX());
		System.out.println("y : "+t.getY());
		
		SingleTest t1 = SingleTest.getInstance();
		SingleTest t2 = SingleTest.getInstance();
		t1.setX(1000);
		
		System.out.println("t1.x : "+t1.getX());
		System.out.println("t2.x : "+t2.getX());
	}
}
