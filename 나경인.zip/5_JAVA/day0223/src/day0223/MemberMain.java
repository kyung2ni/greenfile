package day0223;

public class MemberMain {
	public static void main(String[] args) {
		Member m = new Member();
		
		m.setName("김그린");
		m.setTel("010-1111-2222");
		m.setAddress("울산시 남구");
		
		String name = m.getName();
		String tel = m.getTel();
		String address = m.getAddress();
		
		System.out.println(name);
		System.out.println(tel);
		System.out.println(address);
	}
}
