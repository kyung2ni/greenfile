package day0223;

public class Singleton {
	
	//3. 객체를 다른 클래스에서 사용할 수 없도록 private 로 설정
	//5. static 메서드에서 사용하기 위해서 static 추가
	private static Singleton single = new Singleton();
	
	//싱글톤 : 인스턴스가 딱 1개만 생성되어야 하는 경우에 사용
	//1.생성자를 private 으로 설정
	private Singleton() {
		
	}
	//4. 리턴타입이 Singleton 인 메서드 생성
	//	객체를 생성하기 위한 메서드이므로
	//	객체 생성없이 사용하기 위해서 static 메서드로 설정
	static Singleton getInstance() {
		return single;
	}
}
