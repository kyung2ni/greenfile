package day0223;

public class SafeArrayMain {
	public static void main(String[] args) {
		
		SafeArray array = new SafeArray(3);
		
		for (int i=0; i<array.length; i++) {
			array.setNum(i,  i*10);
			System.out.println(array.getNum(i));
		}
		array.setNum(0, 10);
		array.setNum(1, 20);
		array.setNum(2, 30);
		
		System.out.println(array.getNum(1)); 
	}
}
