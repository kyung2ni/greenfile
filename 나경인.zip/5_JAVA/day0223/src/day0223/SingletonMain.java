package day0223;

public class SingletonMain {
	public static void main(String[] args) {
		//2.생성자가 private 이므로 인스턴스 생성 불가
//		Singleton obj1 = new Singleton();
//		Singleton obj2 = new Singleton();
		
		//6. 인스턴스 확인
		Singleton obj3 = Singleton.getInstance();
		Singleton obj4 = Singleton.getInstance();
		
		//7. 동일한 주소 확인
		System.out.println(obj3);
		System.out.println(obj4);
	}
}
