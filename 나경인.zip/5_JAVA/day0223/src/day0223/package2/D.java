package day0223.package2;

import day0223.package1.A;

public class D {
	public static void main(String[] args) {
		A a = new A();
		System.out.println(a.pub);	//O	(제한없음)
//		System.out.println(a.pro);	//X	(같은 패키지+다른패키지 자손)
//		System.out.println(a.def);	//X	(같은 패키지)
//		System.out.println(a.pri);	//X	(같은 클래스)
	}
}
