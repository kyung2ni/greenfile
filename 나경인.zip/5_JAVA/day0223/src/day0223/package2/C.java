package day0223.package2;	//A와 다른 패키지

import day0223.package1.A;

public class C extends A{

	public void printMembers() {
		System.out.println(pub); 	//O
		System.out.println(pro);	//O
//		System.out.println(def);	//X(같은 패키지)
//		System.out.println(pri);	//X(같은 클래스)
	}
}
