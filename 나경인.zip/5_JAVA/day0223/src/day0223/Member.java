package day0223;

public class Member {
	private String name;
	private String tel;
	private String address;
	
	public void printMember() {
		System.out.println("name : "+name);
		System.out.println("tel : "+tel);
		System.out.println("address : "+address);
	}
	
	//멤버변수의 값을 읽어오는 메서드 : get멤버변수이름
	//멤버변수의 값을 변경하는 메서드 : set멤버변수이름
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name= name;
	}
	
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel=tel;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address=address;
	}
}
