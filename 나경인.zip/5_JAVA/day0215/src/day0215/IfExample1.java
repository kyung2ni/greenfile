package day0215;

import java.net.MulticastSocket;

public class IfExample1 {

	public static void main(String[] args) {
		String str = "C";
		char ch = 'c';
		
		System.out.println(ch == 'c' || ch == 'C'); //true
		System.out.println(str == "c" || str == "C"); //true
		System.out.println(str.equals("c") || str.equals("C")); //true
		System.out.println(str.equalsIgnoreCase("c")); //true
		
		char num = '4';
		System.out.println(num>='0' && num<= '9'); //true
		System.out.println(!(num>='0' && num<= '9')); //false
		System.out.println(num<'0'||num>'9'); //false
		
		//charAt(인덱스) : 문자열에서 인덱스번째의 문자를 반환(0부터 시작)
		String a = "안녕하세요";
		System.out.println(a.charAt(2)); // 하
		
		//문자형을 숫자로 변경    57 - 48  =  9
		System.out.println('9' - '0'); //9
		
		//문자열을 문자로 변경 
		String str1 = "3";
		char ch1 = 'A';
		if (str1 != null &&!str1.equals("")) {
			ch1 = str1.charAt(0);
		}
		System.out.println(ch1);
	}

}
