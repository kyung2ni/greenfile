package day0215;

import java.util.Scanner;

public class ScannerExample {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
//		String temp = scan.next(); 공백까지만 인식
//		String temp = scan.nextLine(); 
		
		System.out.print("주소 : ");
		String addr = scan.next(); //공백까지만 인식,키보드 버퍼
		
		scan.nextLine();
		
		System.out.print("이름 > ");
		String name = scan.nextLine();
		
		System.out.println(name + "님은 " + addr + "에 삽니다.");
		
		//키보드 버퍼 : 직전에 키보드로부터 입력된 문자를 기억하는 기억장치 
		
	}
}
