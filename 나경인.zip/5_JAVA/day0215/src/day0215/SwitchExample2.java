package day0215;

public class SwitchExample2 {

	public static void main(String[] args) {
		//출근 시간에 따라 스케줄을 표시
		//8시~12시 사이에 출근을 하며 출근 시간은 랜덤으로 결정
		
		//8시 : 출근을 합니다.
		//9시 : 회의를 합니다
		//10시 : 외근을 갑니다.
		//나머지 시간에는 업무를 봅니다
		
		double rnd = Math.random(); //랜덤수 생성
		double time = 8+rnd*5; //8~12 랜덤수 결정
		int time2 = (int) time; //정수로 변환
		System.out.println("[현재시간 : "+ time2 + "시]");
		switch (time2) {
			case 8 :
				System.out.println("8시 : 출근을 합니다.");
			case 9 :
				System.out.println("9시 : 회의를 합니다.");
			case 10 :
				System.out.println("10시 : 외근을 갑니다.");
			default :
				System.out.println("업무를 봅니다.");
//			case 8 :
//				System.out.println("8시 : 출근을 합니다. \n9시 : 회의를 합니다. \n10시 : 외근을 갑니다. \n업무를 봅니다.");
//				break;
//			case 9 :
//				System.out.println("9시 : 회의를 합니다. \n10시 : 외근을 갑니다. \n업무를 봅니다.");
//				break;
//			case 10 :
//				System.out.println("10시 : 외근을 갑니다. \n업무를 봅니다.");
//				break;
//			default :
//				System.out.println("업무를 봅니다.");
		}
		
	}

}
