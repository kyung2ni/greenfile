package day0215;

import java.util.Scanner;

public class IfExample3 {

	public static void main(String[] args) {
		
		//사원이 실적 목표를 달성하였을 결우
		//실적 목표를 초과한 금액의 10%를 성과급으로 받는 프로그램을 작성
		//실적 목표(1000)는 상수로 설정할 것.
		final int TARHET_SALES = 1000;
		
		Scanner scan = new Scanner(System.in);
		System.out.print("실적 입력 > ");
		int input = scan.nextInt();
		
		if (input > TARHET_SALES) {
			System.out.println("보너스 : "+(input-TARHET_SALES)*0.1);
		} else {
			System.out.println("실적 달성 못함.");
		}
	}

}
