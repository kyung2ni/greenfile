package day0215;

import java.util.Scanner;

public class ForExample2 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.print("홀수 입력 > ");
		int num = 7; //scan.nextInt();
		int num2 = num/2+1;
		int num3 = num/2;
		for (int i=1; i<=num2; i++) {
			for (int j=num2; j>i; j--) {
				System.out.print(" ");
			}
			for (int k=0; k<(i*2)-1; k++) {
				System.out.print("*");
			}
			for (int j=num2; j>i; j--) {
				System.out.print(" ");
			}
			System.out.println();
		}
		for (int i=num; i<=num3; i++) {
			for (int j=num3; j>i; j--) {
				System.out.print("+");
			}
			for (int k=num3; k>(i*2); k--) {
				System.out.print("*");
			}
			for (int j=num3; j>i; j--) {
				System.out.print("+");
			}
			System.out.println();
		}
		
	}

}
//for (int j=num3+1; j>i; j--) {
//	System.out.print(" ");
//}
//for (int k=0; k<(i*2)-1; k++) {
//	System.out.print("*");
//}
//for (int j=num3+1; j>i; j--) {
//	System.out.print(" ");
//}
