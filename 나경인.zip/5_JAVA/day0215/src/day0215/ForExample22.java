package day0215;

import java.util.Scanner;

public class ForExample22 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.print("홀수 입력 > ");
		int num = scan.nextInt();
		
		for (int i=0; i<num; i++) {
			for (int j=0; j<num; j++) {
				
				if (i<=num/2) { //위쪽
					if (i+j <= num/2-1) { //왼쪽 상단 공백
						System.out.print("_");
					} else if (j-i >= num/2+1) { //오른쪽 상단 공백
						System.out.print("_");
					} else {
						System.out.print("*");
					}
				} else if (i>num/2) { //아래쪽
					if (i-j >= num/2+1) { //왼쪽 하단 공백
						System.out.print("_");
					} else if (i+j >= num/2*3+1) { //오른쪽 하단 공백
						System.out.print("_");
					} else {
						System.out.print("*");
					}
				}
			}
			System.out.println();
		}
		
		
		
	}

}
//for (int j=num3+1; j>i; j--) {
//	System.out.print(" ");
//}
//for (int k=0; k<(i*2)-1; k++) {
//	System.out.print("*");
//}
//for (int j=num3+1; j>i; j--) {
//	System.out.print(" ");
//}
