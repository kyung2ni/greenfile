package day0215;

public class StringExample {
	public static void main(String[] args) {
		String s1 = "str";
		String s2 = "str";
		String s3 = new String("str");
		String s4 = new String("str");
		
		//==은 주소값을 비교
		//equals 는 값을 비교
		System.out.println(s1 == s2); //true
		System.out.println(s1 == s3); //false
		System.out.println(s1 == s4); //false
		System.out.println(s3 == s4); //false
		
		System.out.println(s1.equals(s2)); //true
		System.out.println(s1.equals(s3)); //true
		System.out.println(s3.equals(s4)); //true
	}
}
