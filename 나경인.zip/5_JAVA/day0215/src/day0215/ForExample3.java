package day0215;

import java.util.Scanner;

public class ForExample3 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.print("홀수 입력 > ");
		int num = scan.nextInt();
		
		if (num%2 ==0 ) {
			System.out.println("홀수를 입력해주세요");
			return;
		}
		
		int middle = num/2;
		
		for(int i =0; i<num; i++) {
			for (int j=0; j<num; j++) {
				
				if (i <= middle) { //상단
					
					if (j< middle-i ||j > middle+i) {
						System.out.print(" ");
					} else {
						System.out.print("*");
					}
					
				} else { //하단
				
					if (j < i-middle || j >= num-(i-middle)) {
						System.out.print(" ");
					} else {
						System.out.print("*");
					}
					
				}
			}
			System.out.println();
		}
		
	}
}

