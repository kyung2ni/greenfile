package day0215;

import java.util.Scanner;

public class SwitchExample1 {

	public static void main(String[] args) {
		//성적을 입력받아 등급을 출력하시오.
		//90-100 : A
		//80-89 : B
		//70-79 : C
		//60-69 : D
		//나머지 : F
		
		Scanner scan = new Scanner(System.in);
		System.out.print("성적 > ");
		int point = scan.nextInt();
		int po = point / 10;
		switch (po) {
			case 10 : 
			case 9 : 
				System.out.println("A");
				break;
			
			case 8 : 
				System.out.println("B");
				break;
			
			case 7 : 
				System.out.println("C");
				break;
			
			case 6 : 
				System.out.println("D");
				break;
			
			default : 
				System.out.println("F");
			
		}
	}
}
