package day0215;

import java.util.Scanner;

public class IfExample2 {
	public static void main(String[] args) {
		
		//키보드로 영문자를 입력받고
		//입력된 문자가 대문자이면 소문자로 출력
		//소문자이면 대문자로 출력
		//그 외 문자이면 '입력데이터오류'라고 표시할 것.

		Scanner scan = new Scanner(System.in);
		System.out.print("영문자 입력 > ");
		String word = scan.nextLine();
		
		char c = word.charAt(0); //입력받은 내용에서 첫글자를 가져와 저장
		if (c>=65 && c<=90) {
			System.out.println(word.toLowerCase());
		} else if (c>=97 && c<=122) {
			System.out.println(word.toUpperCase());
		} else {
			System.out.println("입력데이터 오류");
		}
	}
}
