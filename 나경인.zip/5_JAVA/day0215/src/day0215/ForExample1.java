package day0215;

import java.util.Scanner;

public class ForExample1 {
	public static void main(String[] args) {
		//숫자를 입력받아서 1부터 해당숫자까지의
		//짝수합 : ####
		//홀수합 : ####
		//총합계 : ####
		int eSum=0,oSum=0,tSum=0;
		Scanner scan = new Scanner(System.in);
		System.out.println("숫자를 입력하세요 > ");
		int num = scan.nextInt();
		
		for (int i=1; i<=num; i++) {
			if (i %2 ==0) {
				eSum += i;
			} else {
				oSum += i;
			}
			tSum += i;
		}
		System.out.printf("짝수합 : %,d\n",eSum);
		System.out.printf("홀수합 : %,d\n",oSum);
		System.out.printf("총합계 : %,d\n",tSum);
	}
}
