package day0307;

import java.net.MulticastSocket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CollectionsExample1 {
	public static void main(String[] args) {
		List list = new ArrayList();
		
		System.out.println(list);
		
		//컬렉션에 값 추가
		System.out.println();
		System.out.println("컬렉션에 값 추가");
		Collections.addAll(list, 1,2,3,4,5);
		System.out.println(list);
		
		//오른쪽으로 숫자만큼 이동
		System.out.println();
		System.out.println("오른쪽으로 숫자만큼 이동");
		Collections.rotate(list, 2);
		System.out.println(list);
		
		//0번과 2번 인덱스를 교환
		System.out.println();
		System.out.println("0번과 2번 인덱스를 교환");
		Collections.swap(list, 0, 2);
		System.out.println(list);
		
		//랜덤으로 섞어주기
		System.out.println();
		System.out.println("랜덤으로 섞어주기");
		Collections.shuffle(list);
		System.out.println(list);
		
		//오름차순으로 정렬
		System.out.println();
		System.out.println("오름차순으로 정렬");
		Collections.sort(list);
		System.out.println(list);
		
		//기존값을 역순으로 정렬
		System.out.println();
		System.out.println("기존값을 역순으로 정렬");
		Collections.sort(list, Collections.reverseOrder());
		System.out.println(list);
		
		//3이 저장된 위치(index)로 나타냄
		//정렬이 되어있어야 함.
		System.out.println();
		System.out.println("3이 저장된 위치(index)로 나타냄");
		int idx = Collections.binarySearch(list, 3);
		System.out.println("3의 위치 : "+idx);
		
		//최대값, 최소값
		System.out.println();
		System.out.println("최대값, 최소값");
		System.out.println("max : "+Collections.max(list));
		System.out.println("min : "+Collections.min(list));
		System.out.println("min : "+Collections.max(list,Collections.reverseOrder()));
		
		//list 를 9로 채움
		System.out.println();
		System.out.println("list 를 9로 채움");
		Collections.fill(list, 9);
		System.out.println("list : "+list);
		
		//list 와 같은 size 의 새로운 list 를 생성하고 2로 채움
		System.out.println();
		System.out.println("list 와 같은 size 의 새로운 list 를 생성하고 2로 채움");
		List newList = Collections.nCopies(list.size(),2);
		System.out.println("newList : "+newList);
		
		//두 컬렉션을 비교(공통요소가 없으면 true)
		System.out.println();
		System.out.println("두 컬렉션을 비교(공통요소가 없으면 true)");
		System.out.println(Collections.disjoint(list, newList));
		
		//list 에 newList 를 복사함
		System.out.println();
		System.out.println("list 에 newList 를 복사함");
		Collections.copy(list, newList);
		System.out.println("newList : "+newList);
		System.out.println("list : "+list);
		
		//list 에서 2를 모두 1로 바꿈
		System.out.println();
		System.out.println("list 에서 2를 모두 1로 바꿈");
		Collections.replaceAll(list, 2, 1);
		System.out.println(list);
	}
}
