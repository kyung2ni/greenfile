package day0307;

import java.net.MulticastSocket;
import java.util.ArrayList;

class Item {
	String name;
	int price;
	
	Item(String name, int price) {
		this.name = name;
		this.price = price;
	}
	public String toString() {
		return "Item{ name : "+ name + ", price : "+price+"}"; 
	}
	
}

public class ArrayListExample5 {
	public static void main(String[] args) {
		//이름과 가격을 저장하는 Item 클래스를 생성하여
		//장바구니 품목을 입력하고
		//ArrayList 객체를 통해 다음과 같이 출력하시오
		
		//장바구니 품목
		//이름		가격
		//티셔츠		49900
		//면바지		58900
		//스니커즈		46900
		
		//출력 결과
		//item{name : 티셔츠, price : 49900}
		//item{name : 면바지, price : 58900}
		//item{name : 스니커즈, price : 46900}
		//------------------------------------------
		//총합 : 155700
		
		Item item1 = new Item("티셔츠",49900);
		Item item2 = new Item("면바지",58900);
		Item item3 = new Item("스니커즈",46900);
		
		ArrayList<Item> cart = new ArrayList();
		
		cart.add(item1);
		cart.add(item2);
		cart.add(item3);
		
		int sum=0;
		for (int i=0; i<cart.size(); i++) {
			System.out.println(cart.get(i));
			sum += cart.get(i).price;
		}
		System.out.println("----------------------");
		System.out.println("총합 : "+sum);
		
//		
//		System.out.println("item{name : "+list1.get(0)+", price : "+list1.get(1)+"}" );
//		System.out.println("item{name : "+list2.get(0)+", price : "+list2.get(1)+"}" );
//		System.out.println("item{name : "+list3.get(0)+", price : "+list3.get(1)+"}" );
//		System.out.println("총합 : "+(item1.price+item2.price+item3.price));
		
		
	}
}
