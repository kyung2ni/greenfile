package day0307;

import java.util.ArrayList;

public class ArrayExample {
	public static void main(String[] args) {
		int[] arr = new int[100];
		System.out.println("배열 크기 : "+arr.length);
		
		ArrayList list = new ArrayList(1);
		list.add(10);
		list.add(20);
		System.out.println("list크기 : "+list.size());
	}
}
