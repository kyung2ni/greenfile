package day0307;

public class aaa {
	/*
	 * 열거형  -> 한정된 값만 가짐 상수 선언
	 * 	관련된 상수들을 같이 묶어 놓은 것. java 는 타입에 안전한 열거형을 제공
	 * 
	 * 열거형 정의와 사용
	 * 	열거형 정의하는 방법
	 * 	enum 열거형이름 {상수1, 상수2, ...} 
	 * 
	 * 컬렉션 프레임워크(collections framework)
	 * 	컬렉션(collection)
	 * 		여러 객체(데이터)를 모아 놓은 것을 의미
	 * 	프레임워크(framework)
	 * 		표준화, 정형화된 체계적인 프로그래밍 방식
	 * 	컬렉션 프레임워크(collections framework)
	 * 		컬렉션(다수의 객체)을 다루기 위한 표준화된 프로그래밍 방식
	 * 		컬렉션을 쉽고 편리하게 다룰 수 있는 다양한 클래스를 제공
	 * 		java.util 패키지에 포함. JDK1.2 부터 제공
	 * 		- 널리 알려진 자료구조를 바탕으로 객체들을 효율적으로 추가, 삭제, 검색할 수 있도록
	 * 			관련 인터페이스와 클래스들을 포함시켜 놓은 java.util 패키지
	 * 		- 프레임워크 : 사용 방법을 정해놓은 라이브러리
	 * 		- 주요 인터페이스로 List, Set, Map 이 있음
	 * 		배열 : 고정 크기 이상의 객체를 관리할 수 없다
	 * 			배열의 중간에 객체가 삭제되면 응용프로그램에서 자리를 옮겨야 한다
	 * 		컬렉션 : 가변 크리고러 객체의 개수를 염려할 필요 없다
	 * 			컬렉션 내의 한 객체가 작제되면 컬렉션이 자동으로 자리를 옮겨준다	
	 * 	
	 * 	컬렉션 클래스(collection class)
	 * 		다수의 데이터를 저장할 수 있는 클래스 (예, Vector,ArrayList,HashSet)
	 * 
	 * 	컬렉션 프레임워크의 핵심 인터페이스
	 * 	Collection
	 * 	List - 순서를 유지하고 저장, 중복 저장 가능
	 * 		구현 클래스 : ArrayList, Vector, LinkedList
	 * 	Set - 순서를 유지하지 않고 저장, 중복 저장 안됨
	 * 		구현 클래스 : HashSet, TreeSet
	 * 	Map - 키와 값으로 구성된 엔트리 저장, 키는 중복 저장 안됨
	 * 		구현 클래스 : HashMap, HashTable, TreeMap, Properties 
	 * 
	 * Collection 인터페이스의 메서드 
	 * 	추가 - boolean add(Object o)
	 * 		  boolean addAll(Collection c)
	 * 		지정된 객체(o) 또는 Collection(c) 객체들을 Collection 에 추가한다
	 * 
	 * 	검색 - boolean contains(Object o)
	 * 		  boolean containsAll(Collection c)
	 * 		지정된 객체(o) 또는  Collection 의 객체들이 Collection 에 포함되어있는지 확인한다
	 * 
	 * 	삭제 = boolean remove(Object o) 지정된 객체를 삭제한다
	 * 		  boolean removeAll(Collection c) 지정된 Collection 에 포함된 객체들을 삭제한다
	 * 
	 * 	int size() - Collection 에 저장된 객체의 개수를 반환한다
	 * 
	 * 	collection 인터페이스 : 컬렉션 프레임워크의 최상위 인터페이스
	 * 						 컬렉션을 표현하기 위한 기본적인 기능을 정의
	 * 	collections 클래스 : 컬렉션을 조작하고 관리하기 위한 유틸리티 클래스
	 * 						컬렉션을 정렬, 검색, 변경하는데 사용
	 * 		
	 * 								배열과 ArrayList
	 * 	
	 * 			  ArrayList									일반 배열
	 * -------------------------------------------------------------------------------
	 * 	ArrayList<String> myList = new			String[] myList = new String[2]
	 * 	ArrayList<String>();
	 * 
	 * 	String a = new String("whoohoo");		String a = new String("Whoohoo");
	 * 
	 * 	myList.add(a);							myList[0] = a;
	 * 
	 * 	String b = new String("Frog");			String b = new String("Frog");
	 * 
	 * 	myList.add(b);							myList[1] = b;
	 * 
	 * 	int theSize = myList.size();			int theSize = myList.length;
	 * 
	 * 	Object o = myList.get(1);				String o = myList[1];
	 * 
	 * 	myList.remove(1);						myList[1] = null
	 * 
	 * 	boolean isIn = myList.contains(b);		boolean isIn = false
	 * 											for (int i=0; i<myList.length; i++) {
	 * 												if (b.eqials(myList[i])) {
	 * 													isIn = true;
	 * 													break;
	 * 												}
	 * 											} 																
	 * -------------------------------------------------------------------------------
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * */
}
