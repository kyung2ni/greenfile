package day0307;

import java.util.ArrayList;
import java.util.Collections;

public class ArrayListExample1 {
	public static void main(String[] args) {
		//중복O, 순서O
		ArrayList list1 = new ArrayList(10);
		
		//ArrayList 에는 객체만 저장 가능
		list1.add(5);
		list1.add(4);
		list1.add(2);
		list1.add(0);
		list1.add(1);
		list1.add(3);
		
		//subList() : arrayList에서 일부를 뽑아서 새로운 리스트로 생성
		ArrayList list2 = new ArrayList(list1.subList(1, 4));
		print(list1,list2);
		
		Collections.sort(list1);
		Collections.sort(list2);
//		Collections.reverse(list1); //뒤집기
		print(list1, list2);
		
		//containsAll : list1에 list2의 모든 요소가 다 포함되어있는지 확인
		System.out.println("list1.containsAll(list2) : "+list1.containsAll(list2));
		
		//리스트에 내용 추가(인덱스 지정 가능)
		list2.add("B");
		list2.add("C");
		list2.add(3, "A");
		print(list1, list2);
		
		//해당 위치에 있는 내용을 변경
		list2.set(3, "AA");
		print(list1, list2);
		
		list1.add(0, "1");
		//지정된 객체의 위치를 알려줌
		System.out.println("index : "+list1.indexOf("1"));
		System.out.println("index : "+list1.indexOf(1));
		print(list1, list2);
		
		
		list1.remove(1); //숫자만 쓰면 1번 인덱스의 값이 지워짐(인덱스 위치)
		list1.remove(Integer.valueOf(1)); //숫자 1이 지워짐 (숫자를 지울땐 숫자형식으로 입력)
		print(list1, list2);
		
		//list1에서 list2와 겹치는 부분만 남겨놓고 나머지를 삭제 
		System.out.println("list1.retainAll(list2) : "+list1.retainAll(list2));
		print(list1, list2);
		
		//삭제하기
		//0번 인덱스부터 내용을 삭제하면 배열 복사때문에 인덱스가 변하게 되므로
		//정상적인 삭제가 처리되지 않음
//		for(int i=0; i<list2.size(); i++) { //배열 복사 > 인덱스 변경 , size 감소
//			list2.remove(i);
//		}

		//list2에서 list1에 포함된 객체만 삭제
		//1. get(i)를 이용하여 list2에서 하나씩 꺼낸다
		//2. contains()로 꺼낸 객체가 list1에 있는지 확인
		//3. remove(i)로 해당 객체를 list2에서 삭제
		for(int i=list2.size()-1; i>=0; i--) {
			if (list1.contains(list2.get(i)))
				list2.remove(i);
		}
		print(list1, list2);
	}
	
	static void print(ArrayList list1, ArrayList list2) {
		System.out.println("list1 : "+list1);
		System.out.println("list2 : "+list2);
		System.out.println();
	}
}
