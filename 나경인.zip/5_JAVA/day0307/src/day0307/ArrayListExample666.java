package day0307;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class MemberMenu {
	Scanner sc = new Scanner(System.in);
	private int menu;
	boolean flag = true;
	private String menuStr = "1.추가 2.검색 3.수정 4.삭제 5.전체출력 6.데이터초기화 7.종료";
	
	public void menuProcess(ArrayList<Member> data) {
		int idx = 0; 
		while(flag) {
			System.out.println("-------------------------------------------------");
			System.out.println(menuStr);
			menu = sc.nextInt();
			
			switch(menu) {
			case 1 :
				data.add(infoInput());
				break;
			case 2 :
				idx = search(data);
				if (idx>=0) {
					printMember(data.get(idx));
				}
				break;
			case 3 :
				editMember(data);
				break;
			case 4 :
				delMember(data);
				break;
			case 5 :
				for ( idx=0; idx<data.size(); idx++) {
					printMember(data.get(idx));
				}
				break;
			case 6 :
				delAllMember(data);
				break;
			case 7 :
				System.out.println("프로그램을 종료합니다.");
				flag=false;
				break;
			default : 
				System.out.println("잘못된 입력입니다.");
				break;
			}
		}
	}
	//case 1 : 추가기능
	public Member infoInput() {
		System.out.print("이름 > ");
		String name = sc.next();
		System.out.print("");
		sc.nextLine();
		
		System.out.print("전화번호 > ");
		String tel = sc.nextLine();

		
		System.out.print("주소 > ");
		String address = sc.nextLine();

		
		return new Member(name, tel, address);
	}
	
	//case 2 : 검색기능
	public int search(ArrayList<Member> data) {
		System.out.println("이름 > ");
		String name = sc.next();
		
		for (int i=0; i<data.size(); i++) {
			if (name.equals(data.get(i).getName())) {
				return i;
			}
		}
		System.out.println("일치하는 사람이 없습니다.");
		return -1;
	}
	public void printMember(Member m) {
		System.out.println(m);
	}
	
	//case 3 : 수정
	public void editMember(ArrayList<Member> data) {
		int idx = search(data);
		
		if (idx != -1) {
			System.out.println("새 전화번호 > ");
			String tel = sc.next();
			sc.nextLine();
			
			System.out.println("새 주소 > ");
			String address = sc.nextLine();
			data.set(idx, new Member(data.get(idx).getName(),tel,address));
		}
	}
	
	//case 4 : 삭제
	public void delMember(ArrayList<Member> data) {
		int idx = search(data);
		data.remove(idx);
	}
	
	//case 6 : 데이터초기화
	public void  delAllMember(ArrayList<Member> data) {
		data.removeAll(data);
	}
}

class Member {
	private String name;
	private String tel;
	private String address;
	
	public Member() {}
	public Member(String name, String tel, String address) {
		this.name = name;
		this.tel = tel;
		this.address = address;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	@Override
	public String toString() {
		return "Member [이름 : "+name+" 전화번호 : "+tel+" 주소 : "+address+"]";
		
	}


}
public class ArrayListExample666 {
	public static void main(String[] args) {
		//주소록 생성
		//사용자에게서 메뉴를 선택받아 추가, 검색, 수정, 삭제,
		//전체출력, 데이터초기화, 종료를 수행하도록 하세요
		
		ArrayList<Member> data = new ArrayList<>();
		
		MemberMenu mm = new MemberMenu();
		mm.menuProcess(data);
		
			
		
		
	}
}
