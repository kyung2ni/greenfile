//package day0307;
//
//import java.util.ArrayList;
//import java.util.Arrays;
//import java.util.Collections;
//import java.util.Scanner;
//
//class Member2 {
//	String name;
//	int tel;
//	String address;
//	
//	public Member2(String name, int tel, String address) {
//		this.name = name;
//		this.tel = tel;
//		this.address = address;
//	}
//	
//	public String toString() {
//		return "\n이름 : "+name+" 전화번호 : "+tel+" 주소 : "+address;
//		
//	}
//
//
//}
//public class ArrayListExample6 {
//	public static void main(String[] args) {
//		//주소록 생성
//		//사용자에게서 메뉴를 선택받아 추가, 검색, 수정, 삭제,
//		//전체출력, 데이터초기화, 종료를 수행하도록 하세요
//		Scanner scan = new Scanner(System.in);
//		
//		ArrayList<Member> list = new ArrayList<>();
//		exit : while(true) {
//			System.out.println("1.추가 2.검색 3.수정 4.삭제 5.전체출력 6.데이터초기화 7.종료");
//			System.out.print("입력 > ");
//			int p = scan.nextInt();
//			switch(p) {
//			case 1 :
//				System.out.print("이름 입력 > ");
//				String name = scan.next();
//				
//				System.out.print("전화번호 입력 > ");
//				int tel = scan.nextInt();
//				
//				System.out.print("주소 입력 > ");
//				String address = scan.next();
//				
//				Member2 member = new Member2(name,tel,address);
//				list.add(member);
//				break;
//			case 2 :
//				System.out.print("이름 입력 > ");
//				String name2 = scan.next();
//				for (Member m : list) {
//			        if (m.name.equals(name2)) {
//			            System.out.println("검색 결과 : "+m);
//			            break;
//			        }
//			    }
//			    break;
//			case 3 :
//				System.out.print("이름 입력 > ");
//				String name3 = scan.next();
//				for (Member m : list) {
//			        if (m.name.equals(name3)) {
//			        	System.out.print("수정할 전화번호 입력 > ");
//						int tel3 = scan.nextInt();
//						
//						System.out.print("수정할 주소 입력 > ");
//						String address3 = scan.next();
//						
//						m.set(address,address3);
//			            break;
//			        }
//			    }
//				
//			case 4 :
//				System.out.print("이름 입력 > ");
//				String name4 = scan.next();
//				for (Member m : list) {
//			        if (m.name.equals(name4)) {
//			        	list.remove(m);
//			            break;
//			        }
//			    }
//				break;
//			case 5 :
//				System.out.println(list);
//				break;
//			case 6 :
//				list.removeAll(list);
//				break;
//			case 7 :
//				System.out.println("종료합니다");
//				break exit;
//			}
//		}
//		
//	}
//}
