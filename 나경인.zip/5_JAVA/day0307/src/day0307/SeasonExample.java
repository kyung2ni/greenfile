package day0307;

public class SeasonExample {
	public static void main(String[] args) {
		//열거형의 생성자는 암묵적으로 private 이므로 외부에서는 객체를 생성할 수 없다
		//Season s = new Season("a");
		
		for (Season s : Season.values()) {
			System.out.println("한글 이름 : "+s.getKoreanName());
			System.out.println("놀아요 : "+s.getSeasonPlay());
		}
		
		System.out.println(Season.SPRING.getKoreanName());
		
//		System.out.println(Season.SPRING);
//		System.out.println(Season.SUMMER);
//		System.out.println(Season.AUTUMN);
//		System.out.println(Season.WINTER);

	}
}
