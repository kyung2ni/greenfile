package day0307;

import java.util.ArrayList;
import java.util.Scanner;

public class ArrayListExample3 {
	public static void main(String[] args) {
		
		// ArrayList에 각각의 값을 추가후 출력
		//1. 검색한 값을 입력받아 해당하는 내용의 위치를 출력
		//   찾는 값이 없다면 '찾는값이 없음'이라고 출력
		//2. 삭제할 값을 입력받아 해당하는 요소를 삭제하고 남은 요소들을 출력
		//3. 리스트에 있는 모든 요소를 삭제하고
		//   리스트가 비어있는 경우에는 '리스트가 비었음' 출력
		//
		Scanner scan = new Scanner(System.in);
		ArrayList<String> list = new ArrayList<>(3);
		
		list.add("aaa");
		list.add("bbb");
		list.add("ccc");
		
		for (int i=0; i<list.size(); i++) {
			System.out.println(i+"번째 요소 : "+list.get(i));
		}
		System.out.println("---------------------");
		System.out.print("검색할 값 입력 > ");
		String obj = scan.next();
		int idx = 0;
		if (list.contains(obj)) {
			idx = list.indexOf(obj);
			System.out.println(idx+"번째 위치에서 "+list.get(idx)+"검색");
		} else {
			System.out.println("찾는값이 없음");
		}
//		if (list.indexOf(obj) == -1) {
//			System.out.println("찾는값이 없음");
//		} else {
//			System.out.println(list.indexOf(obj)+"번째 위치에서 "+obj+" 검색");			
//		}
		System.out.println("---------------------");
		System.out.print("삭제할 값 입력 > ");
		
		String obj2 = scan.next();
		System.out.println();
		if (list.contains(obj2)) {
			idx = list.indexOf(obj2);
			list.remove(idx);
		} else {
			System.out.println("찾는 값이 없음");
		}
//		list.remove(String.valueOf(obj2)); 
		
		for (int i=0; i<list.size(); i++) {
			System.out.println(i+"번째 요소 : "+list.get(i));
		}
		System.out.println();
		
		System.out.println("전체 삭제");
		list.removeAll(list);
		
		if (list.isEmpty()) {
			System.out.println("리스트가 비었음");
		} else {
			for (int i=0; i<list.size(); i++) {
				System.out.println(i+"번째 요소 : "+list.get(i));
			} 
		}
		
		
		
		
	}
}
