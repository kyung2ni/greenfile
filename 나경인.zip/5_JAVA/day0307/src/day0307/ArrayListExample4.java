package day0307;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ArrayListExample4 {
	public static void main(String[] args) {
		//로또 번호 추출기
		//1~45사이의 숫자 중 랜덤으로 6개 추출
		//Collections 사용하면 편하고 빠름
		
		//리스트 2개 쓰기
		ArrayList<Integer> list = new ArrayList<>();
		ArrayList<Integer> num = new ArrayList<>();
		
		//로또번호 45개 생성
		for (int i=1; i<=45; i++) {
			list.add(i);
		}
		//로또번호 섞기
		Collections.shuffle(list);
		
		//번호 6개 num에 넣기 
		for (int i=0; i<6; i++) {
			Collections.addAll(num,list.get(i));
		}
		
		//오름차순 정렬
		Collections.sort(num);
		System.out.println(num);
		
		//////////////////////////////////////////////////////////
		
		//리스트 1개만 쓰기
		ArrayList<Integer> list2 = new ArrayList<>();
		
		//로또번호 45개 생성
		for (int i=1; i<=45; i++) {
			list2.add(i);
		}
		//로또번호 섞기
		Collections.shuffle(list2);
		
		//6개만 남기고 번호 삭제
		for(int i=list2.size()-6; i>0; i--) {
			list2.remove(i);
		}
		//오름차순 정렬
		Collections.sort(list2);
		System.out.println(list2);
		
		////////////////////////////////////////////////////////////
		
//		ArrayList<Integer> list3 = new ArrayList<>();
//		
//		
//		//로또번호 45개 생성
//		for (int i=1; i<=45; i++) {
//			list3.add(i);
//		}
//		//로또번호 섞기
//		Collections.shuffle(list);
//		int[] lottoArr = new int[6];
//		//
//		for (int i=0; i<6; i++) {
//			lottoArr[i] = 
//		}
//		
//		//오름차순 정렬
//		Collections.sort(num);
//		System.out.println(num);
//		
		
			
	}
}
