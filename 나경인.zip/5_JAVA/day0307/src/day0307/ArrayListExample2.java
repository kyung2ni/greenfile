package day0307;

import java.util.ArrayList;
import java.util.List;

public class ArrayListExample2 {
	public static void main(String[] args) {
		
		List<String> list = new ArrayList<String>();
		
		list.add("Java");
		list.add("JDBC");
		list.add("Servlet/JSP");
		list.add(2,"Database");
		list.add("MyBatis");
		
		//배열 크기 : array.length; (속성)
		//문자열 길이 : string.length(); (메서드)
		//ArrayList 길이 : arrayList.size(); (메서드)
		System.out.println("총 객체 수 : "+list.size());
		
		System.out.println("2 : "+list.get(2));
		
		//저장된 총 객체를 출력
		for (int i=0; i<list.size(); i++) {
			System.out.println(i+" : "+list.get(i));
		}
		
		System.out.println();
		list.remove(2); //2번 인덱스 삭제
		list.remove(2); //2번 인덱스 삭제
		list.remove("MyBatis");
		
		for (int i=0; i<list.size(); i++) {
			System.out.println(i+" : "+list.get(i));
		}
		
		//추가할 땐 add()
		//찾을 땐 get()
		//삭제할 땐 remove()
	}
}	
