package day0221;

class Math {
	int add(int a,int b) {
		return a+b;
	}
	float add(float a,float b) {
		return a+b;
	}
	
	int add(int[] a) {
		int result = 0;
		
		for (int i=0; i<a.length; i++) {
			result +=a[i];
		}
		return result;
	}
}

public class MathTest {
	public static void main(String[] args) {
		Math m = new Math();
		
		System.out.println(m.add(10,20));
		System.out.println(m.add(10.2f,11.5f));
		
		int[] arr= {100,200,300};
		System.out.println(m.add(arr));
		
	}
}
