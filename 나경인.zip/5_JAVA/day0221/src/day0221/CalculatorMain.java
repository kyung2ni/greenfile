package day0221;

class Calculator {
	//정사각형과 직사각형의 넓이를 계산하는
	//areaRectangle 메서드를 오버로딩하여 작성하고
	//정사각형의 길이는 10
	//직사각형의 넓이는 가로10, 세로20으로 계산하여
	//각각의 넓이를 출력하시오
	
	int areaRectangle(int a,int b) {
		return a*b;
	}
	int areaRectangle(int a) {
		return a*a;
	}
	
}

public class CalculatorMain {
	public static void main(String[] args) {
		
		Calculator cal = new Calculator();
		
		System.out.println("정사각형의 넓이 : "+cal.areaRectangle(10));
		System.out.println("직사각형의 넓이 : "+cal.areaRectangle(10,20));
		
		
		
	}
}
