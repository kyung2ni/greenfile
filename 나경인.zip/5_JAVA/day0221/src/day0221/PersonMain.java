package day0221;

public class PersonMain {
	public static void main(String[] args) {
		
		Person p1 = new Person();
		
		System.out.println(p1.name);
		System.out.println(p1.age);
		System.out.println(p1.tel);
		
		Person p2 = new Person("정디비",22,"010-2123-3456");
		
		System.out.println(p2.name);
		System.out.println(p2.age);
		System.out.println(p2.tel);
		
		
	}
}
