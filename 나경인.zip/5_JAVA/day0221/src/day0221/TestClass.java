package day0221;

class Test {
	
	int iv; //인스턴스 변수
	static int cv; //클래스 변수
	
	//인스턴스 메서드
	void instanceMethod() {}
	//클래스 메서드
	static void staticMethod() {}
	//인스턴스 메서드 내에서는
	//다른 인스턴스메서드와 클래스메서드를 모두 호출할 수 있다.
	void instanceMethod2() {
		System.out.println(iv);
		System.out.println(cv);
		instanceMethod();
		staticMethod();
	}
	//클래스 메서드 내에서는
	//인스턴스 메서드를 호출할 수 없다.
	//호출 시점에 인스턴스 생성되어있다는 보장 x
	static void staticMethod2() {
//		System.out.println(iv);
		System.out.println(cv);
//		instanceMethod();
		staticMethod();
	}
}
public class TestClass {
	public static void main(String[] args) {
		Test t = new Test();
		
		t.instanceMethod();
		t.instanceMethod2();
		
		Test.staticMethod();
		Test.staticMethod2();
	}
}
