package day0221;

public class ProductMain {
	public static void main(String[] args) {
		Product p1 = new Product();
		Product p2 = new Product();
		Product p3 = new Product();
		
		System.out.println("p1의 serial no : "+p1.serialNo); //1
		System.out.println("p2의 serial no : "+p2.serialNo); //2
		System.out.println("p3의 serial no : "+p3.serialNo); //3
		System.out.println("제품의 총 개수 : "+Product.count);
	}
}
