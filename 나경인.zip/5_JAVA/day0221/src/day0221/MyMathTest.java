package day0221;

class MyMath {
	
//	long a, b; 스태틱쓰면 사용불가
	
	static long add(long a,long b) { //매개변수 x
		return a+b;
	}
	
}

public class MyMathTest {
	public static void main(String[] args) {
		MyMath mm = new MyMath();
//		mm.a = 300L;
//		mm.b = 200L;
//		System.out.println(mm.add());
		
		System.out.println(MyMath.add(100L, 200L));
	}
	
	
}
