package day0221;

class Printer {
	
	static int show(int a) {
		System.out.println(a);
		return a;
	}
	static boolean show(boolean a) {
		System.out.println(a);
		return a;
	}
	static void show(double a) {
		System.out.println(a);

	}
	static void show(String a) {
		System.out.println(a);

	}
	
	
}

public class PrinterExample {
	public static void main(String[] args) {
//		Print Printer = new Print();
		
		Printer.show(10);
		Printer.show(true);
		Printer.show(5.7);
		Printer.show("출력!!");
	}
}


