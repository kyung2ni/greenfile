package day0221;

class CarS {
	//인스턴스 변수
	int num; //차량번호
	double gas; //주유량
	static int count; //차량수 (클래스변수)
	
	//인스턴스 메서드
	public void setCarI(int n, double g) {
		num = n;
		gas = g;
		count++;
		System.out.printf("차량번호 : %d, 연료량 %f으로 설정합니다.\n", num, gas);
	}
	
	public void showI() {
		System.out.println("차량번호 : "+num);
		System.out.println("연료량 : "+gas);
	}
	
	public static void showC() {
		System.out.println("차량대수 : "+count);
	}
}

public class Static1 {
	public static void main(String[] args) {
		CarS car1 = new CarS();
		car1.setCarI(1234,20.5);
		car1.showI();
		CarS.showC();
		
		CarS car2 = new CarS();
		car2.setCarI(5678,55.3);
		car2.showI();
		CarS.showC();
	}

}
