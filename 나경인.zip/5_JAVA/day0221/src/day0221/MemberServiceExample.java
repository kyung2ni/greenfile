package day0221;

class MemberService {
	//login 과 logout 기능을 선언하고자 함.
	//login 을 할 때는 매개변수 값으로 id 와 password 를 제공하고
	//logout 할 때에는 id 값만 사용한다
	
	//login 은 id 가 'green', 'password'가 '1234'일 때만
	//로그인에 성공하도록 하고
	//'green님 반갑습니다!'를 출력하도록 한다.
	//logout을 할 때에는 'green'인 경우에만 로그아웃에 성공하도록 하고
	//'로그아웃 되었습니다.'를 출력하도록 한다.
	
	boolean log (String id) {
		boolean result = false;
		if (id.equals("green")) {
			result = true;
		} else {
			result = false;
		}
		return result;
	}
	boolean log (String id,String password) {
		boolean result = false;
		if (id.equals("green") && password.equals("1234")) {
			
			result = true;
		} else {
			result =false;
		}
		return result;
	}
}


public class MemberServiceExample {
	public static void main(String[] args) {
		MemberService ms = new MemberService();
		boolean login = ms.log("green","1234");
		
		if (login) {
			System.out.println("green님 반갑습니다.");
		} else {
			System.out.println("id 또는 pw가 올바르지 않습니다.");
		}
		
		boolean logout = ms.log("green");
		if (logout) {
			System.out.println("로그아웃 되었습니다.");
		} else {
			System.out.println("로그아웃 실패.");
		}
		
		


	
	}
	
}
