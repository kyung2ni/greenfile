package day0221;

public class Document {

	//문서의 제목이 있으면 문서명을 그대로 출력
	//만약 문서명을 지정하지 않았다면
	//'제목없음1.txt', '제목없음2.txt'...로 출력
	
	String name;
//	int num;
	static int count = 0;

	Document() {
		count++;
//		num = count;
		System.out.printf("문서 제목없음%d.java가 생성됨\n",count);
	}
	
	Document(String name) {
		this.name = name;
		System.out.printf("문서 %s가 생성됨\n",this.name);
	}


	 
	
	
}
