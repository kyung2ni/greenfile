package day0221;

public class Car {
	String color; //색상
	String gearType; //수동,자동
	int door; //문짝 개수
	
	Car() {
//		color = "white";
//		gearType = "auto";
//		door = 4;
		this("white","auto",4);
	}
	Car(String color) {
//		this.color = color;
//		this.gearType = "auto";
//		this.door = 4;
		this(color,"auto",4);
	}

	Car(String color,String gearType,int door) {
		this.color = color;
		this.gearType = gearType;
		this.door = door;
	}
}
