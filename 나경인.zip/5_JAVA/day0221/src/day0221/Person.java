package day0221;

public class Person {
	String name="김그린";
	int age=99;
	String tel="010-1234-4321";
	
	Person() {}
	//매개변수 1개 생성자(이름)
	Person(String name) {
		this(name, 22);
		System.out.println("this생성자는 첫번째 줄에서만 쓸 수 있음");
	}
	//매개변수 2개 생성자(이름,나이)
	Person(String name,int age) {
		this(name, age, "010-0000-0000");
	}
	//매개변수 3개 생성자(이름,나이,전화번호)
	Person(String name,int age,String tel) {
		this.name = name;
		this.age = age;
		this.tel = tel;
	}
}
