package day0221;

public class InitTest {
//	int x;
//	int y = x;
//	
//	void method1() { //지역변수에서는
//		int i = 10; //초기화 해야
//		int j = i; //쓸 수 있음
//	}
	
	static int cv = 1;	//명시적 초기화
	int iv = 1;			//명시적 초기화
	
	//초기화 블럭
	//클래스 초기화 블럭
	static {
		cv = 2;
	}
	//인스턴스 초기화 블럭
	{
		iv = 2;
	}
	
	InitTest() { //생성자
		iv =3;
	}
	public static void main(String[] args) {
		InitTest i = new InitTest();
		System.out.println(InitTest.cv);
		System.out.println(i.iv);
	}
}
