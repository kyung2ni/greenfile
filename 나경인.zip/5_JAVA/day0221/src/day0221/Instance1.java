package day0221;

class CarI {
	//인스턴스 변수
	int num; //차량번호
	double gas; //주유량
	
	//인스턴스 메서드
	public void setCarI(int n, double g) {
		num = n;
		gas = g;
		System.out.printf("차량번호 : %d, 연료량 %f으로 설정합니다.\n", num, gas);
	}
	
	public void showI() {
		System.out.println("차량번호 : "+num);
		System.out.println("연료량 : "+gas);
	}
}

public class Instance1 {
	public static void main(String[] args) {
		CarI car1 = new CarI();
		car1.setCarI(1234,20.5);
		car1.showI();
		
		CarI car2 = new CarI();
		car2.setCarI(5678,55.3);
		car2.showI();
		
	}
}
