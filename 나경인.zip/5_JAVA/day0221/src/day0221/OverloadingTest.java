package day0221;

public class OverloadingTest {
	//메서드 오버로딩 : 하나의 클래스에 같은 이름의 메서드를 여러 개 정의하는 것
	//오버로딩의 조건
	//	메서드의 이름이 같아야 한다.
	//	매개변수의 개수 또는 타입이 달라야 한다.
	//	매개변수는 같고 리턴타입이 다른 경우는 오버로딩이 성립되지 않는다.
	//	(리턴타입은 오버로딩을 구현하는 데 아무런 영향을 주지 못한다.
	
	//매개변수를 2개 입력받아
	//int, float, String에 대한 합계를 구하자고 함
	
	int add(int x, int y) {
		return x+y;
	}
	
	float add(float x, float y) {
		return x+y;
	}
	
	String add(String x, String y) {
		return x+y;
	}
	long add (int x, long y) {
		return x+y;
	}
	long add(long x, int y) {
		return x+y;
	}
	public static void main(String[] args) {
		OverloadingTest ot = new OverloadingTest();
		System.out.println(ot.add(4, 5));
		System.out.println(ot.add(4.2f,8.4f));
		System.out.println(ot.add("A","B"));
		
		System.out.println(ot.add(3, 5L));
		System.out.println(ot.add(3L, 5)); //실행할 타입을 명확하게 써주어야 함
		
		
		
	}
	
}
