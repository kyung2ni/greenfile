package day0221;

public class FlowerMain {
	public static void main(String[] args) {
		Flower f1 = new Flower("장미",1500);
		Flower f2 = new Flower("튤립",2000);
		
		f1.flowerInfo();
		f2.flowerInfo();
	}
}
