package day0221;

public class Product {
	int serialNo;
	static int count = 0; //개수
	
	//생성자 오버로딩이 100개 존재
	
	
	{
		count++;
		serialNo = count;
		
	}

}
