package day0221;

public class Bus {
	int num;
	double gas;
	//기본생성자 추가
	public Bus() {}
	
	//생성자 (이름이 클래스와 동일,리턴값이없음)
//	public Bus() {
//		num = 0;
//		gas = 0.0;
//		System.out.println("버스가 생성되었습니다.");
//	}
	
	//인스턴스(this) 변수와 지역변수를 구별하기위해 this 사용
	public Bus(int num, double gas) {
		this.num = num;
		this.gas = gas;
		System.out.println("버스가 생성되었습니다.");
	}
	
	public void show() {
		System.out.println("차량번호 : "+num);
		System.out.println("가스량 : "+gas);
	}
//	2유형 수당신청
}
