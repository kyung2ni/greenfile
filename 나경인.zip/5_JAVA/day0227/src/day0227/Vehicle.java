package day0227;

public abstract class Vehicle {
	int speed;
	
	abstract void setSpeed(int speed); 
	abstract void show();
}
