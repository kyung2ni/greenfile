package day0227;

public class Temporary extends Employee{
	int workhour;
	int timePay;
	
	Temporary(String name, int age, String address, String department) {
		super(name, age, address, department);
		timePay = 10000;
		
	}
	public void setWorkhours(int workhour) {
		this.workhour = workhour;
		this.salary = workhour*timePay;
	}
	public void printInfo() {
		super.printInfo();
		System.out.println("비정규직");
		System.out.println("일한시간 : "+workhour );
		System.out.println("급여 : "+salary);
	}
}
