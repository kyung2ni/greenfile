package day0227;

public class Employee {
	String name;
	int age;
	String address;
	String department;
	int salary;
	
	Employee(String name, int age, String address, String department) {
		this.name = name;
		this.age = age;
		this.address = address;
		this.department =department;
		
	}
	public void printInfo() {
		System.out.println("이름 : "+name);
		System.out.println("나이 : "+age);
		System.out.println("주소 : "+address);
		System.out.println("부서 : "+department);
	}
}
