package day0227;

public class Regular extends Employee{
	Regular(String name, int age, String address, String department) {
		super(name, age, address, department);
		
	}
	public void setSalary(int salary) {
		this.salary = salary;
		
	}
	public void printInfo() {
		super.printInfo();
		System.out.println("정규직");
		System.out.println("급여 : "+salary);
	}
}
