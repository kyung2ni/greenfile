package day0227;

public class EmployeeMain {
	public static void main(String[] args) {
		Regular r = new Regular("김그린", 35, "울산", "개발부");
		Temporary t = new Temporary("이자바", 22, "부산", "총무부");
		r.setSalary(5000000);
		r.printInfo();
		System.out.println("----------------------------");
		
		t.setWorkhours(120);
		t.printInfo();
	}
}
