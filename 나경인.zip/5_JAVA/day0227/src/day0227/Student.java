package day0227;

import java.util.Scanner;

public class Student extends Person{
	String univ;
	String department;
	int univNum;
	
	double[] score = new double[8];
	Scanner scan = new Scanner(System.in);
	
	Student() {}
	
	Student (String name, int age, String address, String univ, String department, int univNum) {
		super(name, age, address);
		this.univ = univ;
		this.department = department;
		this.univNum = univNum;
//		super(name, age, address, univ, department, univNum);
	}
	
	public void printUnivScore() {
		double sum = 0;
		double avg = 0;
		for (int i = 0; i<8; i++) {
			System.out.print((i+1)+"학기 학점 > ");
			score[i] = scan.nextDouble();
			sum += score[i];
		}
		avg = sum/8;
		avg = (double)((int)(avg*1000))/1000;
		
		System.out.println("8학기 학점의 평균 학점은 "+avg+"점 입니다.");
	}
	
	public void printInfo() {
		System.out.println("이름 : "+name);
		System.out.println("나이 : "+age);
		System.out.println("주소 : "+address);
		System.out.println("학교 : "+univ);
		System.out.println("학과 : "+department);
		System.out.println("학번 : "+univNum);
	}

	
}
