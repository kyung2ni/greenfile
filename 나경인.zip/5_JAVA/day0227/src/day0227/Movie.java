package day0227;

public class Movie {
	
	int price;
	
	Movie() {
		price = 10000;
		int discount = 0;
	}
}

class ActionMovie {
	int discount = 1000;
}

class HorroMovie {
	
}

class ComedyMovie {
	
}
