package day0227;

public class Plane extends Vehicle{
	int num;
	
	void flight(int num) {
		this.num = num;
	}
	
	@Override
	void setSpeed(int speed) {
		this.speed = speed;
		
	}

	@Override
	void show() {
		System.out.println("비행기 번호 : "+num);
		System.out.println("속도 : "+speed);
		
	}
	
}
