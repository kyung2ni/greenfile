package day0227;

import java.util.Scanner;

public class StudentMain {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
//		Student s1 = new Student("김그린",20,"울산시 남구","그린대학교","컴퓨터공학과",202222222);
//		s1.printInfo();
//		s1.printUnivScore();
		
		Student s2 = new Student();
		
		System.out.print("이름 : ");
		s2.name = scan.nextLine();

		System.out.print("나이 : ");
		s2.age = Integer.parseInt(scan.nextLine());
		
		System.out.print("주소 : ");
		s2.address = scan.nextLine();
		
		System.out.print("학교 : ");
		s2.univ = scan.nextLine();
		
		System.out.print("학과 : ");
		s2.department = scan.nextLine();
		
		System.out.print("학번 : ");
		s2.univNum = Integer.parseInt(scan.nextLine());
		
		s2.printInfo();
		
		
		
		
	}

}
