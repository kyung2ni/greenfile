package day0227;

public class CarExampleMain {
	public static void main(String[] args) {
		CarExample c = new CarExample();
		c.speedUp();
		c.speedUp();
		c.speedUp(200);
		c.speedUp(200);
		c.speedDown(100);
		c.speedDown(250);
		c.speedDown();
		c.speedUp(100);

	}
}
