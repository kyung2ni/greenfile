package day0227;

public class CarExample {
	int maxSpeed;
	int speed;
	
	CarExample() {
		this.maxSpeed = 300;
		this.speed = 0;
	}
	
	public void speedUp() {
		speed += 5;
		Speed();		
	}
	public void speedUp(int speed) {
		this.speed += speed;
		Speed();
	}
	public void speedDown() {
		speed -=5;
		Speed();
	}
	public void speedDown(int speed) {
		this.speed -=speed;
		Speed();
	}
//	public void checkSpeed(int speed) {
//		if (this.speed > maxSpeed) {
//			System.out.println("최대속도보다 높으므로 최대속도로 설정");
//			this.speed = maxSpeed;
//		}
//		if (this.speed < 0) {
//			this.speed = 0;
//		}
//	}
	
	public void Speed() {
		if (speed <= maxSpeed && speed >=0) {
			System.out.println("현재속도 : "+speed);
			return;
		} else if (speed > maxSpeed) {
			speed = maxSpeed;
			System.out.println("최대속도보다 높으므로 최대속도로 설정");
		} else {
			speed = 0;
			System.out.println("속도가 0보다 작으므로 0으로 설정");
		}
		System.out.println("현재속도 : "+speed);
	}
}
