package day0227;

public class VehicleMain {
	public static void main(String[] args) {
		Car c = new Car(10,50.0);
		c.setSpeed(60);
		c.show();
		
		Plane p = new Plane();
		p.flight(11);
		p.setSpeed(500);
		p.show();
		
	}
}
