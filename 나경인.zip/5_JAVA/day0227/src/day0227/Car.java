package day0227;

public class Car extends Vehicle{
	int num;
	double gas;
	
	Car(int num,double gas) {
		this.num = num;
		this.gas = gas;
	}
	
	@Override
	void setSpeed(int speed) {
		this.speed = speed;
	}
	@Override
	void show() {
		System.out.println("차량번호 : "+num);
		System.out.println("연료량 : "+gas);
		System.out.println("속도 : "+speed);
		
	}
	
}
