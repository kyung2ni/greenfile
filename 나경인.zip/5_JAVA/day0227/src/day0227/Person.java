package day0227;

public class Person {
	String name;
	int age;
	String address;
//	String univ;
//	String department;
//	int univNum;
	
	Person() {}
	
	Person (String name, int age, String address) {
		this.name = name;
		this.age = age;
		this.address = address;
	}
//	Person (String name, int age, String address, String univ, String department, int univNum) {
//		this.name = name;
//		this.age = age;
//		this.address = address;
//		this.univ = univ;
//		this.department = department;
//		this.univNum = univNum;
//	}
		

	
	public void printInfo() {
		System.out.println("이름 : "+name);
		System.out.println("나이 : "+age);
		System.out.println("주소 : "+address);
//		System.out.println("학교 : "+univ);
//		System.out.println("학과 : "+department);
//		System.out.println("학번 : "+univNum);
	}
}
