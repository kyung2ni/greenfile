package day0226;

public class Tv extends Product{
	
	Tv() {
		super(100); // TV가격은 100만원
	}
	@Override
	public String toString() {
		return "Tv";
	}
}
