package day0226;

public class Car {
	String color = "white";
	int door = 4;
	
	void drive() {
		System.out.println("달려요~~");
	}
	
	void stop() {
		System.out.println("멈춰요!!!");
	}
	
	
}
