package day0226;

class A {
	A() {
		System.out.println("A메서드");
	}
}

class B extends A{
	B() {
		System.out.println("B메서드");
	}
}

public class TypeTest1 {
	public static void main(String[] args) {
		A a = new B(); //부모 타입의 참조변수로 자손을 다룸 
	}
}
