package day0226;

public class Cat extends Animal{
	//cry()를 오버라이딩 하여
	//야옹!출력
	public void cry() {
		System.out.println("야옹!");
	}
	//고양이의 특성을 나타내는 grooming()메서드를 정의
	//XX이가 그루밍을 한다.
	public void grooming() {
		System.out.println(name+"(이)가 그루밍을 한다.");
	}
}
