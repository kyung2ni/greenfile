package day0226;

public class AnimalMain {
	public static void main(String[] args) {
		AnimalAction a = new AnimalAction();
		
		
		Dog d = new Dog();
		d.name = "자기야";
//		a.cry();
//		a.run();
		a.action(d);
		
		
		Cat c = new Cat();
		c.name = "야옹이";
//		a.cry();
//		a.grooming();
		a.action(c);
	}
}
