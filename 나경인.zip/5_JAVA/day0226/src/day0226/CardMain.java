package day0226;

public class CardMain {
	public static void main(String[] args) {
		KCard k = new KCard("국민카드",700000);
		k.printInfo();
		
		HCard h = new HCard("현대카드",700000);
		h.printInfo();	
	}
	
}
