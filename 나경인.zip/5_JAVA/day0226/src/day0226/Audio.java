package day0226;

public class Audio extends Product{
	
	Audio() {
		super(2000);
	}
	@Override
	public String toString() {
		return "Audio";
	}
}
