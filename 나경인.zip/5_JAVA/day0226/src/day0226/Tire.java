package day0226;

public class Tire {
	public void roll() {
		System.out.println("회전합니다~");
	}
}
