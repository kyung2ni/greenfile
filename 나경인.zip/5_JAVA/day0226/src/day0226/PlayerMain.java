package day0226;

public class PlayerMain {
	public static void main(String[] args) {
		
		/*Mp3*/Player mp = new Mp3Player();
		
		mp.play(1);
		mp.stop();
	}
}
