package day0226;

import java.util.Arrays;

public class Buyer {
	int money = 10000;
	int bonusPoint = 0;
	
	//장바구니로 이용할 배열을 선언
	
	Product[] cart = new Product[10];
	int i=0;
	
	void buy(Product p) {
		if (money < p.price) {
			System.out.println("잔액이 부족합니다.");
			return;
		}
		
		money -= p.price;
		bonusPoint += p.bonusPoint;
		cart[i++]= p;
		
		System.out.println(p+"를 구매하였습니다.");
	}
	
	void summary() {
		int sum=0;
		String itemList = "";
		//구입한 물건의 총 금액을 출력
		//구입하신 물건의 총금액은 2600만원 입니다.
		for (int i=0; i<cart.length; i++) {
			//배열에 저장된 값이 null 이면 for 문 종료
			if (cart[i] ==null) break;
			sum += cart[i].price;
			itemList += cart[i]+", ";
		}
		System.out.println("구입하신 물건의 총 금액은"+sum+"만원 입니다.");
		System.out.println("구입하신 제품은 "+itemList+"입니다.");
		//구입한 제품의 이름을 출력
		//구입하신 제품은 TV , Computer, Audio, 입니다.
		
	}
//	void buyTv(Tv t) {
//		if (money < t.price) {
//			System.out.println("잔액이 부족합니다.");
//			return;
//		}
//		
//		money -= t.price;
//		bonusPoint += t.bonusPoint;
//		
//		System.out.println("TV를 구매하였습니다.");
//	}
//	void buyCom(Computer c) {
//		if (money < c.price) {
//			System.out.println("잔액이 부족합니다.");
//			return;
//		}
//		
//		money -= c.price;
//		bonusPoint += c.bonusPoint;
//		
//		System.out.println("컴퓨터를 구매하였습니다.");
//	}
//	void buyAudio(Audio a) {
//		if (money < a.price) {
//			System.out.println("잔액이 부족합니다.");
//			return;
//		}
//		
//		money -= a.price;
//		bonusPoint += a.bonusPoint;
//		
//		System.out.println("오디오를 구매하였습니다.");
//	}
}
