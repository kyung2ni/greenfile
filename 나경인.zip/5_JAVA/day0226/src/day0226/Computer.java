package day0226;

public class Computer extends Product{
	
	Computer() {
		super(500);
	}
	@Override
	public String toString() {
		return "Computer";
	}
}
