package day0226;

public class Run {
	public Tire t;
	public void run() {
		t.roll();
	}
}
