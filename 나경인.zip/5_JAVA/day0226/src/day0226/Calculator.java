package day0226;

public abstract class Calculator {
//	1. 클래스 이름 Calculator.java
//	2. 추상메서드 : 매개변수가 2개인
//	add(더하기),minus(빼기), mul(곱하기), div(나누기)생성
//	3. Calculator를 상속받는 Cal,java를 생성하여 계산
//	4. CalMain.java를 생성하여
//	사용자에게서 두 수를 입력받아 Cal.java를 통해 계산하여
//	그 결과를 출력하시오
//	5. 출력예시
//	5 + 3 = 8
//	5 - 3 = 2
//	5 * 3 = 15
//	5 / 3 = 1
//	(나눗셈에서 나누는 수에 0을 입력했을 때 오류가 발생하지않도록 설정)

	public abstract int/*void*/ add(int x,int y);
	public abstract int/*void*/ minus(int x,int y);
	public abstract int/*void*/ mul(int x,int y);
	public abstract int/*void*/ div(int x,int y);
}
