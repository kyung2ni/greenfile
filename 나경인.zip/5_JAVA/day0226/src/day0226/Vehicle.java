package day0226;

public class Vehicle {
	public void run() {
		System.out.println("차량이 달립니다");
	}
}
