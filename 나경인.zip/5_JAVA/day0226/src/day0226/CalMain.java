package day0226;

import java.util.Scanner;

public class CalMain {
	public static void main(String[] args) {
		Cal c = new Cal();
		Scanner scan = new Scanner(System.in);
		System.out.print("첫번째 숫자를 입력하세요 > ");
		int x = scan.nextInt();
		System.out.print("두번째 숫자를 입력하세요 > ");
		int y = scan.nextInt();
		
		
//		c.add(x, y);
//		c.minus(x, y);
//		c.mul(x, y);
//		c.div(x, y);
		System.out.printf("%d + %d = %d\n",x ,y ,c.add(x, y));
		System.out.printf("%d + %d = %d\n",x ,y ,c.minus(x, y));
		System.out.printf("%d + %d = %d\n",x ,y ,c.mul(x, y));
		System.out.printf("%d + %d = %d\n",x ,y ,c.div(x, y));
	}
}
