package day0226;

public /*abstract*/ class Mp3Player extends Player{

	void play(int pos) {
		System.out.println(pos+"번째 노래를 재생합니다.");
	}
	void stop() {
		System.out.println("중지합니다.");
	}
}
