package day0226;

public class AnimalAction{
	public void action(Animal a) {
	
		//공통적으로 cry()를 호출하고
		//Dog 타입이면 run 을 호출
		//Cat 타입이면 grooming 을 호출

		a.cry();

//		if (a instanceof Dog) {
//			((Dog)a).run();
//		} else if (a instanceof Cat) {
//			((Cat)a).grooming();
//		}
		
		if (a instanceof Dog dog) {
			dog.run();
		} else if (a instanceof Cat cat) {
			cat.grooming();
		}
		
		
	}	
}
