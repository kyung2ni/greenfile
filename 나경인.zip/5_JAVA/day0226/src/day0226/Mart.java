package day0226;

public class Mart {
	public static void main(String[] args) {
		Buyer b = new Buyer();
		//1. 메서드를 통해서 호출
//		b.buyTv(1000,10);
//		b.buyCom(500,5);
//		b.buyAudio(2000, 20);
		
		//2. 클래스를 생성하여 매개변수로 전달
//		Tv t = new Tv(1000);
//		b.buyTv(t);
//		Computer c = new Computer(500);
//		b.buyCom(c);
//		Audio a = new Audio(2000);
//		b.buyAudio(a);
		
		//3.Product 타입의 매개변수로 전달
		Tv t = new Tv();
		b.buy(t);
		Computer c = new Computer();
		b.buy(c);
		
		b.buy(new Audio());
		
		b.summary();
		
		System.out.println("잔액 : "+b.money);
		System.out.println("보너스 : "+b.bonusPoint);
	}
}
