package day0226;

//추상메서드를 1개라도 포함하고 있으면 추상클래스임
public abstract class Player {
	
	abstract void play(int pos);//추상메서드(구현부가 없음) 
	abstract void stop();
	
}
