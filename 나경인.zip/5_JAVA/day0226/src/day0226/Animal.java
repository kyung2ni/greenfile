package day0226;

public class Animal {
	String name;
	
	public void cry() {
		System.out.println(name +"가 소리를 낸다.");
	}
	
	
}
