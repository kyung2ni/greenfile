package day0226;

public class RunExample {
	public static void main(String[] args) {
		Run r = new Run();
		r.t = new Tire();
		r.run();
		
		r.t = new HankookTire();
		r.run();
		
		r.t = new KumhoTire();
		r.run();
	}
}
