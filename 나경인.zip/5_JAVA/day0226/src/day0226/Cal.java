package day0226;

public class Cal extends Calculator{

	@Override
	public int add(int x, int y) {
		// TODO Auto-generated method stub
		return x+y;
	}

	@Override
	public int minus(int x, int y) {
		// TODO Auto-generated method stub
		return x-y;
	}

	@Override
	public int mul(int x, int y) {
		// TODO Auto-generated method stub
		return x*y;
	}
	
	@Override
	public int div(int x, int y) {
		// TODO Auto-generated method stub
		if (y == 0) {
			return 0;
		}
		return x/y;
	}
//	public void add(int x,int y) {
//		System.out.println(x+"+"+y+"="+(x+y));
//	}
//	public void minus(int x,int y) {
//		System.out.println(x+"-"+y+"="+(x-y));
//	}
//	public void mul(int x,int y) {
//		System.out.println(x+"*"+y+"="+(x*y));
//	}
//	public void div(int x,int y) {
//		if (y ==0) {
//			System.out.println(x+"/"+y+"="+0);	
//		} else {
//			System.out.println(x+"/"+y+"="+result2);
//		}
//	}
}
