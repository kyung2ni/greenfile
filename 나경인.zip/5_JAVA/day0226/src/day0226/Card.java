package day0226;

public abstract class Card {
	
	public String cardCompany; //카드회사명
	public int cardAmt; //카드 승인금액
	public int pointAmt; //카드 적립금액
	
	public Card(String cardCompany, int cardAmt) {
		this.cardCompany = cardCompany;
		this.cardAmt = cardAmt;
	}
	
	public abstract void printInfo();
}
