package day0226;

public class KCard extends Card{
	public KCard(String cardCompany, int cardAmt) {
		super(cardCompany, cardAmt);
	}
	//포인트 3%적립
	@Override
	public void printInfo() {
		pointAmt = (int)(cardAmt *0.03);
		System.out.printf("%s 구매금액 %d원에 대한 포인트적립액은 %d원 입니다.\n",cardCompany,cardAmt,pointAmt);
	}
	
	

}
