package day0226;

public class Dog extends Animal{
	//cry()를 오버라이딩 하여
	//멍멍 출력
	public void cry() {
		System.out.println("멍멍!");
	}
	//강아지의 특성을 나타내는 run()메서드를 정의
	//XX이가 뛴다
	public void run() {
		System.out.println(name+"(이)가 뛴다.");
	}
}
