package day0226;

public class Driver {

	
	public void drive(Vehicle v) {
		v.run();
	}
//	public void drive(Bus b) {
//		b.run();
//	}
//	
//	public void driva(Taxi t) {
//		t.run();
//	}
}
