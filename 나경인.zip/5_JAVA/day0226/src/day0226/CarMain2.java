package day0226;

public class CarMain2 {
	public static void main(String[] args) {
		Car car = new Car();
		FireEngine fe = new FireEngine();
		
		FireEngine fe2 = (FireEngine) car;
		Car car2 = fe2;
		
		//생성된 인스턴스가 없음에도 불구하고 오류가 발생되지 않음(메서드 호출 가능)
		car2.drive();
	}
}
