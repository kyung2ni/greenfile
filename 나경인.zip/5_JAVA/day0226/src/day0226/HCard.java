package day0226;

public class HCard extends Card{
	public HCard(String cardCompany, int cardAmt) {
		super(cardCompany, cardAmt);
	}
	
	//포인트 5%적립
	@Override
	public void printInfo() {
		pointAmt = (int)(cardAmt *0.05);
		System.out.printf("%s 구매금액 %d원에 대한 포인트적립액은 %d원 입니다.\n",cardCompany,cardAmt,pointAmt);
	}
}
