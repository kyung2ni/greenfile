package day0226;

public class Ambulance extends Car{
	void siren() {
		System.out.println("사이렌~");
	}
}
