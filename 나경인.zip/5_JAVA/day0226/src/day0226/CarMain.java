package day0226;

public class CarMain {
	public static void main(String[] args) {
		FireEngine f = new FireEngine();
		
		System.out.println(f.color);
		System.out.println(f.door);
		f.drive();
		f.stop();
		f.water();
		
		System.out.println("----------------------------");
		
		Car c = (Car) f;
		
		System.out.println(c.color);
		System.out.println(c.door);
		c.drive();
		c.stop();
//		c.water(); 오류
		
		System.out.println("----------------------------");
		
		FireEngine f2 = (FireEngine) c;
		//			5개				4개 4개밖에 없지만 형변환으로 인해 5개
		//
		System.out.println(f2.color);
		System.out.println(f2.door);
		f2.drive();
		f2.stop();
		f2.water();
		
//		Ambulance a = (Ambulance) f; //상속관계가 아니므로 클래스의 형변환 불가능
		System.out.println("----------------------------");
		
		Car car = null;
		FireEngine fe = new FireEngine();
		FireEngine fe2 = null;
		
		fe.water();
		car = fe; //형변환 생략해도 실행됨
//		car.water();
		
		fe2 = (FireEngine) car;
		
		fe2.water();
		
//		1. 참조변수의 타입과 인스턴스의 타입은 같을수도 있지만 다를수도 있다.
//		2. 참조변수의 타입이 조상일때와 자손일때의 차이접은 사용할 수 있는 멤버의 개수가 달라짐
//		3. 조상타입의 참조변수로 자손타입의 객체를 사용하는 것은 O 자손타입의 참조변수로 조상타입의 객체를 사용 X
	}
}
