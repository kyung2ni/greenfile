package day0226;

public class InstanceofExample {
	public static void personInfo(Person person) {
		System.out.println("name : "+person.name);
		person.walk();
		//JDK11버전까지 사용했던 방법
		if (person instanceof Student) {
			Student stu = (Student) person;
			stu.study();	
		}
		
		//JDK12버전부터 사용가능
		if (person instanceof Student s) {
			s.study();
		}
	}
	
	public static void main(String[] args) {
		Person p1 = new Person("김그린");
		personInfo(p1);
		
		Person s1 = new Student("이자바", 10);
		personInfo(s1);
	}
}
