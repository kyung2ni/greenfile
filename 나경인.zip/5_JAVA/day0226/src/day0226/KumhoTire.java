package day0226;

public class KumhoTire extends Tire{

	public void roll() {
		System.out.println("금호 타이어가 회전합니다.");
	}
}
