package game;

import java.util.Scanner;

public class DamagochiMain {
	public static void main(String[] args) {
		boolean run = true;
		Scanner scan = new Scanner(System.in);
		Damagochi c = null;
		
		
		System.out.println("-----------------------------------");
		System.out.println("1.피카츄 | 2.이상해씨 | 3.꼬부기");
		System.out.println("-----------------------------------");
		System.out.print("선택 > ");
		int cPick = scan.nextInt();
		
		if (cPick == 1) {
			c = new Pikachu();
		} else if (cPick == 2) {
			c = new Isanghaessi();
		} else if (cPick == 3) {
			c = new Kkobugi();
		} else {
			System.out.println("다시 선택하세요");
		}
		int eatCount = 0;
		int sleepCount = 0;
		int practiceCount = 0;
		
		while(run) {
			System.out.println("-----------------------------------");
			System.out.println("1.밥먹기 | 2.잠자기 | 3.놀기 | 4.연습하기");
			System.out.println("-----------------------------------");
			System.out.print("선택 > ");
			int Pick = scan.nextInt();
			switch (Pick)  {
				case 1 : 
					if (eatCount>1) {
						System.out.println("배가 너무 부릅니다");
						break;
					}
					c.eat();
					eatCount++;
					practiceCount--;
					break;
				case 2 :
					if (sleepCount>0) {
						System.out.println("피곤하지 않습니다");
						break;
					}
					c.sleep();
					sleepCount++;
					practiceCount = 0;
					break;
				case 3 :
					c.play();
					eatCount--;
					sleepCount--;
					if (eatCount < 0) {
						eatCount = 0;
					}
					if (sleepCount < 0) {
						sleepCount = 0;
					}
					break;
				case 4 :
					if (practiceCount>1) {
						System.out.println("지쳤습니다");
						break;
					}
					c.practice();
					practiceCount++;
					eatCount--;
					sleepCount--;
					if (eatCount < 0) {
						eatCount = 0;
					}
					if (sleepCount < 0) {
						sleepCount = 0;
					}
					break;
				default :
					System.out.println("다시 선택하세요.");
					continue;
			}
		}
		
	}
}
