package game;

public class Pikachu extends Damagochi{

	
	Pikachu() {
		System.out.println("피카츄가 생성되었습니다");
		create();
	}
	@Override
	void create() {
		exp = 30;
		energy = 50;
		level = 1;
		maxExp = 40;
		eat = 10;
		sleep = 5;
		play = 20;
		playExp = 5;
		practice = 15;
		practiceExp = 20;
		
	}

	
}
