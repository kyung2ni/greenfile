package game;

public class Isanghaessi extends Damagochi{
	Isanghaessi() {
		System.out.println("이상해씨가 생성되었습니다");
		create();
	}
	
	@Override
	void create() {
		exp = 20;
		energy = 30;
		level = 1;
		maxExp = 35;
		eat = 5;
		sleep = 20;
		play = 10;
		playExp = 15;
		practice = 10;
		practiceExp = 20;
		
	}

}
