package game;

public abstract class Damagochi {

	int exp;
	int energy;
	int level;
	int maxExp;
	int eat;
	int sleep;
	int play;
	int playExp;
	int practice;
	int practiceExp;
	
	abstract void create();
	
	void status() {
		System.out.printf("레벨 : %d / 경험치 : %d / 에너지 : %d \n",level,exp,energy);
		
	}

	void eat() {
		energy += eat;
		System.out.printf("밥을 먹고 에너지를 회복했습니다 (에너지 +%d)\n",eat);
		playing();
		status();
		
	}

	void sleep() {
		energy += sleep;
		System.out.printf("잠을 자서 에너지를 회복했습니다 (에너지 +%d)\n",sleep);
		playing();
		status();
	}

	void play() {
		energy -= play;
		exp += playExp;
		System.out.printf("놀았습니다 (에너지 -%d, 경험치 -%d)\n",play,playExp);
		playing();
		status();
	}

	void practice() {
		energy -= practice;
		exp += practiceExp;
		System.out.printf("열심히 훈련했습니다 (에너지 -%d, 경험치 +%d)\n",practice,practiceExp);
		playing();
		status();
	}
	
	void playing() {
		if (exp >= maxExp) {
			level++;
			exp -= maxExp;
			System.out.println("------------레벨이 올랐습니다------------");
		}
		if (energy <= 0) {
			System.out.println("-----------다마고치가 죽었습니다-----------");
			status();
			System.exit(0);
		}
	}
}
