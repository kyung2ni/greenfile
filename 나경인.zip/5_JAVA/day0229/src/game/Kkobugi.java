package game;

public class Kkobugi extends Damagochi{
	Kkobugi() {
		System.out.println("꼬부기가 생성되었습니다");
		create();
	}
	
	@Override
	void create() {
		exp = 40;
		energy = 50;
		level = 1;
		maxExp = 50;
		eat = 15;
		sleep = 10;
		play = 30;
		playExp = 15;
		practice = 20;
		practiceExp = 30;
		
	}
		
}
