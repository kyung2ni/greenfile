
public class TryCatch3 {
	public static void main(String[] args) {
		
		int[] arr = new int[3];
		int i;
		try {
			for (i=0; i<3; i++) {
				arr[i] = i;
			}
			for (i=0; i<=3; i++) {
				System.out.println(arr[i]);
			} 
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} finally {
			System.out.println("무조건 실행");
		}
	}
}
