
public class TryCatch1 {
	public static void main(String[] args) {
		System.out.println(1);
		try {
			System.out.println(2);
			int a = 100;
			String b = "100a";
			System.out.println(a+Integer.parseInt(b));
			System.out.println(0/0);
			System.out.println(3);
		} catch(Exception e ) {
			//발생한 예외가 ArithmeticException이면
			//'숫자는 0으로 나눌 수 없습니다.' 출력
			if (e instanceof ArithmeticException) {
				System.out.println("숫자는 0으로 나눌 수 없습니다.");
			} else if (e instanceof NumberFormatException) {
				System.out.println("숫자의 형식에 맞지 않습니다.");
			}
		}
		System.out.println(5);
	}
}
