
public class Throws1 {
	
	static void method1() throws Exception /*throws Exception*/{
		try {
			method2();
		} catch(Exception e) {
			System.out.println("예외를 처리합니다.");
			throw e;
		}
	}
	
	static void method2() throws Exception{ //폭탄던지기
//		System.out.println("출력");
		throw new Exception();
	}
	
	public static void main(String[] args) throws Exception{
		try {
			method1();
		} catch(Exception e) {
			System.out.println("main에서 해결");
		}
		
//		try {
//			method1();
//		} catch(Exception e) {
//			System.out.println("예외처리");
//		}
	}
}
