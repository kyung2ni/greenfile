package game22;

public class Picachu extends Character{
	
	Picachu() {
		hp = 30;
		energy = 50;
		System.out.println("피카츄가 생성되었습니다.");
	}
	@Override
	void eat() {
		energy += 10;
	}

	@Override
	void sleep() {
		energy += 5;
	}

	@Override
	boolean play() {
		energy -= 20;
		hp += 5;
		levelUp();
		return checkEnergy();
	}

	@Override
	boolean train() {
		energy -= 15;
		hp += 20;
		levelUp();
		return checkEnergy();
	}
	@Override
	void levelUp() {
		if (hp >=40) {
			level++;
			hp -= 40;
		}
		
		
	}
	
}
