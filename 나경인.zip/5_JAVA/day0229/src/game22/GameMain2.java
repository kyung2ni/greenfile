package game22;

import java.util.Scanner;

public class GameMain2 {
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		Character character = null; //생성한 캐릭터 저장
		PlayGame pg = null; //게임 진행을 위한 참조변수
		
		System.out.println("원하는 캐릭터를 선택하세요 \n1)피카츄 2)이상해씨 3)꼬부기");
		int x = scan.nextInt();
		
		switch (x) {
			case 1 :
				character = new Picachu();
				break;
			case 2 :
				character = new Lee();
				break;
			case 3 :
				character = new Gobook();
				break;
			default :
				System.out.println("캐릭터를 다시 선택하세요.");
				break;
		}
		
		
		if (character == null) {
			System.out.println("게임을 종료합니다");
			return;
		} else {
			pg = new PlayGame(character);
		}
		
		while(true) {
			pg.printMenu(scan);
			
			if (pg.exit()) {
				System.out.println("게임을 종료합니다");
				break;
			}
		}
//		exit : while(!isExit) {
//			System.out.println("----------------------------------------");
//			System.out.println("1)밥먹기 2)잠자기 3)놀기 4)운동하기 5)종료");
//			System.out.println("----------------------------------------");
//			int menu = scan.nextInt();
//			switch (menu) {
//				case 1 :
//					System.out.println("밥을 먹어요");
//					character.eat();
//					character.printInfo();
//					break;
//				case 2 :
//					System.out.println("잠을 자요");
//					character.sleep();
//					character.printInfo();
//					break;
//				case 3 :
//					System.out.println("놀아요");
//					isExit = character.play();
//					character.printInfo();
//					break;
//				case 4 : 
//					System.out.println("운동을 해요");
//					isExit = character.train();
//					character.printInfo();
//					break;
//				case 5 :
//					System.out.println("종료합니다");
//					break exit;
//					
//			}
//		}
	}
}
