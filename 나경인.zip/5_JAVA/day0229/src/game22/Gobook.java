package game22;

public class Gobook extends Character{
	
	Gobook() {
		hp = 40;
		energy = 50;
		System.out.println("꼬부기가 생성되었습니다.");
	}
	@Override
	void eat() {
		energy += 15;
	}

	@Override
	void sleep() {
		energy += 10;
	}

	@Override
	boolean play() {
		energy -= 30;
		hp += 15;
		levelUp();
		return checkEnergy();
	}

	@Override
	boolean train() {
		energy -= 20;
		hp += 30;
		levelUp();
		return checkEnergy();
	}
	@Override
	void levelUp() {
		if (hp >= 50) {
			level++;
			hp -= 50;
		}
		
		
	}
	
}
