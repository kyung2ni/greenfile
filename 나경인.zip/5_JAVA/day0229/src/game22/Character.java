package game22;

public abstract class Character {
	int hp =0;
	int level =1;
	int energy =0;
	
	abstract void eat();
	abstract void sleep();
	abstract boolean play();
	abstract boolean train();
	abstract void levelUp();
	
	//에너지 확인
	boolean checkEnergy() {
		if (energy <= 0) {
			System.out.println("에너지가 0보다 작으므로 사망합니다");
			return true;
		} else {
			return false;
		}
	}
	
	
	
	//정보 출력
	public void printInfo() {
		System.out.println("----------캐릭터 정보 확인----------");
		System.out.println("level : "+level);
		System.out.println("hp : "+hp);
		System.out.println("energy : "+energy);
		System.out.println();
	}
}
