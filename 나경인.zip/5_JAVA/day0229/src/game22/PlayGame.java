package game22;

import java.util.Scanner;

public class PlayGame {

	Character character = null;
	boolean isExit = false;
	int menu;
	
	PlayGame(Character character) {
		this.character = character;
	}

	public void printMenu(Scanner scan) {
		System.out.println("----------------------------------------");
		System.out.println("1)밥먹기 2)잠자기 3)놀기 4)운동하기 5)종료");
		System.out.println("----------------------------------------");
		play();
	}
	public void play() {
		switch (menu) {
			case 1 :
				System.out.println("밥을 먹어요");
				character.eat();
				break;
			case 2 :
				System.out.println("잠을 자요");
				character.sleep();
				break;
			case 3 :
				System.out.println("놀아요");
				isExit = character.play();
				break;
			case 4 : 
				System.out.println("운동을 해요");
				isExit = character.train();
				break;
			case 5 :
				System.out.println("종료합니다");
				isExit = true;	
		}
		character.printInfo();
	}
	
	boolean exit() {
		return isExit;
	}
}
