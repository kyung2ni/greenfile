
public class ExceptionTest {
	public static void main(String[] args) {
		try {
		int[] a = {1,2,3};
		System.out.println(a[5]);
		
		int result = a[1];
		System.out.println(result);
		} catch(Exception e ) {
			System.out.println("오류 발생");
		}
	}
}
