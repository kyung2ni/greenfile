import java.util.Scanner;

public class Throw2 {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		try {
			//1~100사이의 숫자만 입력
			while(true) {
				System.out.print("숫자 입력 > ");
				int num = scan.nextInt();
				if (num < 0 || num > 100) {
					throw new Exception(); //강제로 예외 만들기
				} 
			}
		} catch(Exception e) {
			System.out.println("예외발생");
		}
		System.out.println("출력");
			
		
	}
}
