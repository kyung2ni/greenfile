
public class TryCatch2 {
	public static void main(String[] args) {
		System.out.println(1);
		try {
			System.out.println(2);
			System.out.println(0/0);
			int a = 100;
			String b = "100a";
			System.out.println(a+Integer.parseInt(b));
			
			System.out.println(3);
		} catch(ArithmeticException | NumberFormatException ae) {
			
			//발생한 예외가 ArithmeticException이면
			//'숫자는 0으로 나눌 수 없습니다.' 출력
			System.out.println("NumberFormatException");
		} catch(Exception e) { //Exception <<은 캐치블럭 가장 아래
			System.out.println("Exception!!!!!");
		} finally { // 무조건 실행되어야 하는 부문
			System.out.println("끝!!!!!!");
		}
//		} catch(NumberFormatException ne) {
//			System.out.println("NumberFormatException");
//		}
		System.out.println(5);
		
	}
}
