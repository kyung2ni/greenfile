package day0308;

import java.util.HashSet;

public class HashSetTest3 {
	public static void main(String[] args) {
		HashSet set = new HashSet();
		
		
		set.add("abc");
		set.add("abc");
		set.add(new Person("aaa",10));
		set.add(new Person("aaa",10));
		System.out.println(set);
	}
}
