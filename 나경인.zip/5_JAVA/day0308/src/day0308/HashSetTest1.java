package day0308;

import java.util.*;

public class HashSetTest1 {
	public static void main(String[] args) {
	
			Object[] objArr = {"1",new Integer(1),"1","2","2","3","3","4","4","4"};
//			System.out.println(Arrays.toString(object));
			Set set = new HashSet();
//			List set = new ArrayList();
			
			for (int i=0; i<objArr.length; i++) {
				System.out.println(objArr[i]+"="+set.add(objArr[i]));
			}
			System.out.println(set);
	}
}
