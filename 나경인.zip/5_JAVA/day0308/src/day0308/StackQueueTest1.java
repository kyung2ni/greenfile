package day0308;

import java.util.*;

public class StackQueueTest1 {
	public static void main(String[] args) {
		Stack s = new Stack();
		Queue q = new LinkedList(); //Queue 인터페이스를 구현한 클래스
		
		s.push("0");
		s.push("1");
		s.push("2");
		
		q.offer("0");
		q.offer("1");
		q.offer("2");
		
		System.out.println("stack----");
		System.out.println("0의 위치 : "+ s.search("0") );
		while(!s.empty()) {
			System.out.println(s.pop());
		}
		System.out.println("queue----");
		while(!q.isEmpty()) {
			System.out.println(q.poll());
		}
	}
}
