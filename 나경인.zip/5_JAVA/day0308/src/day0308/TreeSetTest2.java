package day0308;

import java.util.TreeSet;

public class TreeSetTest2 {
	public static void main(String[] args) {
		TreeSet set = new TreeSet();
		
		set.add("abc");      set.add("alien");    set.add("bat");
		set.add("car");      set.add("Car");     set.add("dddd");
		set.add("disc");	 set.add("dance");    set.add("dZZZZ");    
		set.add("elephant"); set.add("elevator"); set.add("fan");
		set.add("flower"); set.add("dzz");
		System.out.println(set);
		
		String from = "b";
		String to = "d";
		
		System.out.println(set.subSet(from, to));//b 이상 d 미만
		System.out.println(set.subSet(from, to+"zzz"));
		System.out.println(set.headSet("c"));//c 이전까지 
		System.out.println(set.tailSet("c"));//c 부터 끝까지

	}
}
