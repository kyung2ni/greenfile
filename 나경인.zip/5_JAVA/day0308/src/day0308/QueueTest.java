package day0308;

import java.util.*;

class Message {
	public String command;
	public String to;
	
	public Message(String command, String to) {
		this.command = command;
		this.to = to;
	}
}

public class QueueTest {
	public static void main(String[] args) {
		Queue<Message> messageQueue = new LinkedList<>();
//		Stack<Message> messageQueue2 = new Stack<>();
		
		messageQueue.offer(new Message("kakao","김그린"));
		messageQueue.offer(new Message("SMS","이자바"));
		messageQueue.offer(new Message("Mail","정디비"));
		
		while(!messageQueue.isEmpty()) {
			Message msg = messageQueue.poll();
			
			switch(msg.command) {
			case "kakao" :
				System.out.println(msg.to+"님에게 카톡을 보냅니다");
				break;
			case "SMS" :
				System.out.println(msg.to+"님에게 문자를 보냅니다");
				break;
			case "Mail" :
				System.out.println(msg.to+"님에게 메일을 보냅니다");
				break;
			}
			
		}
	}
}
