package day0308;

public class HashSetTest2 {
	public static void main(String[] args) {
		
		Person p = new Person("abc",10);
		
		int hash1 = p.hashCode();
		int hash2 = p.hashCode();
		
		System.out.println(hash1);
		System.out.println(hash2);
		
		p.age = 20;
		
		int hash3 = p.hashCode();
		System.out.println(hash3);
		Person p1 = new Person("aaa",10);
		Person p2 = new Person("aaa",10);
		System.out.println(p1);
		System.out.println(p2);
		
		System.out.println(p1.equals(p2));
		
		System.out.println(p1.hashCode());
		System.out.println(p2.hashCode());
	}
}
