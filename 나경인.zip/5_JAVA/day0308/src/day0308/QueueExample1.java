package day0308;

import java.util.*;

public class QueueExample1 {
	public static void main(String[] args) {
		//help 를 입력하면 도움말을 볼 수 있습니다
		//help - 도움말을 보여줍니다.
		//q 또는 Q 프로그램을 종료합니다.
		//history - 최근에 입력한 명령어를 5개 보여줍니다
		boolean exit = true;
		Scanner scan = new Scanner(System.in);
		Queue<String> msg = new LinkedList<>();
//		int count = 1;
		final int MAX_SIZE = 5;
		
		System.out.println("help를 입력하면 도움말을 볼 수 있습니다.");
		while(exit) {
			System.out.print("명령어 >>");
			String ms = scan.nextLine();
			if ("".equals(ms)) { 
				continue;
			}
			msg.offer(ms);
			if (msg.size()>MAX_SIZE) {
				msg.remove();
			}
			switch(ms) {
			case "help" :
				System.out.println("help - 도움말을 보여줍니다.");
				System.out.println("q 또는 Q 프로그램을 종료합니다.");
				System.out.println("history - 최근에 입력한 명령어를 "+MAX_SIZE+"개 보여줍니다");
				break;
			case "Q","q" :
				System.out.println("프로그램을 종료합니다.");
				exit = false;
				break;
			case "history" :
				LinkedList list = (LinkedList) msg; 
				for (int i=0; i<list.size(); i++) {
					System.out.println((i+1)+". "+list.get(i));
				}
				//Iterator<String> iter = msg.iterator();
				//while(iter.hasNext()) {
				//	System.out.println(count+". "+iter.next());
				//	count++;
				//}
				break;
			}
		}
		
		
	}
}
