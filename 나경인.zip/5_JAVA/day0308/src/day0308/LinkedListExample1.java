package day0308;

import java.util.*;

public class LinkedListExample1 {
	public static void main(String[] args) {
		
		List<String> list1 = new ArrayList<>();
		List<String> list2 = new LinkedList<>();
		
		long startTime;
		long endTime;
		
		startTime =System.currentTimeMillis();
		for (int i=0; i<100000; i++) {
			list1.add(0,String.valueOf(i));
		}
		endTime = System.currentTimeMillis();
		
		System.out.println("ArrayList 소요시간 : "+(endTime-startTime)+"ms");
		
		startTime =System.currentTimeMillis();
		for (int i=0; i<100000; i++) {
			list2.add(0,String.valueOf(i));
		}
		endTime = System.currentTimeMillis();
		
		System.out.println("LinkedList 소요시간 : "+(endTime-startTime)+"ms");
	}
}
