package day0308;

import java.util.Stack;

class Coin {
	private int value;
	
	public Coin(int value) {
		this.value = value;
	}
	public int getValue() {
		return value;
	}
}

public class StackTest2 {
	public static void main(String[] args) {
		Stack<Coin> coinBox = new Stack<>();
		
		coinBox.push(new Coin(100));
		coinBox.push(new Coin(50));
		coinBox.push(new Coin(500));
		coinBox.push(new Coin(10));
		
		//peek() : 맨 위에 저장된 객체를 반환
		//실제 스택에서 객체를 꺼내지 않음. 확인을 위해 사용
		System.out.println(coinBox.peek().getValue());
		
		while(!coinBox.isEmpty()) {
			Coin coin = coinBox.pop(); //실제로 스택에서 내용을 꺼냄
			System.out.println("꺼낸 동전 : "+coin.getValue()+"원");
		}
		
		System.out.println(coinBox.search(500));
	}
}
