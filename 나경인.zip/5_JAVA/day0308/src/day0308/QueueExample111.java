package day0308;

import java.util.*;

public class QueueExample111 {
	
	static Queue q = new LinkedList<>();
	final static int MAX_SIZE = 5;
	
	public static void save(String input) {
		if (!"".equals(input)) q.offer(input);
		if (q.size() > MAX_SIZE) q.remove();
	}
	
	public static void main(String[] args) {
		//help 를 입력하면 도움말을 볼 수 있습니다
		//help - 도움말을 보여줍니다.
		//q 또는 Q 프로그램을 종료합니다.
		//history - 최근에 입력한 명령어를 5개 보여줍니다
		boolean exit = true;
		Scanner scan = new Scanner(System.in);
		final int MAX_SIZE = 5;
		
		System.out.println("help를 입력하면 도움말을 볼 수 있습니다.");
		while(exit) {
			System.out.print("명령어 >>");
			String input = scan.nextLine();
			
			if ("".equals(input)) {
				continue;
				
			} else if (input.equalsIgnoreCase("q")) {
				System.out.println("프로그램을 종료합니다.");				
				break;
				
			} else if (input.equalsIgnoreCase("help")) {
				save(input);
				System.out.println("help - 도움말을 보여줍니다.");
				System.out.println("q 또는 Q 프로그램을 종료합니다.");
				System.out.println("history - 최근에 입력한 명령어를 "+MAX_SIZE+"개 보여줍니다");				
			} else if (input.equalsIgnoreCase("history")) {
				save(input);
				LinkedList list = (LinkedList) q; 
				for (int i=0; i<list.size(); i++) {
					System.out.println((i+1)+". "+list.get(i));
				}
			} else {
				save(input);
			}
		}
		
		
	}
}
