package day0308;

import java.util.*;

public class StackExample1 {
	public static void main(String[] args) {
		
		String expression = "((5+6)*(3-2))";
		
		Stack st = new Stack();
		try {
			for(int i=0; i<expression.length(); i++) {
				char tmp = expression.charAt(i);
				if (tmp == '(') {
					st.push(tmp + "");
				} else if (tmp ==')') {
					st.pop();
				}
			}
			if (st.isEmpty()) {
				System.out.println("괄호 일치");
			} else {
				System.out.println("닫는 괄호가 일치하지 않습니다");
			}
			
		} catch(EmptyStackException e) {
			System.out.println("여는 괄호가 일치하지 않습니다");
		}
		

		
		
		//입력받은 수식의 괄호가 올바르게 작성된 경우에는
		//'괄호가 일치합니다'
		//괄호가 맞지 않는 경우에는
		//'여는 괄호가 일치하지 않습니다','닫는 괄호가 일치하지 않습니다' 출력
		
	}
	
}
