package day0220;

class Math{
	int add(int x,int y) {
		int result = x + y;
		return result;
	}
}

public class MathTest {
	public static void main(String[] args) {
		Math obj = new Math();
		
		int sum = obj.add(2,4);
		System.out.println("결과 : "+sum);
		
		sum = obj.add(5, 7);
		System.out.println("결과 : "+sum);
			
		obj.add(1,4);
	}
}
