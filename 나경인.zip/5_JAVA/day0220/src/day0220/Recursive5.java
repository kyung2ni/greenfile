package day0220;

public class Recursive5 {
	public static void main(String[] args) {
		System.out.println("n번째 피보나치의 위치는 :" +fibonacci(5));
	}
	public static int fibonacci(int n) {
		if (n==1) return 1;
		if (n==2) return 1;
		
		return fibonacci(n-1) + fibonacci(n-2);
		
		
		
	}
}
