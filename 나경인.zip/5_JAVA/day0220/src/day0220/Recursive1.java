package day0220;

public class Recursive1 {
	public static void main(String[] args) {
//		//5! = 5*4*3*2*1
//		int num = 5;
//		int sum = 1;
//		for (int i=num; i>=1; i--) {
//			sum *= i;
//		}
//		System.out.println(sum);
		
		long result = factorial(4);
		System.out.println("4! = "+result);
	}
	public static long factorial(int n) {
		long result = 0;
		
		if (n==1) {
			return 1;
		} else {
			result = n * factorial(n-1);
		}
		return result;
	}
}
