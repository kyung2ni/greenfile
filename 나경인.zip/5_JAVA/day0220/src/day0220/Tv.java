package day0220;

public class Tv {

	//멤버변수
	String color;	//색상
	boolean power;	//전원
	int channel;	//채널
	int volume;		//볼륨
	
	//메서드
	public void power() {
		power = !power;
	}
	public void channelUp() {
		++channel;
	}
	public void channelDown() {
		--channel;
	}
	
}
