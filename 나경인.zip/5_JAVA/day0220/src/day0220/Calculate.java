package day0220;

public class Calculate {
	long add(long a,long b) {
		long result = a+b;
		return result;
	}
	
	long subtract(long a ,long b) {
		return a-b;
	}
	long multiply(long a ,long b) {
		return a*b;
	}
	double divide(long a ,long b) {
		return (double)a/b;
	}
}
