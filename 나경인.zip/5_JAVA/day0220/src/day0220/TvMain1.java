package day0220;

public class TvMain1 {

	public static void main(String[] args) {
		
		//int[] score = new int[5];
		
		//객체 배열
		Tv[] tvArr1 = new Tv[3];
		
		//score[0] = 100;
		//score[1] = 90;
		
		tvArr1[0] = new Tv();
		tvArr1[1] = new Tv();
		tvArr1[2] = new Tv();
		
		//배열 초기화
		//int[] score = {1,2,3,4,5};
		
		Tv[] tvArr2 = {new Tv(), new Tv(), new Tv()};
		
		//int[] score = new int[100];
		
		//for (int i=0; i<score.length; i++) {
		//score[i] = i;
		//}
		
		Tv[] tvArr3 = new Tv[100];
		
		for (int i=0; i<tvArr3.length; i++) {
			tvArr3[i] = new Tv();
		}
	}
}
