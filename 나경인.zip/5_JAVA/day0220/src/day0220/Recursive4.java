package day0220;

import java.util.Scanner;

public class Recursive4 {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.print("알고싶은 피보나치의 위치 >> ");
		int count = scan.nextInt();
//		System.out.println(count+"번째 피보나치의 위치는 :" + fibonacci(count));
		System.out.println(count+"번째 피보나치의 위치는 :" + fibonacci2(count));
	}
	
	//피보나치 수열 : 숫자의 앞에 있는 값과 뒤의 값을 더하면서 계속해서 증가하는 규칙
	//1,1,2,3,5,8,13
	public static int fibonacci2(int n) {
		int num1 = 1;
		int num2 = 1;
		int num3 = 0;
		
		for (int i=0; i<n; i++) {
			if (i == 0 || i == 1 ) {
				num3 = 1;
				System.out.println(1+i+"번째 피보나치 : "+num3);
			} else {
				num3 = num1+num2;
				num1 = num2;
				num2 = num3;
				System.out.println(1+i+"번째 피보나치 : "+num3);
			}
	}
		return num3;
		
		
		
	}
//	public static int fibonacci(int n) {
//		int num = 1; //첫번째
//		int num2 = 1; //두번째
//		int t = num + num2;
//		int result = 0; 
//		int i = 3; //위치, 세번째
//
//		while (i<=n) {
//			if (n==1 ||n==2) {
//				result = 1;
//			}
//			result = t;
//			
//			num=num2;
//			num2=t;
//			t=num+num2;
//			i++;
//		}
//		return result;
//		
//
//		
//	}
}
