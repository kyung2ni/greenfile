package day0220;

public class ScoreMain {
	public static void main(String[] args) {
		
		Score s1 = new Score();
		
		s1.name = "김그린";
		s1.kor = 50;
		s1.eng = 30;
		s1.math = 60;
		s1.sumVal();
		s1.avgVal();
		
		s1.print(); //프린트 매번 쓸 필요없다
		
//		System.out.println("이름 : " + s1.name);
//		System.out.println("국어점수 : " + s1.kor);
//		System.out.println("영어점수 : " + s1.eng);
//		System.out.println("수학점수 : " + s1.math);
//		System.out.println("합계 : " + s1.sum);
//		System.out.println("평균 : " + s1.avg);
		
		Score s2 = new Score(); 
		
		s2.name = "이자바";
		s2.kor = 90;
		s2.eng = 100;
		s2.math = 67;
		s2.sumVal();
		s2.avgVal();
		
		s2.print(); 
		
//		System.out.println("이름 : " + s2.name);
//		System.out.println("국어점수 : " + s2.kor);
//		System.out.println("영어점수 : " + s2.eng);
//		System.out.println("수학점수 : " + s2.math);
//		System.out.println("합계 : " + s2.sum);
//		System.out.println("평균 : " + s2.avg);
				
		
	}
}
