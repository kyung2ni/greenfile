package day0220;

import java.util.Scanner;

public class AreaMain {
	public static void main(String[] args) {
		AreaCalculator ac = new AreaCalculator();
		
		Scanner scan = new Scanner(System.in);
		System.out.print("가로 : ");
		int w = scan.nextInt();
		System.out.print("세로 : ");
		int h = scan.nextInt();
		
		int area = ac.areaResult(w,h);
		
		System.out.printf("가로 길이가 %d이고 세로 길이가 %d인 직사각형의 넓이는 %d입니다",w,h,area);
		
		 
		
	}
}
