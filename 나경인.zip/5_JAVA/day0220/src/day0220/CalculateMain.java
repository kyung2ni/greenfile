package day0220;

public class CalculateMain {
	public static void main(String[] args) {
		
		Calculate cal = new Calculate();
		
		long result1 = cal.add(1, 2);
		long result2 = cal.subtract(1, 2);
		long result3 = cal.multiply(1, 2);
		double result4 = cal.divide(1, 2);
		
		System.out.println("합계 :" + result1);
		System.out.println("빼기 :" + result2);
		System.out.println("곱하기 :" + result3);
		System.out.println("나누기 :" + result4);
		
	}
}
