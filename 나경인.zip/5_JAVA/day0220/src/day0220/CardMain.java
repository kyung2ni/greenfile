package day0220;

class Card{
	//인스턴스 변수
	String kind;
	int number;
	
	//클래스 변수
	static int width = 100;
	static int height = 250;
}

public class CardMain {
	//한 파일에는 하나의 클래스가 일반적
	//퍼블릭 붙은 클래스명과 파일명은 같아야함
	public static void main(String[] args) {
		
		Card c1 = new Card();
		c1.kind = "visa";
		c1.number = 1234;
		
		Card c2 = new Card();
		c2.kind = "master";
		c2.number = 5678;
		
		System.out.println("c1은 " + c1.kind+","+c1.number+"이며 크기는 ("+c1.width+","+c1.height+")");
		System.out.println("c2은 " + c2.kind+","+c2.number+"이며 크기는 ("+c2.width+","+c2.height+")");
		
		System.out.println("c1의 width와 height를 각각 50, 80으로 변경");
		
		c1.width = 50;
		c1.height = 80;
		
		System.out.println("c1은 " + c1.kind+","+c1.number+"이며 크기는 ("+c1.width+","+c1.height+")");
		System.out.println("c2은 " + c2.kind+","+c2.number+"이며 크기는 ("+c2.width+","+c2.height+")");
		
	}
	
}
