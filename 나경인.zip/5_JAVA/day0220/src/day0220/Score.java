package day0220;

public class Score {

	String name;
	int kor;
	int eng;
	int math;
	int sum;
	float avg;
	
	//총점
	public void sumVal() {
		sum = kor + eng + math;
	}
	
	//평균
	public void avgVal() {
		avg = (float) sum/3;
	}
	
	//출력
	public void print() {
		System.out.println("이름 : " + name);
		System.out.println("국어점수 : " + kor);
		System.out.println("영어점수 : " + eng);
		System.out.println("수학점수 : " + math);
		System.out.println("합계 : " + sum);
		System.out.println("평균 : " + avg);
	}
	
	
	
}
