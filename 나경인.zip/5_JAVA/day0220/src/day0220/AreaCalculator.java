package day0220;

public class AreaCalculator {
	int areaResult(int x,int y) {
		return x*y;
	}
	
}
