package day0304;

class Point implements Cloneable{
	int x;
	int y;
	
	@Override
	protected Object clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		return super.clone();
	}
}

public class ObjectClone1 {
	public static void main(String[] args) {
		
		Point p1 = new Point();
		//Point p2 = p1;//얕은 복사를 수행 (주소값 복사)
		Point p2 = null; //깊은 복사를 수행하기 위해 참조변수 선언
		try {
			p2 = (Point) p1.clone();			
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		}
		
		p1.x = 10;
		p1.y = 20;
		
		p2.x = 30;
		p2.y = 40;
		
		System.out.println("p1.x : "+p1.x);
		System.out.println("p1.y : "+p1.y);
		
		System.out.println("p2.x : "+p2.x);
		System.out.println("p2.y : "+p2.y);
		
		System.out.println("p1 : "+p1);
		System.out.println("p2 : "+p2);
	}
}
