package day0304;

public class StringMethod1 {
	public static void main(String[] args) {
		//indexOf() : 문자열이 존재하는지 확인하기 위해 위치를 알려줌
		//			  존재하지 않으면 -1을 리턴
		String str1 = "자바 프로그래밍";
		int location = str1.indexOf("a");
		
		System.out.println(location);
		
		//메일 주소 형식을 확인
		String email1 = "test@naver.com";
		String email2 = "testnaver.com";
		String email3 = "test@navercom";
		String email4 = "test.naver@com";
		
		emailTest(email1);
		emailTest(email2);
		emailTest(email3);
		emailTest(email4);
		//replace() : 기존 문자를 새로운 문자로 대체
		String old = "자바는 객체지향 언어. 자바는 재밌어요. 자바 최고다!!";
		String newStr = old.replace("자바","java");
		
		System.out.println(old);
		System.out.println(newStr);
		
		//subString() : 주어진 인덱스에서 문자열을 추출
		String ssn = "911111-1234567";
		
		String First = ssn.substring(0,6); //0부터 6미만
		System.out.println(First);
		String second = ssn.substring(7); //7인덱스부터 끝까지
		System.out.println(second);
		
		//valueOf() : 기본 타입의 값을 문자열로 변환
		int iVal = 100;
		String strVal = String.valueOf(iVal); // int 를 String 으로 변환
		
		double dVal = 200.2;
		String strVal2 = dVal+""; //기본형을 String 으로 변환하는 또다른 방범
		
		System.out.println(strVal+strVal2);//문자열로 바뀐걸 확인
		
		//문자열을 숫자로 변경하여 합계 계산
		double sum = Integer.parseInt(strVal)+Double.parseDouble(strVal2);
		System.out.println(sum);
		double sum2 = Integer.valueOf(strVal)+ Double.valueOf(strVal2);
		System.out.println(sum2);
		
		//split() :문자열을 구분자로 나눠 배열에 저장
		String animal = "dog,cat,bear";
		String[] arr = animal.split(",");
		System.out.println(arr[0]);
		System.out.println(arr[1]);
		System.out.println(arr[2]);
		
		//join() : 문자열 사이에 구분자를 넣어 결합
		System.out.println(String.join("-",arr));
		
	}
	public static void emailTest(String str) {
		//메일 주소가 맞는지 확인하는 메서드
		//1. 반드시 '@'가 있어야함
		//2. 반드시 '.'이 있어야함
		//3. 반드시 '@'는 '.'보다 먼저 나와야함
		int at = str.indexOf("@");
		int dot = str.indexOf(".");
		
		if(at != -1 && dot != -1 && at < dot) {
			System.out.println("맞음");
		} else {
			System.out.println("아님");
		}
		
	} 
}
