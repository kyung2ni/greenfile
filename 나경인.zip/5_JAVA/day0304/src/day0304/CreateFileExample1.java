package day0304;

import java.io.File;
import java.util.Scanner;

public class CreateFileExample1 {
	public static void main(String[] args) {
		try {
			Scanner s = new Scanner(System.in);
			System.out.println("파일명 > ");
			File f = createFile(s.nextLine());
			System.out.println(f.getName()+"파일이 생성되었습니다.");			
		} catch(Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	static File createFile(String fileName) throws Exception{
		if (fileName == null || fileName.equals("")) {
			throw new Exception("파일이름이 유효하지 않습니다");
		}
		File f = new File(fileName); //file 클래스의 객체 생성
			f.createNewFile(); // 실제 파일 생성 메서드
			
		return f;
	}
}
