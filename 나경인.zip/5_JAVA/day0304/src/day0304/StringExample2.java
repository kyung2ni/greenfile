package day0304;

import java.util.Scanner;

public class StringExample2 {
	public static void main(String[] args) {
		//사용자에게 한글자를 입력받아 
		//입력받은 문자가 영어인지 숫자인지 출력
		
		//방법1
		Scanner s = new Scanner(System.in);
		
		String al = "abcedfghijklnmopqrstuvwxyz";
		String num = "1234567890";
		
		String sc = s.nextLine();
		
		int eng = al.indexOf(sc);
		int n = num.indexOf(sc);
		
		if (eng != -1) {
			System.out.println("영어");
		} else if (n != -1){
			System.out.println("숫자");
		} else {
			System.out.println("잘못된 입력");
		}
		
		//방법2. 아스키코드로 비교
		//charAt() : 특정 위치의 문자열 리턴
		int s2 = sc.charAt(0);
		
		if ((s2>=65 &&s2<=90) || (s2>=97 && s2<=122)) {
			System.out.println("영어");
		} else if (s2>=48&& s2<=57) {
			System.out.println("숫자");
		}
		
	}
}
