package day0304;

public class StringGetBytes {
	public static void main(String[] args) {
		//getBytes() : 시스템의 기본 문자셋으로 인코딩왼 바이트 배열을 리턴
		
		String str = "안녕하세요";
		
		byte[] bytes1 = str.getBytes();
		System.out.println("bytes1.length :" +bytes1.length);
		String str1 = new String(bytes1);
		System.out.println(str1);
		try {
			byte[] bytes2 = str.getBytes("EUC-KR");
			System.out.println(bytes2.length);
			String str2 = new String(bytes2,"EUC-KR");
			System.out.println(str2);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}
}
