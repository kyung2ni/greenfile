package day0304;

import java.util.Scanner;

public class StringExample1 {
	//사용자에게서 공백을 포함한 문자열을 입력받아
	//총 몇개의 단어가 있는지 출력하세요.
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.print("단어 입력 > ");
		
		String a = s.nextLine();
		String[] arr = a.split(" ");
		
		System.out.println("단어 개수 : "+arr.length);
		for (String i : arr) {
			System.out.print(i+",");
		}
	}
	
}
