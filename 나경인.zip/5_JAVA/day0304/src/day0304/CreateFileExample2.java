package day0304;

import java.io.File;
import java.util.Scanner;

public class CreateFileExample2 {
	public static void main(String[] args) {
			Scanner s = new Scanner(System.in);
			System.out.println("파일명 > ");
			File f = createFile(s.nextLine());
			System.out.println(f.getName()+"파일이 생성되었습니다.");			

	}
	
	static File createFile(String fileName) {
		try {			
			if (fileName == null || fileName.equals("")) {
				throw new Exception("파일이름이 유효하지 않습니다");
			}
		} catch (Exception e) {
			fileName= "제목없음.txt";
		} finally {
			File f = new File(fileName); //file 클래스의 객체 생성
			createNewFile(f); // 실제 파일 생성 메서드
			return f;			
		}
	}
	static void createNewFile(File f) {
		try {
			f.createNewFile();			
		} catch(Exception e) {
			
		}
	}
}
