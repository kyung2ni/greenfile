package day0304;

public class ExceptionExample2 {
	public static void main(String[] args) {
		int[] array = {1,2,3,4};
		
		//array배열의 값을 출력하고
		//배열의 범위가 벗어나는 경우
		//'인덱스 초과'로 표시되도록 설정
		try {
//			System.out.println(array[5]);			
			for (int a : array) {
				System.out.println(a + ", ");
			}
		} catch(ArrayIndexOutOfBoundsException ae) {
			System.out.println("인덱스 초과");
		}
		
	}
}
