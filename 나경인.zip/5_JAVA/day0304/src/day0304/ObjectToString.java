package day0304;

class Test1 {
	@Override
	public String toString() {
		return "toString() 오버라이딩!!!!";
	}
}

class Test2 {
	public int x=10;
	public int y=20;
	
	@Override
	public String toString() {
		return "x : "+x+",y : "+y;
	}
}

public class ObjectToString {
	public static void main(String[] args) {
		Test1 t1 = new Test1();
		t1.toString();
		System.out.println(t1.toString());
		
		Test2 t2 = new Test2();
		t2.toString();
		System.out.println(t2.toString());
	}
}
