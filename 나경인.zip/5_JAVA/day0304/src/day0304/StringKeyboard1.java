package day0304;

import java.io.IOException;

public class StringKeyboard1 {
	public static void main(String[] args) throws IOException{
		byte[] bytes = new byte[100];
		
		System.out.print("입력 > ");
		int readByteNo = System.in.read(bytes);
		
		//carriage return(13) :커서를 해당 줄의 처음으로 옮김
		//lineFeed(10) : 커서를 해당 줄의 다음줄로 옮김
		
		String str = new String(bytes,0,readByteNo-2);
		System.out.println(str);
		System.out.println();
		
		
	}
}
