package day0304;

import java.util.InputMismatchException;
import java.util.Scanner;

public class ResourcesExample1 {
	public static void main(String[] args) {
//		Scanner scan = new Scanner(System.in);
		
		try(Scanner scan = new Scanner(System.in)) { //scan 과 close 다 해줌			
			int num1 = scan.nextInt();
			int num2 = scan.nextInt();
			
			int result = num1 + num2;
			System.out.println(result);
			
		} catch(InputMismatchException ie) {
			System.out.println("숫자로 입력하세요");
		} /*finally {
			scan.close();			
		}*/
	}
}
