package day0304;

class Value {
	int num;
	
	Value(int num){
		this.num=num;
	}
	
	@Override
	public boolean equals(Object obj) {
//		Value v = (Value) obj; // 다형성, 강제 형변환
//		return this.num == v.num;
	
		if (obj instanceof Value) {
			Value v =(Value)obj;
			return this.num == v.num;
		} else {
			return false;
		}
	}
}

public class ObjectEquals1 {
	public static void main(String[] args) {
		Value v1 = new Value(10);
		Value v2 = new Value(10);
		
		System.out.println(v1 ==v2); //주소비교 false
		//객체의 주소를 비교 false
		if (v1.equals(v2)) {
			System.out.println("v1과 v2는 같습니다");
		} else {
			System.out.println("v1과 v2는 다릅니다");
		}
		
		v2 = v1;
		if (v1.equals(v2)) {
			System.out.println("v1과 v2는 같습니다");
		} else {
			System.out.println("v1과 v2는 다릅니다");
		}
	}
}
