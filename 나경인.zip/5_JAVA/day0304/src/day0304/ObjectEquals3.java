package day0304;

import java.util.Scanner;

public class ObjectEquals3 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
				
		String id = "green";
		String pw="1234";
		System.out.print("id > ");
		String id_str = sc.next();
		
		System.out.print("pw > ");
		String id_pwd = sc.next();
		
		if (id.equals(id_str) && pw.equals(id_pwd)){
			System.out.println("로그인 성공");
		} else {
			System.out.println("로그인 실패");
		}
	}
}
