package day0304;

class Member {
	public String id;
	
	public Member(String id) {
		this.id = id;
	}
	
	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		if (!(obj instanceof Member)) return false;
			
		
		Member m = (Member) obj;
		return this.id == m.id;
	}
}

public class ObjectEquals2 {
	public static void main(String[] args) {
		Member m1 = new Member("blue");
		Member m2 = new Member("blue");
		Member m3 = new Member("red");
		System.out.println("m1과 m2 비교");
		System.out.println(m1.equals(m2));
		
		System.out.println("m1과 m3 비교");
		System.out.println(m1.equals(m3));
		
	}
}
