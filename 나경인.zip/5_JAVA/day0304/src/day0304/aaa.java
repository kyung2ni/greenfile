package day0304;

public class aaa {
	/*
	 *
	 * 리소스 
	 * 	데이터를 제공하는 객체
	 * 	리소스는 사용하기 위해 열어야(open) 하며, 사용이 끝난 다음에는 닫아야(close) 함
	 * 	리소스를 사용하다가 예외가 발생될 경우에도 안전하게 닫는 것이 중요
	 * 	try-with-resources 블록을 사용하면 예외발생 여부와 상관없이 리소스를 자동으로 닫아줌
	 * 
	 * 사용자정의 예외 만들기
	 * 	기존의 예외클래스를 상속받아서 새로운 예외 클래스를 정의할 수 있다.
	 * 	에러코드를 저장할 수 있게 ERR_CODE 와 getErrCode() 를 멤버로 추가
	 * 
	 * java.base
	 * 	모든 모듈이 의존하는 기본 모듈로, 모듈 중 유일하게 requires 하지 않아도 사용할 수 있음
	 * 
	 * 	java.lang 자바 언어의 기본 클래스를 제공
	 * 	java.util 자료 구조와 관련된 컬렉션 클래스를 제공
	 * 	java.text 날짜 및 숫자를 원하는 형태의 문자열로 만들어 주는 포맷 클래스를 제공
	 * 	java.time 날짜 및 시간을 조작하거나 연산하는 클래스를 제공
	 * 	java.io 입출력 스트림 클래스를 제공
	 * 	java.net 네트워크 통신과 관련된 클래스를 제공
	 *  java.nio 데이터 저장을 위한 Buffer 및 새로운 입출력 클래스 제공
	 *  
	 * java.lang 패키지의 주요 클래스와 용도
	 *	자바 언어의 기본적인 클래스를 담고 있는 패키지
	 *	이 패키지에 있는 클래스와 인터페이스는 import 없이 사용할 수 있음
	 *	Object	자바 클래스의 최상위 클래스로 사용
	 *	System	키보드로부터 데이터를 입력받을 때 사용
	 *			모니터(콘솔)로 출력하기 위해 사용
	 *			프로세스를 종료시킬 때 사용
	 *			진행 시간을 읽을 때 사용
	 *			시스템 속성(프로퍼티)를 읽을 때 사용
	 *	문자열 관련
	 *		String	문자열을 저장하고 조작할 때 사용
	 *		StringBuilder	효율적인 문자열 조작 기능이 필요할 때 사용
	 *		java.util.StringTokenizer	구분자로 연결된 문자열을 분리할 때 사용
	 *	포장 관련
	 *		기본 타입의 값을 포장할 때 사용
	 *		문자열을 기본 타입으로 변환할 때 사용
	 *	Math	수학 계산이 필요할 때 사용
	 *	Class	클래스와 메타 정보(이름, 구성멤버)등을 조사할 때 사용 
	 * 
	 * Object 클래스의 메서드
	 * 	notify(), wait() 등은 쓰레드와 관련된 메서드이다
	 * 	equals(), hashCode(),thString은 적절히 오버라이딩해야 한다
	 * 	protected Object clone() 	객체 자신의 복사본을 반환한다
	 * 	public boolean equals(Object obj)	객체 자신과 객체 obj가 같은 객체인지 알려준다 같으면 true
	 * 	protected void finalize()	객체가 소멸될 때 가비지 컬렉터에 의해 자동적으로 호출된다. 이 때 수행되어야 하는 코드가 있는 경우에만 오버라이딩 한다
	 * 	public Class getClass()	객체 자신의 클래스정보를 담고 있는 Class 인스턴스를 반환한다
	 * 	public int hashCode() 	객체 자신의 해시코드를 반환한다
	 * 	public String toString()	객체 자신의 정보를 문자열로 반환한다
	 * 	public void notify()	객체 자신을 사용하려고 기다리는 쓰레드를 하나만 깨운다
	 * 	public void notifyAll() 객체 자신을 사용하려고 기다리는 모든 쓰레드를 깨운다
	 * 	public void wait 	다른 쓰레드가 notify()나 notifyAll()을 호출할 때까지 현재 쓰레드를 무한히 또는
	 * 	(long timeout		지정된 시간(timeout, nanos)동안 기다리게 한다(timeout은 천분의 1초,nanos 는 10*9분의1초)
	 *  	
	 * 객체 해시코드 (hashCode() 
	 * 	객체를 식별하는 하나의 정수값
	 * 	Object 클래스의 hashCode() 메소드는 객체 메모리번지 이용하여 해시코드를 만들어 리턴
	 * 		객체마다 다른값 가짐(객체의 내부주소를 반환)
	 * 	다량의 데이터를 저장&검색하는 해싱기법에 사용
	 * 	두 객체가 동등한지 비교 필요
	 * 	 public int hashCode()
	 * 	hashCode()가 리턴하는 정수값이 같은지 확인하고,
	 * 	equals()메소드가 true를 리턴하는지 확인해서 동등 객체임을 판단
	 * 
	 * ***	equals()를 오버라이딩하면, hashCode()도 같이 오버라이딩 해야한다
	 * 		equals()의 결과가 true 인 두 객체의 hash code 는 같아야하기 때문  ***
	 * 
	 * clone()
	 * 	객체 자신ㅇ르 복제해서 새로운 객체를 생성하는 메서드
	 * 	Cloneable 인터페이스를 구현한 클래스의 인스턴스만 복제할 수 있다
	 * 	Object 클래스에 정의된 clone()은 인스턴스변수의 값만을 복제한다
	 * 	인스턴스변수가 참조형일 때, 참조하는 객체도 복제되게 오버라이딩해야함
	 * 	
	 * 	얕은 복사 : 주소값 복사(참조형)
	 * 	깊은 복사 : '값'을 새로운 메모리공간에 복사(기본형)
	 * 깊은 복사를 하기 위한 3가지 조건
	 * 	1. Cloneable 인터페이스를 implements 하기
	 * 	2. clone()메소드를 override 하기
	 * 	3. try - catch 구문을 이용해 CloneNotSupportedException 던지기
	 * 
	 * getClass()
	 * 	자신이 속한 클래스의 Class 객체를 반환하는 메서드
	 * 	Class 객체는 클래스의 모든 정보를 담고 있으며, 클래스당 단 1개만 존재
	 * 	클래스파일(*.class)이 메모리에 로드될때 생성된다
	 * 
	 * String 클래스
	 * 	String 클래스는 문자열을 저장하고 조작할 때 사용
	 * 	문자열 리터럴은 자동으로 String 객체로 생성 String 클래스의 다양한 생성자를 이용해서 직접 객체를 생성할 수도 있음
	 * 
	 * String 클래스의 특징
	 * 	문자열 배열 char[]과 그에 관련된 메서드들이 정의되어 있다.
	 * 	*String 인스턴스의 내용은 바꿀 수 없다(immutable)*
	 * 
	 * 바이트 배열로 변환 getBytes()
	 *	getBytes()의 메소드는 시스템의 기본 문자셋으로 인코딘된 바이트 배열 리턴
	 *	getBytes(Charset charset)메소드는 특정 문자셋으로 인코딩된 바이트 배열 리턴
	 * 
	 */
}
