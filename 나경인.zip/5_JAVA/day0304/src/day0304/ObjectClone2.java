package day0304;

//1. Cloneable 인터페이스를  implements 하기
class User implements Cloneable{
	String name;
	
	//2. clone() 메소드를 override 하기
	@Override
	protected Object clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		return super.clone();
	}
	
}

public class ObjectClone2 {
	public static void main(String[] args) {
		
		//얕은 복사 ( 값이 아닌 주소를 복사 )
		User user = new User();
		user.name = "김그린";
		User copy = user;
		
		System.out.println(user.hashCode());
		System.out.println(copy.hashCode());
		System.out.println(user.equals(copy));
		
		//깊은 복사 (값을 새로운 메모리에 복사)
		//3. try - catch 구문을 이용해
		//CloneNotSupportedException 처리
		
		try {
			User user2 = new User();
			user2.name = "이자바";
			User copy2 = (User) user2.clone();
			
			System.out.println(user2.hashCode());
			System.out.println(copy2.hashCode());
			System.out.println(user2.equals(copy2));
		} catch(CloneNotSupportedException e) {
			e.printStackTrace();
		}
		
	}
}
