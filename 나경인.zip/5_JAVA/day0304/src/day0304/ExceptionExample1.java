package day0304;

import java.util.InputMismatchException;
import java.util.Scanner;

public class ExceptionExample1 {
	public static void main(String[] args) {
		/*Scanner 를 이용하여 두개의 정수를 입력받아
		 * 곱셈과 나눗셈의 연산 결과를 출력하시오.
		 * 만약 문자를 입력한 경우에는
		 * 예외의 종류와 함계 ' 숫자를 입력하세요 ' 출력
		 * 나눗셈에 0을 입력한 경우애는 
		 * 예외의 종류와 함께 '0 이외의 값을 입력하세요' 출력
		 * */
		
		Scanner scan = new Scanner(System.in);
		try {
			System.out.print("숫자 1 > ");
			int x = scan.nextInt();
			System.out.print("숫자 2 > ");
			int y = scan.nextInt();
			int result1 = x*y;
			double result2 = (double)x/y;			
			System.out.printf("%d x %d = %d \n",x,y,result1);
			System.out.printf("%d / %d = %s \n",x,y,result2);
		} catch(InputMismatchException ie) {
			System.out.println(ie+ "숫자를 입력하세요");
		} catch(ArithmeticException ae) {
			System.out.println(ae+ "0이외의 값을 입력하세요");
		}
		
//		if (y==0) {
//			throw;
//		}
		
//		InputMismatchException
		
	}
}
