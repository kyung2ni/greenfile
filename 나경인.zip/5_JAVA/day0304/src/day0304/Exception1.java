package day0304;

class CarException extends Exception{
	public CarException (double gas) {
		super(gas + "는 0보다 작습니다");
	}
}

class Car {
	int num; 
	double gas;
	
	public Car() {
		num= 0;
		gas = 0.0;
		
		System.out.println("자동차가 생성됩니다.");
	}
	public void setCar(int num,double gas) throws CarException{
		if (gas < 0) {
			throw new CarException(gas);
		} else {
			
		}
		
		this.num = num;
		this.gas = gas;
		
		System.out.printf("차량번호 : %d ,연료량 : %f 로 설정되었습니다.\n",num,gas);
	}
	public void show() {
		System.out.println("차량번호 : "+num);
		System.out.println("연료량 : "+gas);
	}
}

public class Exception1 {
	public static void main(String[] args) {
		
		String str = null;
		
		Car car1 = new Car();
		try {
			car1.setCar(1234, 10.1);
			
		} catch (CarException e) {
			System.out.println(e);
		}
		car1.show();
	}
}
