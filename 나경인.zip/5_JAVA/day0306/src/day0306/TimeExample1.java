package day0306;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Month;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

public class TimeExample1 {
	public static void main(String[] args) {
		LocalDate now = LocalDate.now();
		LocalDate w = LocalDate.of(2024, 3, 6);
		System.out.println(now);
		System.out.println(w);
		
		LocalDate seoulNow = LocalDate.now(ZoneId.of("Asia/Seoul"));
		LocalDate nyNow = LocalDate.now(ZoneId.of("America/New_York"));
		LocalDate afNow = LocalDate.now(ZoneId.of("Africa/Addis_Ababa"));
		System.out.println("서울 : "+seoulNow);
		System.out.println("뉴욕 : "+nyNow);
		System.out.println("아프리카 : "+afNow);
		
		LocalDate plusMonth = now.plusMonths(1); 	//+1달
		LocalDate plusDays = now.plusDays(1);		//+1일
		LocalDate minusMonths = now.minusMonths(1);	//-1달
		LocalDate minusDays = now.minusDays(1);		//-1일
		
		System.out.println("+1달 "+ plusMonth);
		System.out.println("+1일 "+ plusDays);
		System.out.println("-1달 "+ minusMonths);
		System.out.println("-1일 "+ minusDays);
		
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd"); //날짜 형식 설정
		String formatedNow = now.format(dtf); //formatedNow에 저장
		System.out.println(formatedNow); //출력
		
		int year = now.getYear();
		Month month = now.getMonth();
		String month2 = now.getMonth().toString();
		int monthValue = now.getMonthValue();  
		int dayOfMonth = now.getDayOfMonth();
		int dayOfYear = now.getDayOfYear();
		DayOfWeek dayOfWeek = now.getDayOfWeek();
		String dayOfWeek2 = now.getDayOfWeek().toString();
		int dayOfWeekValue = now.getDayOfWeek().getValue();
		
		System.out.println(year);
		System.out.println(month);
		System.out.println(month2);
		System.out.println(monthValue);
		System.out.println(dayOfMonth);
		System.out.println(dayOfYear);
		System.out.println(dayOfWeek);
		System.out.println(dayOfWeek2);
		System.out.println(dayOfWeekValue);
		
		
		
	}
}
