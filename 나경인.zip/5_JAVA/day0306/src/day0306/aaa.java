package day0306;

public class aaa {
	/*
	 * java.time 패키지의 팩심 클래스
	 * 	날짜를 표현할 때는 LocalDate, 시간을 표현할 때는 LocalTime 을 사용
	 * 	날짜와 시간을 같이 표현할 때는 LocalDateTime을 사용
	 * 	시간대(time-zone)까지 다뤄야 할 때는 ZonedDateTime 을 사용
	 * 		LocalDateTime + 시간대 = ZonedDateTime
	 * 	Period 는 날짜간의 차이를, Duration 은 시간의 차이를 표현할 때 사용
	 * 		날짜 - 날짜 = Period 		시간 - 시간 = Duration
	 *  
	 * 	Temporal : 날짜와 시간을 표현하는 클래스들이 구현
	 * 		LocalDate, LocalTime, LocalDateTime, ZonedDateTime
	 * 	TemporalAmount : 날짜와 시간의 차이를 표현하는 클래스가 구현
	 * 		Period, Duration
	 * 	Temporal 로 시간하는 인터페이스들은 매개변수 타입으로 많이 사용되며,
	 * 	TemporalAmount인지 아닌지만 구별하면 된다
	 * 
	 * LocalDate 와 LocalTime
	 * 	java.time 패키지의 핵심. 이 두 클래스를 잘 이해하면 나머지는 쉬움
	 * 	now()는 현재 날짜 시간을, of()는 특정 날짜 시간을 지정할 때 사용
	 * 	일 단위나 초 단위로도 지정가능
	 * 	parse()로 문자열을 LocalDate 나 LocalTime으로 변환할 수 있다
	 * 	with(), plus(), minus()
	 * 
	 * 애너테이션
	 * 	코드에서 @로 작성되는 요소 클래스 또는 인터페이스를 컴파일하거나 실행할 때
	 * 	어떻게 처리해야 할 것인지를 알려주는 설정 정보
	 * 		1. 컴파일 시 사용하는 정보 전달
	 * 		2. 빌드 툴이 코드를 자동으로 생성할 때 사용하는 정보 전달
	 * 		3. 실행 시 특정 기능을 처리할 때 사용하는 정보 전달
	 * 
	 * 어노테이션 타입 정의와 적용
	 * 	@interface 뒤에 사용햘 어노테이션 이름 작성
	 * 		public @interface AnnotationName {}
	 * 
	 * 애너테이션 적용대상
	 * 	어노테이션을 적용할 수 있는 대상의 종류는 ElementType 열거 상수로 정의
	 * 	@Target 어노테이션으로 적용 대상 지정. @Target의 기본 속성 value 값은 ElementType 배열
	 * -------------------------------------------------------------
	 * 		ElementType 열거 상수		적용 요소
	 * -------------------------------------------------------------
	 * 		TYPE					클래스, 인터페이스, 열거 타입
	 * 		ANNOTATION_TYPE			어노테이션
	 * 		FIELD					필드
	 * 		CONSTRUCTOR				생성자
	 * 		METHOD					메소드
	 * 		LOCAL_CARIABLE			로컬 변수
	 * 		PACKAGE					패키지
	 * -------------------------------------------------------------
	 * 표준 애너테이션
	 * 	JAVA 에서 제공하는 애너테이션
	 * 	@Override				컴파일러에게 오버라이딩 하는 메서드라는 것을 알린다
	 * 	@Deprecated				앞으로 사용하지 않을 것을 권장하는 대상에 붙인다
	 * 	@SuppressWarnings		컴파일러의 특정 경고메시지가 나타나지 않게 해준다
	 * 	@SafeVarargs			지네릭스 타입의 가변인자에 사용한다 JDK1.7
	 * 	@Functionallnterface	함수형 인터페이스라는 것을 알린다 JDK1.8
	 * 	@Native					native 메서드에서 참조되는 상수 앞에 붙인다 JDK1.8
	 * 	@Target*				애너테이션이 적용가능한 대상을 지정하는데 사용한다
	 * 	@Documented*			애너테이션 정보가 javadoc 으로 작성된 문서에 포함되게 한다
	 * 	@Ingerited*				애너테이션이 자손 클래스에 상속되도록 한다
	 * 	@Retention*				애너테이션이 유지되는 범위를 지정하는데 사용한다
	 * 	@Repeatable*			애너테이션을 반복해서 적용할 수 있게 한다 JDK1.8
	 * 	* = 메타 애너테이션
	 * 
	 * 지네릭(Generics)
	 * 	컴파일시 타입을 체크해 주는 기능(compile-time type check)-JDK1.5
	 * 	결정되지 않은 타입을 파라미터로 처리하고 실제 사용할 때 파라미터를 구체적인 타입으로 대체시키는 기능
	 * 	*객체의 타입 안정성을 높이고 형변환의 번거로움을 줄여줌*
	 * 	(하나의 컬렉션에는 대부분 한 종류의 객체만 저장)
	 * 		지네릭스의 장점
	 * 		1. 타입 안정성을 제공한다
	 * 		2. 타입체크와 형변환을 생략할 수 있으므로 코드가 간결해 진다
	 * 
	 * 지네릭 클래스의 용어
	 * 	Box<T> 	지네릭 클래스 'T의 Box' 또는 'T BOX' 라고 읽는다
	 * 	T	 	타입 변수 또는 타입 매개변수 (T는 타입 문자)
	 * 	Box	 	원시 타입 (raw type)
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * */
}	
