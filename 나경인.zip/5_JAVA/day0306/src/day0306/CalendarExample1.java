package day0306;

import java.util.Calendar;

public class CalendarExample1 {
	public static void main(String[] args) {
		Calendar date = Calendar.getInstance();
		date.set(2024,2,31);
		System.out.println(print(date));
		
		System.out.println("--1일 후--");
		date.add(Calendar.DATE, 1); //하루 추가
		System.out.println(print(date));
		
		System.out.println("--6개월 전--");
		date.add(Calendar.MONTH, -6); //6개월 전
		System.out.println(print(date));
		
		//add() : 다른 필드에 영향을 줘서 정확한 날짜 계산이 가능함
		//roll() : 다른 필드에 영향을 주지 않음
		System.out.println("--31일 후--");
		date.add(Calendar.DATE, 31); 
		System.out.println(print(date));
		
		System.out.println("--31일 후--");
		date.roll(Calendar.DATE, 31); //12월로 넘어가지 않음
		System.out.println(print(date));
		
	}
	public static String print(Calendar date) {
		return date.get(Calendar.YEAR)+"년 "+(date.get(Calendar.MONTH)+1)+"월 "+date.get(Calendar.DATE)+"일 ";
	}
}
