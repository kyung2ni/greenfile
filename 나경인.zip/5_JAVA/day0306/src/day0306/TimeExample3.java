package day0306;

import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.format.DateTimeFormatter;

public class TimeExample3 {
	public static void main(String[] args) {
		LocalDateTime now = LocalDateTime.now();
		LocalDateTime dt = LocalDateTime.of(2000, 01,20,11,22,33,123456789);
		System.out.println(now);
		System.out.println(dt);
		
		String formattedNow = now.format(DateTimeFormatter.ofPattern("yyyy년 MM월 dd일 HH시 mm분 ss초"));
		System.out.println(formattedNow);
		
//		int year = now.getYear();
//		Month month = now.getMonth();
//		String month2 = now.getMonth().toString();
//		int monthValue = now.getMonthValue();  
//		int dayOfMonth = now.getDayOfMonth();
//		int dayOfYear = now.getDayOfYear();
//		DayOfWeek dayOfWeek = now.getDayOfWeek();
//		String dayOfWeek2 = now.getDayOfWeek().toString();
//		int dayOfWeekValue = now.getDayOfWeek().getValue();
//		
//		System.out.println(year);
//		System.out.println(month);
//		System.out.println(month2);
//		System.out.println(monthValue);
//		System.out.println(dayOfMonth);
//		System.out.println(dayOfYear);
//		System.out.println(dayOfWeek);
//		System.out.println(dayOfWeek2);
//		System.out.println(dayOfWeekValue);
//		
//		int hour = now.getHour();
//		int minute = now.getMinute();
//		int second = now.getSecond();
//		
//		System.out.println("시 : "+hour);
//		System.out.println("분 : "+minute);
//		System.out.println("초 : "+second);
		
	}
}
