package day0306;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Scanner;

public class Calendar11 {
	public static void main(String[] args) {
		
		//달력 만들기 풀이
		Scanner scan = new Scanner(System.in);
		
		System.out.print("년도 > ");
		int year = scan.nextInt();
		System.out.print("월 > ");
		int month = scan.nextInt();
		
		int startDayOfWeek=0; //요일을 저장하기 위한 변수
		int endDay = 0; //마지막날을 저장하기 위한 변수
		
		
		Calendar sDay = Calendar.getInstance();//시작일
		Calendar eDay = Calendar.getInstance();//마지막일
		
		sDay.set(year, month-1, 1);	//이번달
		eDay.set(year, month, 1);	//다음달
		
		//다음달 1일에서 하루를 빼서 현재 월의 마지막날 구하기
		eDay.add(Calendar.DATE, -1); 
		
		//1일이 무슨 요일인지 확인
		startDayOfWeek = sDay.get(Calendar.DAY_OF_WEEK);
		
		//마지막 날짜 저장하기
		endDay = eDay.get(Calendar.DATE);
		
		System.out.println("	"+year+"년	"+month+"월	");
		System.out.println(" 일  월  화  수 목  금  토  ");
		
		int line = 0;
		for (int i=1; i<startDayOfWeek; i++) {
			System.out.print("   ");
			line++;
		}
		
		for (int i=1; i<=endDay; i++) {
			System.out.print((i<10)? "  "+i : " "+i);
			line++;
			if (line==7) {
				System.out.println();
				line=0;
			}
		}
	}
}
