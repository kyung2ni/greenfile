package day0306;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.Scanner;

public class Calendar2 {
	public static void main(String[] args) {
		
		//달력 만들기 풀이
		Scanner scan = new Scanner(System.in);
		
		System.out.print("년도 > ");
		int year = scan.nextInt();
		System.out.print("월 > ");
		int month = scan.nextInt();
		
		int startDayOfWeek=0; //요일을 저장하기 위한 변수
		int endDay = 0; //마지막날을 저장하기 위한 변수
		
		
		LocalDate sDay = LocalDate.of(year, month, 1);//시작일
		LocalDate eDay = sDay.plusMonths(1).minusDays(1);//마지막일
		
		//1일이 무슨 요일인지 확인 (enum 으로 표시)
		DayOfWeek firstDayOfWeek = sDay.getDayOfWeek(); 
		//enum으로 저장된 요일을 숫자로 저장
		startDayOfWeek = firstDayOfWeek.getValue()+1;
		
//		startDayOfWeek = sDay.getDayOfWeek().getValue();
		//마지막 날짜 저장하기
		endDay = eDay.getDayOfMonth();
		
		System.out.println("	"+year+"년	"+month+"월	");
		System.out.println(" 일  월  화  수 목  금  토  ");
		
		if (startDayOfWeek !=8) {
			for (int i=1; i<startDayOfWeek; i++) {
//				if (startDayOfWeek ==8)break;
				System.out.print("   ");
			
		}

		}
		
		for (int i=1, n=startDayOfWeek; i<=endDay; i++, n++) {
			System.out.print((i<10)? "  "+i : " "+i);

			if (n%7==0) {
				System.out.println();
			}
		}
	}
}
