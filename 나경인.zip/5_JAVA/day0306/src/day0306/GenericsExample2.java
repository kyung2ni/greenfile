package day0306;

class Store <T>{
	private T data;
	
	public void set (T data) {
		this.data = data;
	}
	public T getData() {
		return data;
	}
}
public class GenericsExample2 {
	public static void main(String[] args) {
		Store<String> s = new Store<>();
//		s.set(new Integer(10)); //정수 객체
		s.set("abc"); //문자열 객체
		
		String s1 = (String)s.getData();
		System.out.println(s1);
//		Integer i = (Integer)s.getData();
//		System.out.println(i);
	}
}
