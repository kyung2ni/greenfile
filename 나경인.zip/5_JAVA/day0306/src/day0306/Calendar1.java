package day0306;

import java.util.Calendar;
import java.util.Scanner;

public class Calendar1 {
	public static void main(String[] args) {
		
		//달력 만들기
		Scanner scan = new Scanner(System.in);
		System.out.print("년도 입력 : ");
		int year = scan.nextInt();
		System.out.print("월 입력 : ");
		int month = scan.nextInt();
		Calendar cal = Calendar.getInstance();
		Calendar cal2 = Calendar.getInstance();
		cal.set(year, month,1);
		cal2.set(year, month,1);
		cal.add(Calendar.DATE, -1); 
		cal2.add(Calendar.MONTH, -1);
		
		int day = cal.get(Calendar.DATE);
		int week = cal2.get(Calendar.DAY_OF_WEEK);
		
//		System.out.println("week : "+week);
		System.out.println("--------------------------- "+year+"년 "+month+"월"+" ---------------------------");
		System.out.println("	일	월	화	수	목	금	토");
		
		//달력 맨 앞 공백
		for(int i=1; i<week; i++) {
			System.out.print("	"); 
		}
		
		for(int i=1; i<=day; i++) { //day 계산
			System.out.print("	"+i);
			if (week%7==0) { //토요일 이후 띄우기
				System.out.println(); 
			}
			week++;
		}
	}
}
