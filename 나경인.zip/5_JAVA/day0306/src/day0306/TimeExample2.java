package day0306;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class TimeExample2 {
	public static void main(String[] args) {
		LocalTime now = LocalTime.now();
		LocalTime t = LocalTime.of(12, 11,11,123456789);
		System.out.println(now);
		System.out.println(t);
		
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("HH시 mm분 ss초");
		String formatedNow = now.format(dtf);
		System.out.println(formatedNow);
		
		int hour = now.getHour();
		int minute = now.getMinute();
		int second = now.getSecond();
		
		System.out.println("시 : "+hour);
		System.out.println("분 : "+minute);
		System.out.println("초 : "+second);
		
	}
}
