package day0306;

public enum Season {
	SPRING("봄", "꽃놀이"),
	SUMMER("여름", "물놀이"),
	AUTUMN("가을", "단풍놀이"),
	WINTER("겨울", "눈꽃놀이");

	//열거형 상수에 ()를 사용하기 위해 인스턴스 변수 선언
	private final String KoreanName;
	private final String seasonPlay;
	
	//열거형 상수에 ()를 사용하기 위해 생성자 선언
	Season(String KoreanName) {
		this.KoreanName = KoreanName;
		this.seasonPlay = ""; //()의 값이 2개인 경우 생성자에도 2개의 값이 필요함
	}
	//()의 값이 2개인 경우 생성자에도 2개의 값이 필요함
	Season(String KoreanName, String seasonPlay) {
		this.KoreanName = KoreanName;
		this.seasonPlay = seasonPlay;
	}
	
	public String getKoreanName() {
		return KoreanName;
	}
	
	public String getSeasonPlay() {
		return seasonPlay;
	}
}
