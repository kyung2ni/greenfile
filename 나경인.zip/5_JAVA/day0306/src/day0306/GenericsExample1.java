package day0306;

//T : 타입 파라미터. 타입이 필요한 자리에 T를 사용할 수 있음
class Box <T>{
	T content;
}

public class GenericsExample1 {
	public static void main(String[] args) {
		Box<String> box = new Box<String>();
//		String content = (String)box.content;
		box.content = "gd";
		String content = box.content;
		
		Box<Integer> box2 = new Box<Integer>();
		box2.content = 123;
		Integer content2 = box2.content;
	}
}
