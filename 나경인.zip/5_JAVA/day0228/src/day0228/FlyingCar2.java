package day0228;

interface Fly2 {
	void fly();
}

class Car {
	int speed;
	
	void setSpeed(int speed) {
		this.speed = speed;
	}
}




public class FlyingCar2 extends Car implements Fly2{

	@Override
	public void fly() {
		System.out.println("하늘을 날아요");
		
	}
	public static void main(String[] args) {
		FlyingCar2 fc2 = new FlyingCar2();
		fc2.setSpeed(500);
		System.out.println(fc2.speed + "로 달립니다.");
		fc2.fly();
	}

}
