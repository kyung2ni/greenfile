package day0228;

public interface RemoteControl {
	int MAX_VOLUME = 10; // 상수는 선언과 동시에 값 입력
	int MIN_VOLUME = 0;
	
	
	
	void turnOn();
	void turnOff();
	
	void setVolume(int volume);
}
