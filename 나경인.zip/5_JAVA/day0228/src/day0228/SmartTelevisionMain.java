package day0228;

public class SmartTelevisionMain {
	public static void main(String[] args) {
		Television tv = new Television();
		
		tv.turnOn();
		tv.setVolume(10);
		tv.search("JAVA");
		tv.turnOff();
		
		RemoteControl rc = tv;
		
		rc.turnOn();
		rc.setVolume(10);
//		rc.search("JAVA"); 에러
		rc.turnOff();
		
		Searchable sa = tv;
		
//		sa.turnOn(); 에러
//		sa.setVolume(10); 에러
		sa.search("JAVA");
//		sa.turnOff(); 에러
	}
}
