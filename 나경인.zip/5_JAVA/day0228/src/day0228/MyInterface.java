package day0228;

public interface MyInterface {
	void myMethod1();
	
	default void myMethod2() {
		myMethod4();
		System.out.println("MyInterface - myMethod2");
	}
	
	static void myMethod3() {
		System.out.println("MyInterface - static 메서드");
	}
	
	private void myMethod4() {
		System.out.println("MyInterface - private 메서드");
	}
}
