package day0228;

class A {
	public void methodA(I i) {
		i.methodB();
	}
}

interface I {
	public void methodB();
}

class C implements I{
	public void methodB() {
		System.out.println("methodB()");
	}
}

public class InterfaceTest {
	public static void main(String[] args) {
		A a = new A();
		a.methodA(new C());
		
	}
}
