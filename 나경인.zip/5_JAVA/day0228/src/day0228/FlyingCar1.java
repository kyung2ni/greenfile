package day0228;

interface Drive {
	void drive();
}
interface Fly {
	void fly();
}


class FlyingCar implements Drive,Fly {

	@Override
	public void fly() {
		System.out.println("하늘을 날아요");
		
	}

	@Override
	public void drive() {
		System.out.println("달려요");
		
	}
	
	
	
}

public class FlyingCar1{
	public static void main(String[] args) {
		FlyingCar fc = new FlyingCar();
		
		fc.fly();
		fc.drive();
	}
}

