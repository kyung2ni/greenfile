package day0228;

public class MyClassMain {
	public static void main(String[] args) {
		System.out.println("-- 1. 인터페이스가 참조변수 타입으로 사용 --");
		
		MyClass mc1 = new MyClass();
		
		mc1.rc.turnOn();
		mc1.rc.setVolume(5);
		
		System.out.println("-- 2. 인터페이스가 생성자의 매개변수타입으로 사용 --");
		
//		Television t = new Television();
//		Audio a = new Audio();
		
		MyClass mc2 = new MyClass(new Audio()); 
		
		System.out.println("-- 3. 인터페이스가 메서드의 로컬 변수 타입으로 사용 --");
		
		MyClass mc3 = new MyClass();
		mc3.methodA();
		
		System.out.println("-- 4. 인터페이스가 메서드의 매개변수로 사용 --");
		MyClass mc4 = new MyClass();
		mc4.methodB(new Television());
	}
}
