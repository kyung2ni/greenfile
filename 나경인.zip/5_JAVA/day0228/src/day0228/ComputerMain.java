package day0228;

interface Computer {
	void turnOn();
	void turnOff();
}

//class Power implements Computer {
//
//	@Override
//	public void turnOn() {
//		System.out.println("Computer On");
//		
//	}
//
//	@Override
//	public void turnOff() {
//		System.out.println("Computer Off");
//		
//	}
//	
//}

public class ComputerMain {
	public static void main(String[] args) {
		
		Computer c = new Computer() {

			@Override
			public void turnOn() {
				System.out.println("Computer On");
				
			}

			@Override
			public void turnOff() {
				System.out.println("Computer Off");
				
			}
			
		};

		c.turnOn();
		c.turnOff();
		
	}
}
