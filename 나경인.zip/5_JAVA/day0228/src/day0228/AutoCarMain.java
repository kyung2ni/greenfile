package day0228;

public class AutoCarMain {
	public static void main(String[] args) {
		AutoCar ac = new AutoCar();
		
		ac.start();
		ac.setSpeed(60);
		ac.turn(30);
		ac.stop();
	}
}
