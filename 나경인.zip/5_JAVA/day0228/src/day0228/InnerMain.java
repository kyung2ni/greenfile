package day0228;

public class InnerMain {
	public static void main(String[] args) {
		
		A1 a = new A1();
		
		//인스턴스 멤버 클래스 객체 생성
		
		A1.B1 b = a.new B1();
		b.field1 = 10;
		b.field2 = 20;
		b.method1();
		b.method2();
		
		//static 멤버 클래스 객체 생성
		A1.C1 c = new A1.C1();
		c.field1 = 20;
		A1.C1.field2 = 30;
		c.method1();
		A1.C1.method2();
		
		a.method();
		
		
	}
}
