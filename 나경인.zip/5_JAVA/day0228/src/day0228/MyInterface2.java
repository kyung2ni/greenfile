package day0228;

public interface MyInterface2 {
	void myMethod1();
	
	default void myMethod2() {
		System.out.println("MyInterface2 - myMethod2");
	}
	
}
