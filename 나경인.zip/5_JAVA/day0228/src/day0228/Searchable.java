package day0228;

public interface Searchable {
	void search(String url);
	
}
