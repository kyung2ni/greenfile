package day0228;

public class MyClass2 {
//	public void myMethod2() {
//		System.out.println("MyClass2 - myMethod2()");
//	}
}
