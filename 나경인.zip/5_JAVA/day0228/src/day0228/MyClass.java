package day0228;

public class MyClass {

	//1. 인터페이스가 참조변수 타입으로 사용
	RemoteControl rc = new Television();
	
	
	//2. 인터페이스가 생성자의 매개변수타입으로 사용
	
	//기본생성자
	MyClass() {}
	
	MyClass(RemoteControl rc) {
		this.rc = rc;
		rc.turnOn();
		rc.setVolume(8);
		
	}
	//3. 인터페이스가 메서드의 로컬 변수 타입으로 사용
	
	void methodA() {
		RemoteControl rc = new Audio();
		rc.turnOn();
		rc.setVolume(2);
		
	}
	
	//4. 인터페이스가 메서드의 매개변수로 사용
	
	void methodB(RemoteControl rc) {
		rc.turnOn();
		rc.setVolume(6);
	}
}
