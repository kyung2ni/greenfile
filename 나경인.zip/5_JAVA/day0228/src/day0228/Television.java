package day0228;

public class Television implements RemoteControl,Searchable{
	
	private int volume;
	
	@Override
	public void turnOn() {
		System.out.println("Tv를 켭니다.");
		
	}

	@Override
	public void turnOff() {
		System.out.println("Tv를 끕니다.");
		
	}

	@Override
	public void setVolume(int volume) {
		this.volume = volume;
		if (volume > RemoteControl.MAX_VOLUME) {
			this.volume = MAX_VOLUME;
		}
		if (volume < MIN_VOLUME) {
			this.volume = MIN_VOLUME;
		}
		System.out.println("현재 볼륨 : "+volume);
	}

	@Override
	public void search(String url) {
		System.out.println(url + "을 검색합니다.");
		
	}
	
}
