package day0228;

interface Person {
	String getName();
	
	static boolean isEmpty(String str) {
		if (str ==null || str.length() ==0) {
			return true;
		} else {
			return false;
		}
	}
}

class Employee implements Person {
	
	String name;
	
	Employee(String name) {
		if (Person.isEmpty(name)== true) {
			System.out.println("이름을 반드시 입력하세요!");
		} else {
			this.name = name;			
		}
	}
	
	@Override
	public String getName() {
		return this.name;
	}
	
	
}

public class StaticMethod1 {
	public static void main(String[] args) {
		Person obj1 = new Employee("");
		System.out.println(obj1.getName());
	}
}
