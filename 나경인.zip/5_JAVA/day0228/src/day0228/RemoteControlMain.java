package day0228;

public class RemoteControlMain {
	public static void main(String[] args) {
		RemoteControl rc;
		
		Television tv = new Television();
		
		tv.turnOn();
		tv.setVolume(12);
		tv.setVolume(5);
		tv.turnOff();
		
		Audio a = new Audio();
		
		a.turnOn();
		a.setVolume(15);
		a.setVolume(3);
		a.turnOff();
	}
}
