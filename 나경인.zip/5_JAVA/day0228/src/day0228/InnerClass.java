package day0228;

class Outer {
	private int value = 10;
	class Inner {
		public void myMethod() {
			int num =1;
			System.out.println("num : "+num);
			System.out.println("value : "+value);
		}
	}
	
	Outer() {
		Inner obj = new Inner();
		obj.myMethod();
	}
}

public class InnerClass {
	public static void main(String[] args) {
		Outer outer = new Outer();
		
	}
}
