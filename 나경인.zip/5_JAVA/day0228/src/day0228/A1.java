package day0228;

//바깥클래스
public class A1 {
	A1() {
		System.out.println("A객체가 생성됨");
	}
	
	//인스턴스 멤버 클래스
	class B1 {
		B1() {
			System.out.println("B객체가 생성됨");
		}
		int field1;
		static int field2;
		void method1() {}
		static void method2() {}
	}
	
	//static 멤버 클래스
	static class C1 {
		C1() {
			System.out.println("C 객체가 생성됨");
		}
		int field1;
		static int field2;
		void method1() {};
		static void method2() {};
	}
	
	//메서드 내에서 클래스 생성
	void method() {
		class D1{
			D1() {
				System.out.println("D객체가 생성됨");
				
			}
			int field1;
			static int field2;
			void method1() {}
			static void method2() {}
		}
		D1 d = new D1();
		d.field1 = 30;
		d.field2 = 40;
		d.method1();
		d.method2();
	}
}
