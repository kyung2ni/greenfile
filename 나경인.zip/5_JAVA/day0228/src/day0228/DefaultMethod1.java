package day0228;

public class DefaultMethod1 extends MyClass2 implements MyInterface,MyInterface2{

	@Override
	public void myMethod1() {
		System.out.println("myMethod1");
		
	}
	
	@Override
	public void myMethod2() {
		System.out.println("오버라이딩한 myMethod2");
	}

	public static void main(String[] args) {
		DefaultMethod1 dm1 = new DefaultMethod1();
		
		dm1.myMethod1();
		
		//조상 클래스와 인터페이스의 디폴트 메서드의 이름이 같은 경우에는
		//조상 클래스의 메서드가 실행
		dm1.myMethod2();
		
		//인터페이스의 static 메서드를 호출할때는
		//반드시 인터페이스명을 통해서 호출해야 함.
		MyInterface.myMethod3();
		
//		MyInterface.myMethod4();
	}
	

}
