package day0216;

import java.util.Scanner;

public class WhileExample2 {

	public static void main(String[] args) {
		/*
		 * 1부터 300까지의 랜덤수를 맞추는 게임을 생성
		 * 숫자 입력 > xxx
		 * 
		 * 만약 랜덤수보다 작은 수를 입력하면
		 * '입력한 값이 작습니다. 큰 수를 입력하세요' 표시
		 * 랜덤수보다 큰 수를 입력하면
		 * '입력한 값이 큽니다. 작은 수를 입력하세요' 표시
		 * 만약 정답이면
		 * '정답입니다. x번만에 맞추셨습니다.' 표시 후 종료
		 * 
		 * */
		int rnd = (int) (Math.random()*300)+1;
		int count = 1;
		Scanner scan= new Scanner(System.in);
		
		
		while(true) {
			System.out.print("숫자를 입력하세요 >> ");
			int input = scan.nextInt();
		
			if (input < rnd) {
				System.out.println("입력한 값이 작습니다. 큰 수를 입력하세요");
				count += 1;
				
			} else if (input > rnd){
				System.out.println("입력한 값이 큽니다. 작은 수를 입력하세요");
				count += 1;
			} else {
				System.out.println("정답입니다. "+count+"번만에 맞추셨습니다.");
				break;
			}

		}
	}

}
