package day0216;

import java.util.Scanner;

public class Example2 {

	public static void main(String[] args) {
		boolean run = true;
		long money = 0;
		Scanner scan = new Scanner(System.in);
		
		while (run) {
			System.out.println("------------------------------");
			System.out.println("1.예금 | 2.출금 | 3.잔고 | 4.종료");
			System.out.println("------------------------------");
			System.out.print("선택 > ");
			int pick = scan.nextInt();
			
			switch (pick)  {
				case 1 : 
					System.out.print("예금액 > ");
					money += scan.nextLong();
					break;
				case 2 :
					System.out.print("출금액 > ");
					money -= scan.nextLong();
					break;
				case 3 :
					System.out.print("잔고 > ");
					System.out.println(money);
					break;
				
				case 4 :
					System.out.println("종료되었습니다.");
					run = false;
					break;
				default :
					System.out.println("다시 선택하세요.");
					continue;
			}
				
				
		}
				
			
	}
		

}


