package day0216;

public class ForExample3 {

	public static void main(String[] args) {
		//단일 for 문 
		int num1 = 0;
		int num2 = 0;
		for (int i=1; i<=10; i++) {
			num1 += i;
			num2 += num1;
			System.out.println(num1);
		}
		System.out.println(num2);
		
		System.out.println("---------------------------------------");
		//이중 for 문
		int num3 = 0;
		for (int i=1; i<=10; i++) {
			for (int j=1; j<=i; j++) {
				num3 += j;
			}
		}
		System.out.println(num3);
	}

}
