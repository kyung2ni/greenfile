package day0216;

import java.util.Arrays;

public class ArrayExample1 {

	public static void main(String[] args) {
		
		//방법1
		int[] score1 = new int[5];
		
		score1[0] = 100;
		score1[1] = 90;
		score1[2] = 80;
		score1[3] = 70;
		score1[4] = 60;
		
		System.out.println(score1[0]);
		System.out.println(score1[1]);
		System.out.println(score1[2]);
		System.out.println(score1[3]);
		System.out.println(score1[4]);
		
//		//방법2 생성과 값을 따로하면 오류발생
//		int[] score2
//		score2 = {10,9,8,7,6};
		int[] score2 = {10,9,8,7,6};
		for (int i=0;i<score2.length; i++) {
			System.out.println(score2[i]);
		}
		
		//방법3 : for 문 이용
		int[] score3 = new int[5];
		
		for (int i=0; i<score3.length; i++) {
			score3[i] = i*10;
//			System.out.println(score3[i]);
		}
		System.out.println(Arrays.toString(score3));
		System.out.println(score3); //이상한 주소
		
		char[] chArr = {'a', 'b', 'c', 'd'}; 
		System.out.println(Arrays.toString(chArr));
		System.out.println(chArr); //유일한 예외
	}

}
