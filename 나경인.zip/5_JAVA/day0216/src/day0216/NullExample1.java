package day0216;

public class NullExample1 {

	public static void main(String[] args) {
		int[] intArray= null;
		
		intArray[0] =10;
		

	}

}
