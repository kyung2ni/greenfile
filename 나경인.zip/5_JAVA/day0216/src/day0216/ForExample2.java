package day0216;

public class ForExample2 {

	public static void main(String[] args) {
		for (int i=2; i<=9; i++) {
			System.out.print(i+"단		");
		}
		for (int j=1; j<=9; j++) {
			System.out.println();
			for (int k=2; k<=9; k++) {
				System.out.print(k + "x" + j + "=" + j*k + "		");	
			}
			
		}
		System.out.println();
		System.out.println("------------------------------------------------------------------------------------------------------------------------------");
		
		for (int i=0; i<=9; i++) {
			for (int j=2; j<=9; j++) {
				if (i==0) {
					System.out.print(j+"단		");
				} else {
					System.out.print(j + "x" + i + "=" + j*i + "		");
				}
			}
			System.out.println();
		
		}
		//
		

	}

}
