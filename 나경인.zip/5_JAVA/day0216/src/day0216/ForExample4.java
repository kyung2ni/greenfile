package day0216;

public class ForExample4 {
	public static void main(String[] args) {
		//1+(-2)+3+(-4)+5+(-6)...과 같은 식 으로 더했을때 총합이 100이려면 어떤숫자까지?
		int sum2 = 0; //합계 저장 변수
		int num1 = 0; //부호를 적용한 숫자
		int sign = 1; //부호를 바꿀때 사용
		for (int i=1; true; i++) {
			
			num1 += sign*i;
			sign = -sign;
			sum2 += num1;
			System.out.println(i);
			if (sum2 == 100) {
				break;
			}
			
			
		}
		System.out.println("-----------------------------------------------------------");
		
		//홀짝 이용
		int sum = 0;
		int i = 0;
		
		for (i=1; true; i++) {
			if (i % 2 ==1) {
				sum += i;
			} else {
				sum-= i;
			}
			if (sum >= 100) {
				break;
			}
		}
		System.out.println(i);
		System.out.println("-----------------------------------------------------------");
	}
}
