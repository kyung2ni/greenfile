package day0216;

import java.net.MulticastSocket;

public class BreakExample {
	public static void main(String[] args) {
		//1부터 10까지 숫자를
		//한줄에 3개씩 출력
		int k = 0;
		myFor : for (int i=0; i<10; i++) {
			for (int j=0; j<3; j++) {
				k++;
				System.out.print(k);
				
				if (k ==10) {
					break myFor;
				}
			}
			System.out.println();
		}
	}
}
