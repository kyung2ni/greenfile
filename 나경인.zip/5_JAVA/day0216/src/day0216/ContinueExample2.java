package day0216;

public class ContinueExample2 {
	public static void main(String[] args) {
		
		//아래의 문장에서 'e'의 개수를 구하세요
		String s = "green computer academy";
		int count = 0;
		for (int i=0; i<s.length(); i++) {
			if (s.charAt(i) != 'e') {
				continue;
			}
			count++;
		}
		System.out.println(count);
		
	}
}
