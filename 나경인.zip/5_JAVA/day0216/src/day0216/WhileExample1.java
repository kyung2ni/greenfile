package day0216;

import java.util.Scanner;

public class WhileExample1 {

	public static void main(String[] args) {
		//사용자가 입력한 숫자의 각 자리수의 합계 구하기
		//에)12345입력 >> 1+2+3+4+5 = 15
		
		Scanner scan = new Scanner(System.in);
		System.out.print("숫자를 입력하세요 > ");
		long num = scan.nextLong();
		long sum = 0;
		
		while (num != 0) {
			sum += num % 10;
			num /= 10;
		}
		System.out.println(sum);
			

	}

}
