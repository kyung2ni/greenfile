package day0214;

import java.util.Scanner;

public class ScannerExample {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		System.out.print("숫자를 입력하세요 : ");
		
		int input = scan.nextInt();
		
		System.out.println("입력 내용 : " + input);
	}

}
