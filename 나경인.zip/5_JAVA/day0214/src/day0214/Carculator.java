package day0214;

public class Carculator {

	public static void main(String[] args) {
		//정수형변수 num1, num2를 선언하고
		//다음과 같이 출력되도록 하시오
		
		//변수 초기값
		//num1 : 100, num2 : 50
		
		//출력결과
		
		//100+50=150
		//100-50=50
		//100*50=5000
		//100/50=2
		
		int num1 = 100;
		int num2 = 50;
		
		System.out.println(num1+"+"+num2+"="+(num1+num2));
		System.out.println(num1+"-"+num2+"="+(num1-num2));
		System.out.println(num1+"*"+num2+"="+(num1*num2));
		System.out.println(num1+"/"+num2+"="+(num1/num2));

	}

}
