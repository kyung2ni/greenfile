package day0214;

public class OperatorExample {

	public static void main(String[] args) {
		int x = 10;
		int y = 10;
		int z;
		
		System.out.println("--------------");
		x++;
		++x;
		System.out.println("x : " + x); //12
		
		System.out.println("--------------");
		y--;
		--y;
		System.out.println("y : " + y); //8
		
		System.out.println("--------------");
		z = x++;
		System.out.println("z : " + z); //12
		System.out.println("x : " + x); //13
		
		System.out.println("--------------");
		z = ++x;
		System.out.println("z : " + z); //14
		System.out.println("x : " + x); //14
		
		System.out.println("--------------");
		z = ++x + y++; // 15+8
		System.out.println("z : " + z); //23
		System.out.println("x : " + x); //15
		System.out.println("y : " + y); //9
		
		System.out.println("--------------");
		System.out.println('A' == 65);
		System.out.println(0.1 == 0.1f);
		
		System.out.println("--------------");
		int num1 = 1;
		double num2 = 1.0;
		System.out.println(num1 == num2);
		
		System.out.println("--------------");
		//비트연산자 & | ^
		int bit1 = 3;
		int bit2 = 5;
		System.out.println(bit1 ^ bit2);
		//비트이동연산자 (Shift 연산자)
		System.out.println(1 << 3); 
		//비트전환연산자 
		//정수를 2진수로 표현했을 때 1을0으로 0을1로 바꾼다 (1의 보수 연산자)
		System.out.println("--------------");
		//오버플로우
		byte b = 127;
		b++;
		System.out.println(b);
		
		System.out.println("--------------");
		char c1 = 'A'+ 1; //B
		c1++; //C
		char c2 = (char)(c1 + 1); //D
		System.out.println(c2);
		
		System.out.println("--------------");
		int in1 = 'B'-'A';
		int in2 = '2';
		System.out.println(in1);
		System.out.println(in2);
		
		
	}

}
