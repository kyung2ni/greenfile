package day0214;

public class PromotionExample {

	public static void main(String[] args) {
		/*	형변환
		 * 	값의 타입을 다른 타입으로 변환하는것이다
		 * boolean을 제외한 7개의 기본형은 서로 형변환이 가능
		 * 
		 * 자동 타입 변환
		 * 데이터 타입을 다른 타입으로 변환하는 것
		 * 작은타입 >> 큰타입으로 변환될때
		 * */
		
		byte byteValue = 10;
		int intValue = byteValue;
		
		System.out.println("intValue : " + intValue);
		
		char charValue = '가';
		intValue = charValue;
		System.out.println("가 : "+ intValue);
		
		intValue = 50;
		long longValue = intValue;
		System.out.println("longValue : "+longValue);
		
		longValue = 100;
		float floatValue = longValue;
		System.out.println("floatValue : "+floatValue);
		
		floatValue = 100.5F;
		double doubleValue = floatValue;
		System.out.println("doubleValue : "+doubleValue);

	}

}
