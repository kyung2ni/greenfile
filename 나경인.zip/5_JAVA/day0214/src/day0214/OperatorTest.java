package day0214;

public class OperatorTest {

	public static void main(String[] args) {
		
		float pi = 3.141592f;
		float result = (int)(pi*1000)/1000f;
		
		//소수점 셋째자리까지만 표시 
		//3.141f
		
		System.out.println((float)(int)(1000*pi)/1000);
		System.out.println(result);
		System.out.printf("%1.3f\n",pi);
		
		System.out.println("------------------------------");
		
		//변수 num 에 숫자를 저장하고 '양수', '음수' , '0' 을 출력하시오.
		//삼항연산자를 이용할 것.
		
		int num1 = 1;
		System.out.println(num1 == 0 ? "0" : (num1 > 0  ? "양수" : "음수"));
		
		System.out.println("------------------------------");
		
		//num2에 저장되어있는 값 중에서 백의자리이하를 버리는 코드를 작성 
		//만약 변수 num2에 저장된 값이 456이라면 400이 되고,
		//111 이라면 100이 되도록 하시오.
		
		int num2 = 456;
		System.out.println(num2/100*100);
		System.out.println(num2-num2%100);
		
		System.out.println("------------------------------");
		
		//사과가 123개 있고 하나의 바구니에는 10개의 사과를 담을 수 있다.
		//사과를 담는데 필요한 바구니 수를 구하시오.
		//사과 123개 >>13개
		
		int apple = 123;
		System.out.println("필요한 바구니 개수 : "+(apple/10+
										(apple%10 > 0 ? 1 : 0 )));
		
		int bucket = 10;
		int result1 = apple / bucket + (apple%bucket > 0 ? 1 : 0);
		System.out.println("필요한 바구니 개수 : "+result1);
		
		System.out.println("------------------------------");
		
		//세자리 정수를 변수로 입력하여
		//각 자릿수의 총합을 출력하시오.
		//예 )정수 123의 총합 : 6
		
		int a = 123;
		System.out.println("각 자릿수의 총합 : "+(a/100%10+a%100/10+a%10));
		
		System.out.println("------------------------------");
		
		//화씨(F)를 섭씨(C)로 변환하시오.
		//변환 공식 : C = 5 / 9 * (F - 32)
		//단 변환결과는 소수점 셋째자리에서 반올림하여 출력할 것.
		
		int F = 100;
		float result2 = 100000*5/9*(F - 32);
		float C = result2/100000;
		System.out.printf("%1.2f \n", C );
		
		System.out.println("------------------------------");
		
		float c = 5f / 9 * (F - 32); 
		System.out.println(c);
		System.out.printf("%1.2f \n", c );
		float cc = (int)(5f / 9 * (F - 32)*100+0.5)/100f;
		System.out.println(cc);
		System.out.println("------------------------------");
		System.out.println("------------------------------");
		
		
		
		
		
		
	}

}
