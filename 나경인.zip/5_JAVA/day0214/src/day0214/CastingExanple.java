package day0214;

public class CastingExanple {

	public static void main(String[] args) {
		int intValue = 44032;
		char charValue = (char)intValue;
		System.out.println(charValue);
		
		long longValue = 5000000000l;
		intValue = (int)longValue;
		System.out.println(intValue);
		
		byte b1 = 10;
		byte b2 = 20;
		int result1 = b1+b2;
		
		int i1 = 100;
		double d1 = 200.5;
		double result2 = i1 + d1;
		
		System.out.println(result2);
		
		char charValue1 = 'A'; //65
		char charValue2 = 1;
		int charValue3 = charValue1 + charValue2;
		System.out.println((char)charValue3);
		
		int intValue1 = 10;
		int intValue2 = intValue1 / 4;
		double intValue3 = intValue1 / 4.0;
		System.out.println(intValue2);
		System.out.println(intValue3);
		
		int intValue4 = 10;
		int intValue5 = 3;
		
		int result = intValue4 / intValue5;
		double result3 = (double)intValue4 / intValue5;
		double result4 = (double)(intValue4 / intValue5);
		System.out.println(result);
		System.out.println(result3);
		System.out.println(result4);
	}

}
