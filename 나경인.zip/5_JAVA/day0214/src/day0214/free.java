package day0214;

public class free {

	public static void main(String[] args) {
		String name = "김자바";
		int age = 25;
		String tel1="010", tel2= "123", tel3= "1234";
		System.out.println("이름 : "+name);
		System.out.print("나이 : "+age+"\n");
		System.out.printf("%1$s-%2$s-%3$s",tel1,tel2,tel3+"\n");
		
		int pencils = 534;
		int students = 30;
		
		int pps = pencils/students;
		System.out.println("학생 1명이 가지는 연필 : "+pps);
		
		int pl = pencils%students;
		System.out.println("남은 연필 개수 : "+pl);
		
		int value = 365;
		
		System.out.println(value/100*100);
		
		float var1 = 10f;
		float var2 = var1 / 100;
		if (var2 == 0.1f ) {
			System.out.println("10%입니다.");
		} else {
			System.out.println("10%가 아닙니다.");
		}
	}

}
