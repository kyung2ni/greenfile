package day0214;

public class LiteralExample {

	public static void main(String[] args) {
		long var1 = 20000000000L;//L을 붙여줘야 long 타입으로 인식 기본적으론 int 로 인식
		char var2 = 'A';//char 는 1글자 공백이라도 무조건 있어야함 
		char var3 = ' ';
		char var4 = '\uBAA1';
		char var5 = '\u0041';
		char var6 = 65; //아스키코드 'A'
		float var7 = 0.123456789123456789f;
		double var8 = 0.123456789123456789;
		float var9 = 41144;

		
		System.out.println("var1 : " + var1);
		System.out.println("var2 : " + var2);
		System.out.println("var3 : " + var3);
		System.out.println("var4 : " + var4);
		System.out.println("var5 : " + var5);
		System.out.println("var6 : " + var6);
		System.out.println("var7 : " + var7);
		System.out.println("var8 : " + var8);
		System.out.println("var9 : " + var9+ "\tABC \nABC");
		
		
	}

}
