package day0214;

public class PrintExample {

	public static void main(String[] args) {
		
		int value = 100;
		int num = 10;
		String name = "자동차";
		
		double dNum1 = 100.4;
		double dNum2 = 2.45;
		
		System.out.println("가격 : "+value+", 수량 : "+num); //정수 %d 실수 %f 문자 %s
		System.out.printf("가격 : %d, 수량 : %d, 이름 : %s %n\n",value,num,name); // %n \n 줄바꿈기호
		System.out.println("asd");
		
		System.out.printf("숫자 : %5d원 \n",value); //남는 자릿수만큼 공백
		System.out.printf("숫자 : %5d원 \n" ,num);
		
		System.out.printf("결과 : %5.1f \n", dNum1); //전체 5자리수에 1개의 소수점 나타냄
		System.out.printf("결과 : %5.1f \n", dNum2); //남는자리 공백
	}

}
