package day0311;

import java.util.*;

public class MapExample4 {
	public static void main(String[] args) {
		//사용자에게 아이디와 비밀번호를 입력받아 로그인하도록 하시오
		//아이디와 비밀번호가 올바르면 : 로그인 성공
		//아이디가 잘못된 경우 : 입력하신 아이디가 존재하지 않습니다
		//비밀번호가 잘못된 경우 : 비밀번호가 일치하지 않습니다
		
		//아이디 		비밀번호
		//spring	12
		//summer	123
		//autumn	1234
		//winter	12345
		
		//summer 의 비밀번호를 1111로 변경할 것
		
		Map<String, String> map = new HashMap<>();
		map.put("spring", "12");
		map.put("summer", "123");
		map.put("autumn", "1234");
		map.put("winter", "12345");
		
		map.put("summer", "1111");
		
		Scanner scan = new Scanner(System.in);
		while(true) {
			System.out.println("아이디와 비밀번호를 입력하세요");
			System.out.print("아이디 > ");
			String id = scan.nextLine();
			System.out.print("비밀번호 > ");
			String pw = scan.nextLine();
			
			if (map.containsKey(id)) {
				if (map.get(id).equals(pw)) {
					System.out.println("로그인 성공");
					break;
				} else {
					System.out.println("비밀번호 오류");
				}
					
			} else {
				System.out.println("아이디 오류");
			}
			
		}
		
//		for (Map.Entry<String, String> entry : map.entrySet()) {
//			if (entry.getKey() != id) {
//				System.out.println("입력하신 아이디가 존재하지 않습니다");
//			} else if (entry.getValue() != pw) {
//				System.out.println("비밀번호가 일치하지 않습니다");
//			} else {
//				System.out.println("로그인 성공");
//			}			
//		}
		
		
	}
}
