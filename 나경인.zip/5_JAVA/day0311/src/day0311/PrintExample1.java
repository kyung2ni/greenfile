package day0311;

import java.util.*;

public class PrintExample1 {
	public static void main(String[] args) {
		TreeMap<Integer, String> map = new TreeMap<>();
		
		map.put(1, "aaa");
		map.put(2, "bbb");
		map.put(3, "ccc");
		
		//1. entrySet() : key 와 value 를 가져올때 사용
		System.out.println("1. entrySet()------------");
		for (Map.Entry<Integer, String> entry : map.entrySet()) {
			System.out.println(entry.getKey()+"/"+entry.getValue());
		}
		//2. keySet() : key를 가져올 때 사용
		System.out.println("2. keySet()-------------");
		for (Integer i : map.keySet()) {
			System.out.println(i+"/"+map.get(i));
		}
		
		//3. Iterator ~ entrySet()
		System.out.println("3. Iterator ~ entrySet()-------------");
		Iterator<Map.Entry<Integer, String>> entry = map.entrySet().iterator();
		
		while(entry.hasNext()) {
			Map.Entry<Integer, String> e = entry.next();
			System.out.println(e.getKey()+"/"+e.getValue());
		}
		
		//4. Iterator ~ KeySet()
		System.out.println("4. Iterator ~ KeySet()-------------");
		Iterator<Integer> keys = map.keySet().iterator();
		
		while(keys.hasNext()) {
			int k = keys.next();
			System.out.println(k+"/"+map.get(k));
		}
	}
}
