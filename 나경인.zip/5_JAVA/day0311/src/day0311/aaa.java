package day0311;

public class aaa {
	/*
	 * 
	 * Enumeration Iterator ListIterator
	 * 	컬렉션에 저장된 데이터를 접근하는데 사용되는 인터페이스
	 * 	Enumeration 은 Iterator 의 구버전
	 * 	ListIterator 는 Iterator 의 접근성을 향상시킨 것 (단방향 >> 양방향)
	 * 		- boolean hasNext() : 읽어 올 요소가 남아있는지 확인한다. 있으면 true, 없으면 false
	 * 		- Object next() : 다음 요소를 읽어온다. next()를 호출하기 전에 hasNext()를 호출해서
	 * 		                  읽어 올 요소가 있는지 확인하는 것이 안전하다
	 * 
	 * Map 컬렉션
	 * 	키와 값으로 구성된 Map.Entry 객체 저장하는 구조 가짐
	 * 	키는 중복 저장될 수 없으나 값은 중복 저장될 수 있음
	 * 	기존 저장된 키와 동일한 키로 값을 저장하면 기존 값 없어지고 새로운 값으로 대체
	 * 	HashMap, HashTable, LinkedHashMap, Properties, TreeMap
	 * 
	 * HashMap TreeMap - 순서X, 중복(키x,값o)
	 * 	Map 인터페이스를 구현. 데이터를 키와 값의 쌍으로 저장
	 * 	- HashMap(동기화X)은 HashTable(동기화O)의 신버전
	 * 
	 * HashMap 
	 * 	- Map 인터페이스를 구현한 대표적인 컬렉션 클래스
	 * 	- 순서를 우지하려면 LinkedHashMap 사용
	 * TreeMap	
	 * 	범위 검색과 정렬에 유리한 클래스
	 * 	이진 검색 트리의 구조로 키와 값의 쌍으로 이루어진 데이터를 저장
	 * 	TreeSet 처럼, 데이터를 정렬 해서 저장하기 때문에 지정시간이 길다
	 * 	(TreeSet은 TreeMap을 이용해서 구현되어 있음)
	 * 	다수의 데이터에서 개별적인 검색은 TreeMap 보다 HashMap이 빠르다
	 *  Map이 필요할 때 주로 HashMap을 사용하고, 정렬이나 범위검색이 필요한 경우에 TreeMap을 사용
	 * 
	 * 
	 * 
	 * 
	 * */
}
