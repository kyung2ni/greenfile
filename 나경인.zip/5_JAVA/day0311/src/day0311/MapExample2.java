package day0311;

import java.util.*;

public class MapExample2 {
	public static void main(String[] args) {
		HashMap map = new HashMap();
		map.put("김자바", 100);
		map.put("안자바", 50);
		map.put("박자바", 90);
		map.put("강자바", 90);
		map.put("안자바", 70);
		
		Set set = map.entrySet();
		Iterator it = set.iterator();
		
		//키, 값 같이 출력
		while (it.hasNext()) {
			Map.Entry e = (Map.Entry)it.next();
			System.out.println("이름 : "+e.getKey());
			System.out.println("점수 : "+e.getValue());
		}
		
		//키만 가지고오기
		set = map.keySet();
		System.out.println("명단 : "+set);
		
		Collection values = map.values();
		it = values.iterator();
		
		int sum=0;
		while(it.hasNext()) {
			int s = (int)it.next();
			sum += s;
		}
		System.out.println("총점 : "+sum);
		System.out.println("평균 : "+(float) sum / set.size());
		System.out.println("최고점수 : "+Collections.max(values));
		System.out.println("최고점수 : "+Collections.min(values));
	}
}
