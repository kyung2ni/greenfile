package day0311;

import java.util.*;

public class MapExample5 {
	public static void main(String[] args) {
		//다음 학생의 정보를 map 에 저장하고
		//평균 점수와 함께, 최고점수에 해당하는 사람의 이름,
		//최저점수에 해당하는 사람의 이름을 출력하시오
		
		//김그린 96
		//정제이 86
		//이자바 92
		
		Map<String,Integer> map = new TreeMap<>();
		
		map.put("김그린", 96);
		map.put("정제이", 86);
		map.put("이자바", 92);
		
		Set<Map.Entry<String, Integer>> entrySet= map.entrySet();
		String maxName = null;
		String minName = null;
		int maxScore = 0,minScore = 100,totalScore = 0;
		for (Map.Entry<String, Integer>entry : entrySet) {
			totalScore += entry.getValue();
			if (entry.getValue() > maxScore) {
				maxScore = entry.getValue();
				maxName = entry.getKey();
			}
			if (entry.getValue() < minScore) {
				minScore = entry.getValue();
				minName = entry.getKey();
			}
		}
		int avgScore = totalScore / map.size();
		System.out.println("평균점수 : "+avgScore);
		System.out.printf("최고점수 : %s(%d)\n",maxName,maxScore);
		System.out.printf("최저점수 : %s(%d)\n",minName,minScore);
	}
}
