package day0311;

import java.util.*;

public class IteratorExample1 {
	public static void main(String[] args) {
//		ArrayList list = new ArrayList();
		HashSet list = new HashSet();
		list.add("1");
		list.add("2");
		list.add("3");
		list.add("4");
		list.add("5");
		
		//Iterator 는 1회용 객체이므로
		//한번 출력후에는 결과값이 false 가 됨
		Iterator it = list.iterator(); 
		
		while(it.hasNext()) {
			Object obj = it.next();
			System.out.println(obj);
		}
		while(it.hasNext()) {
			Object obj = it.next();
			System.out.println(obj);
		}
		
//		for (int i=0; i<list.size(); i++) {
//			Object obj = list.get(i);
//			System.out.println(obj);
//		}
		
		//이미 출력한 컬렉션을 다시 사용하기 위해서는
		//Iterator 객체를 새로 생성 후 사용해야함
//		Iterator it2 = list.iterator();
//		while(it2.hasNext()) {
//			Object obj = it2.next();
//			System.out.println(obj);
//		}
	}
}
