package day0311;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class MapExample1 {
	public static void main(String[] args) {
		Map<String,Integer> map = new HashMap<>();
		map.put("김그린", 95);
		map.put("이자바", 80);
		map.put("정제이", 85);
		map.put("이자바", 100);
		
		//저장된 총 개수 확인
		System.out.println("총 Entry 수 : "+map.size());
		
		//객체찾기
		System.out.println("이자바 : "+map.get("이자바"));
		
		//키 확인
		Set<String> keySet = map.keySet();
		
		System.out.println(keySet);
		
		//키를 이용하여 값을 찾아 출력하기
		Iterator<String> keyIterator = keySet.iterator();
		while (keyIterator.hasNext()) {
			String key = keyIterator.next();
			Integer value = map.get(key);
			System.out.println(key+" : "+value);
		}
		map.remove("이자바");
		System.out.println("총 Entry의 수 : "+map.size());
		
		//Map.Entry : Map 인터페이스의 내부 인터페이스
		//Map 에 저장된 모든 key-value쌍을 각각의 객체로 얻을 수 있음
		Set<Map.Entry<String, Integer>> entrySet = map.entrySet();
//		Iterator<Map.Entry<String, Integer>> entryIterator = 
//		
//		while(EntryIterator.hasNext()) {
//			Map.Entry<String, Integer> entry = entryIterator.next();
//			String key= entry.getKey();
//			Integer value = entry.getValue();
//			System.out.println(key + " : "+value);
//		}
		
		map.clear();//전체삭제
		System.out.println("총 Entry 수 : "+map.size());
	}
}
