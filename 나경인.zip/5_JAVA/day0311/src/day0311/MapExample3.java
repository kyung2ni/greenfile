package day0311;

import java.util.*;

class People {
	public int sno;
	public String name;
	
	public People(int sno,String name) {
		this.sno =sno;
		this.name = name;
	}
	@Override
	public boolean equals(Object obj) {
		if (obj instanceof People) {
			People people = (People) obj;
			return (sno==people.sno && (name.equals(people.name)));
		} else {
			return false;
		}
	}
	
	@Override
	public int hashCode() {
		return sno+name.hashCode();
	}
}

public class MapExample3 {
	public static void main(String[] args) {
		Map<People,Integer> map = new HashMap<>();
		
		map.put(new People(1,"김그린"), 23);
		map.put(new People(1,"김그린"), 23);
		
		System.out.println(map.size());
	}
}
