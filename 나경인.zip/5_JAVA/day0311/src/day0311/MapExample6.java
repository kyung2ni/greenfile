package day0311;

import java.util.*;

public class MapExample6 {
	public static void main(String[] args) {
		String[] data = {"A","K","A","K","D","K","A","B","B","Z","D","C","D"};
		
		//각 문자가 몇개씩 있는지 표시
		Map map = new HashMap<>();
		
		
		for (int i=0; i<data.length; i++) {
			if (map.containsKey(data[i])) {
				int count = (int) map.get(data[i]);
				map.put(data[i],count+1);
			} else {
				map.put(data[i],1);
			}
			
		}
		//Iterator 쓰기위한 set으로 변환
		Set set = map.entrySet();
		
		Iterator it = set. iterator();
		while (it.hasNext()) {
			Map.Entry entry = (Map.Entry) it.next();
			int value = (int) entry.getValue();
			System.out.println(entry.getKey()+" : "+printBar('#',value)+value);
		}
		System.out.println(map);
		
	}
	public static String printBar(char ch, int value) {
		char[] bar = new char[value];
		
		for (int i=0; i<bar.length; i++) {
			bar[i] = ch;
		}
		return new String(bar);
	}
}
