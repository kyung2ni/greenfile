package day0222;

public class Eagle extends Animal{

	int wings = 2;
	

	
	void fly() {
		System.out.println("fly()가 호출되었음");
	}
}
