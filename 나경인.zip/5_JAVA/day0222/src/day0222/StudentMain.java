package day0222;

class Student {
	String name;
	int ban;
	int no;
	int kor;
	int eng;
	int math;
	
	Student(){}
	
	Student(String name,int ban,int no,int kor,int eng,int math) {
		this.name=name;
		this.ban=ban;
		this.no=no;
		this.kor=kor;
		this.eng=eng;
		this.math=math;
	}
	
	int getTotal() {
		return kor+eng+math;
	}
	
	float getAverage() {
		return (int)(getTotal()/3f*10+0.5f)/10f;
	}
	
	void printInfo() {
		System.out.println("이름 : "+name);
		System.out.println("총점 : "+getTotal());
		System.out.println("평균 : "+getAverage());
	}
	
	
}

public class StudentMain {
	public static void main(String[] args) {
		Student s1 = new Student();
		s1.name = "김그린";
		s1.ban = 1;
		s1.no = 1;
		s1.kor = 80;
		s1.eng = 22;
		s1.math = 16;
		
//		System.out.println("이름 : "+s1.name);
//		System.out.println("총점 : "+s1.getTotal());
//		System.out.println("평균 : "+s1.getAverage());
//		
		Student s2 = new Student("이자바",2,2,33,44,55);
		s1.printInfo();
		s2.printInfo();
		
		//데이터 타입	변수명	설명
		//String	name	학생이름
		//int		ban		반
		//int		no		번호
		//int		kor		국어점수
		//int		eng		영어점수
		//int		math	수학점수
		
		//Student클래스에 다음의 메서드를 생성하고
		//학생의 이름과 총점,평균을 출력하시오.
		
		//1.메서드명 : getTotal
		//	기능 : 국어 영어 수학희 합계를 반환
		//	반환타입 : int , 매개변수 없음
		
		//2.메서드명 :getAverage
		//	기능 : 평균을 계산하고 소수점 둘째자리에서 반올림
		//	반환타입 : float , 매개변수없음
		
		//결과로 나타낼 데이터는 임의로 작성할 것
		
		//출력화면 : 
		//	이름 : 김그린
		//	총점 : 123
		//	평균 : 41.0
	}
}
