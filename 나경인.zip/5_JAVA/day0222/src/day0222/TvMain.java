package day0222;

public class TvMain {
	public static void main(String[] args) {
		
		SmartTv sTv = new SmartTv();
		
		if (sTv.power != true) {
			sTv.power();
			System.out.println("TV를 켭니다");
		}
		sTv.channel=10;
		sTv.channelUp();
		sTv.channelUp();
		System.out.println("현재 채널은 "+sTv.channel + "입니다.");
		
		if (sTv.net.power !=true) {
			sTv.net.power = true;
			System.out.println("넷플릭스를 켭니다.");
		}
		sTv.play();
		sTv.rew();
		sTv.stop();
		sTv.ff();
		sTv.play();
		
		if (sTv.net.power ==true) {
			sTv.net.power();
			System.out.println("넷플릭스를 끕니다.");
		}
		if (sTv.power ==true) {
			sTv.power();
			System.out.println("TV를 끕니다.");
		}
	}
}
