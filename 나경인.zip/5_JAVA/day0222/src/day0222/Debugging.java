package day0222;
/*
 * f5 : 한줄씩 실행.함수 안이면 함수 안에서 실행
 * f6 : 한줄씩 실행. 함수 호출은 건너뛰고 실행
 * f7 : 현재 함수 끝까지 이동후 함수의 호출부로 되돌아감
 * f8 : 다음 브레이크포인트로 이동
 * 
 * 
 * 
 * */

public class Debugging {
	public static void main(String[] args) {
		int i=0;
		for (i=1; i<=10; i++); 
		{	
			System.out.println("현재 숫자는 : "+i);
		}
	}
}
