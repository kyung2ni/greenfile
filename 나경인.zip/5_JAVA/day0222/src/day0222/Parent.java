package day0222;

public class Parent {
	void print() {
		System.out.println("부모 클래스의 print() 메서드");
	}
}
