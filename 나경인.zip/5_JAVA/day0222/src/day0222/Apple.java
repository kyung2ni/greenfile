package day0222;

public class Apple extends Phone{
	
	Apple () {
		super();
	}
	Apple(String name, String spec, int cost) {
		super(name,spec,cost);
	}
}
