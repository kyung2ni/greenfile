package day0222;

class Food {
	String name;
	int price;
	
	String getName(String name) {
		return this.name=name; 
		
	}
	int getPrice(int price) {
		return this.price=price;
	}
	Food() {}
	Food(String name,int price) {
//		System.out.printf("Food {name:%s , price:%d원}\n",name,price);
		this.price=price;
		this.name=name;
	}
	
}

public class FoodMain {
	public static void main(String[] args) {
		Food chicken = new Food("치킨",16000);
		Food pizza = new Food("피자",26700);
		
		System.out.printf("Food {name:%s , price:%d원}\n",chicken.name,chicken.price);
		System.out.printf("Food {name:%s , price:%d원}\n",pizza.name,pizza.price);
		
	}
}
