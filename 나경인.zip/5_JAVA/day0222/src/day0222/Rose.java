package day0222;

public class Rose extends Flower{
	Rose() {
		super();
	}
	Rose(String name,int cost) {
		super(name,cost);
	}
}
