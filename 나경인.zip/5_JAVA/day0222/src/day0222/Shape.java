package day0222;

class Point {
	int x;
	int y;
}

//상속을 위한 클래스
//class Circle extends Point{
//	int z;
//}

//포함을 위한 클래스
class Circle {
	Point p = new Point(); //참조변수의 초기화
	int z;
}

public class Shape {
	public static void main(String[] args) {
//		//상속
		Circle c = new Circle();
//		c.x = 1;
//		c.y = 2;
//		c.z = 3;
//		System.out.println("c.x : "+c.x);
//		System.out.println("c.y : "+c.y);
//		System.out.println("c.z : "+c.z);
		
		//포함관계
		c.p.x = 4;
		c.p.y = 5;
		c.z = 6;
		
		System.out.println("c.p.x : "+c.p.x);
		System.out.println("c.p.y : "+c.p.y);
		System.out.println("c.z : "+c.z);
		
		//toString() : 문자열로 변환하여 반환
		//클래스명@주소값
		System.out.println(c.toString());
		Circle c1 = new Circle();
		
		//println에 참조변수만 작성하면
		//알아서 toString()을 호출하여 출력함
		System.out.println(c1);
	}
}
