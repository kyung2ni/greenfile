package day0222;

public class OverMain3 {

	class A3 {
		int num1;
		int num2;
		void hello() {
			System.out.println("A를 출력합니다.");
		}
		String print() {
			return "num1 :"+num1+"num2 : "+num2;
		}
	}


	public class OverMain2 {
		public static void main(String[] args) {
//			A3 aa = new A3();
//			aa.num1 = 50;
//			aa.num2 = 60;
//			System.out.println(aa.print());
			
		}
	}

}
