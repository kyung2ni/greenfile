package day0222;

public class Cat extends DogCat{
	
	public Cat (String name,int age) {
		super(name,age);
	}
	public void move() {
		System.out.println("두 발로 점프한다.");
	}
	public void cry() {
		System.out.println("야옹");
	}
}
