package day0222;

public class OverMain1 {


	class A2 {
		int num1;
		int num2;
		void hello() {
			System.out.println("A를 출력합니다.");
		}
		String print() {
			return "num1 :"+num1+"num2 : "+num2;
		}
	}

	class B2 extends A2 {
		int num3;
		void hello() {
			System.out.println("B를 출력합니다");
			System.out.println("이게 바로 오버라이딩");
		}
		String print() {
			return "num1 :"+num1+"num2 : "+num2+"num3 : "+num3;
		}
	}


	public class OverMain2 {
		public static void main(String[] args) {
//			A2 aa = new A2();
//			aa.num1 = 50;
//			aa.num2 = 60;
//			System.out.println(aa.print());
//			B2 bb = new B2();
//			bb.num1 = 10;
//			bb.num2 = 20;
//			bb.num3 = 30;
//			
//			System.out.println(bb.print());
//			
		}
	}
}
