package day0222;

public class SmartTv extends Tv{
	Netflix net = new Netflix();
	
	void play() {
		net.play();
	}
	void stop() {
		net.stop();
	}
	void rew() {
		net.rew();
	}
	void ff() {
		net.ff();
	}
}
