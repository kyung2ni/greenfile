package day0222;

public class DogCatMain {
	public static void main(String[] args) {
		Dog d = new Dog("자기야",16);
		d.animalInfo();
		d.move();
		d.cry();
		
		Cat c = new Cat("다람이",6);
		c.animalInfo();
		c.move();
		c.cry();
	}
}
