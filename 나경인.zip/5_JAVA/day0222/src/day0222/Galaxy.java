package day0222;

public class Galaxy extends Phone{
	
	Galaxy() {
		super();
	}
	
	Galaxy(String name,String spec,int cost) {
//		this.name=name;
//		this.spec=spec;
//		this.cost=cost;
		super(name,spec,cost); //부모의 생성자 호출
	}
}
