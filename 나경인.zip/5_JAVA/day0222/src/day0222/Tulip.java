package day0222;

public class Tulip extends Flower{
	Tulip() {
		super();
	}
	Tulip(String name,int cost) {
		super(name,cost);
	}
}
