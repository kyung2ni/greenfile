package day0222;

public class RacingCar extends Car{
	int course;
	
	public RacingCar() {
		super();
		course = 0;
		System.out.println("레이싱카가 만들어졌습니다.");
		
	}
	public RacingCar(int num,double gas,int course) {
		super(num,gas);
		this.num = num;
		this.gas = gas;
		this.course = course;
		System.out.printf("코스번호 : %d인 레이싱카를 생성하였습니다.\n",course);
	}
	public void setCourse(int course) {
		this.course = course;
		System.out.println("코스번호 : "+course+"로 설정하였습니다.");
	}
}
