package day0222;

public class DogCat {
	String name;
	int age;
	
	DogCat() {}
	
	DogCat(String name, int age) {
		this.name = name;
		this.age = age;
	}
	
	public void move() {
		System.out.println("동물은 움직인다.");
	}
	public void cry() {
		System.out.println("동물은 운다.");
	}
	public void animalInfo() {
		System.out.printf("%s는 %d살입니다. \n",name,age);
	}
}
