package day0222;

public class PhoneMain {
	public static void main(String[] args) {
		Galaxy g = new Galaxy("갤럭시z플립", "반으로 접혀요",1200000);
		g.phoneInfo();
		
		Apple a = new Apple("아이폰15pro", "갬성", 1600000);
		a.phoneInfo();
	}
}
