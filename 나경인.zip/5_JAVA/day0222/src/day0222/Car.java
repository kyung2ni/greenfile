package day0222;

public class Car {
	int num;
	double gas;
	
	
	public Car() {}
	
	public Car(int num,double gas) {
		this.num = num;
		this.gas = gas; 
		System.out.printf("차량번호 : %d,연료량 %f자동차가 만들어졌습니다.\n",num ,gas);
	}
	
	public void setCar(int num,double gas) {
		this.num = num;
		this.gas = gas;
		System.out.println("차량번호 : "+num+"연료량 : "+gas+"로 설정하였습니다.");
	}
	
	public void show() {
		System.out.println("차량번호 : "+num);
		System.out.println("연료량 : "+gas);
	}
}
