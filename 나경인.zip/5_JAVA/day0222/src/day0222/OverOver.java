package day0222;

public class OverOver {
	public static void main(String[] args) {
		Child ch = new Child();
		ch.print();
		ch.print("오버로딩 된 print() 메서드");
	}
}
