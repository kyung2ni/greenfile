package day0222;

public class Dog extends DogCat{
	
	
	Dog() {}
	
	Dog(String name, int age) {
		super(name , age);
	}
	@Override
	public void move() {
		System.out.println("네 다리로 걸어다닌다.");
	}
	
	@Override
	public void cry() {
		System.out.println("멍멍");
	}
}
