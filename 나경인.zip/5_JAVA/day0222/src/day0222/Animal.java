package day0222;

public class Animal {
	double weight;
	String picture;
	
	void eat() {
		System.out.println("eat()이 호출되었음");
	}
	
	void sleep() {
		System.out.println("sleep()이 호출되었음");
	}
}
