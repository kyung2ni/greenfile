package day0222;

class Parent2 {
	int x=10;
}
class Child2 extends Parent2 {
	int x=20;
	
	void method() {
		System.out.println("x : "+x);
		System.out.println(this.x); // 자신을 가리키는 참조변수
		System.out.println(super.x);
	}
}

public class SuperVar1 {
	public static void main(String[] args) {
	Child2 c = new Child2();
	c.method();
	
	}
}
