package day0222;

public class CarMain {
	public static void main(String[] args) {
		RacingCar rc = new RacingCar(4567,11.3,5);
		rc.setCar(1234, 55.6);
//		rc.setCourse(5);
	}
}
