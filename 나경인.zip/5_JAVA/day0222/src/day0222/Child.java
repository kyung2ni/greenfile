package day0222;

public class Child extends Parent{
	
	//오버라이딩
	@Override
	void print() {
		System.out.println("자녀 클래스의 print()메서드");
	}
	//오버로딩
	void print(String str) {
		System.out.println(str);
	}
}
