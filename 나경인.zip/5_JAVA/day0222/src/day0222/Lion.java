package day0222;

public class Lion extends Animal {

	int legs = 4;

	
	void roar() {
		System.out.println("roar()가 호출됨");
	}
}
