package day0213;

public class Variable1 {

	public static void main(String[] args) {
		
		String name = "김그린";
		int age = 22;
		String addr = "울산시 남구 삼산동";
		
		System.out.println("이름 : " + name);
		System.out.println("나이 : " + age);
		System.out.println("주소 : " + addr);
	}
}
