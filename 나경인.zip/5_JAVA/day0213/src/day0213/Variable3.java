package day0213;

public class Variable3 {

	public static void main(String[] args) {
		
		int a, b;
		
		a = 10;
		System.out.println(a);
		
		b = a;
		System.out.println(a);
		

	}

}
