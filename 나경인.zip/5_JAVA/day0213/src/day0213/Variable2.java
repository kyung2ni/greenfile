package day0213;

public class Variable2 {

	public static void main(String[] args) {
		int x = 3;
		int y = 5;
		
		//x 와 y 의 값을 서로 맞바꾸기
		int temp = x;
		x = y;
		y = temp;
		
		double f = 0.123456789123456789;
		System.out.println(f);
		
		System.out.println(x);
		System.out.println(y);
		
	}
	//변수의 타입 (Data type)
	//기본형(Primitive type)
	//8개 (boolean, char, byte, short, int, long, float, double)
	//실제 값을 저장
	
	//참조형(Reference type)
	//기본형을 제외한 나머지(String,System 등)
	//객체의 주소를 저장(4byte, 0x00000000~0xffffffff) >> 16진수
	
	//기본형의 종류
	//논리형 - true 와 false 중 하나를 값으로 갖으며, 조건식과 논리적계산에 사용된다. boolean-1 
	//문자형 - 문자를 저장하는데 사용되며, 변수 당 하나의 문자만을 저장할 수 있다. char-2
	//정수형 - 정수 값을 저장하는데 사용된다. 주로 사용하는 것은 int 와 long 이며, byte-1 short-2 int-4 long-8
	// 		 byte 는 이진데이터를 다루는데 사용되며, short 는 c 언어와의 호환을 위해 추가되었다.
	//실수형 - 실수 값을 저장하는데 사용된다. float 와 double 이 있다 float-4 double-8
	
	
}
